﻿Imports System.Text
Public Class QuarterlyMaskingUtil

    Private Sub btn_Return_To_Menu_Click(sender As System.Object, e As System.EventArgs) Handles btn_Return_To_Menu.Click
        Dim frmNew As New frm_WBGeneratorsAndUtilitiesMenu
        frmNew.Show()
        Me.Close()
    End Sub

    Private Sub btn_Test_File_Entry_Click(sender As System.Object, e As System.EventArgs) Handles btn_Text_File_Entry.Click
        Dim fd As New OpenFileDialog

        fd.Multiselect = False
        fd.CheckFileExists = True
        fd.Filter = "TXT Files|*.txt|All Files|*.*"

        If fd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            txt_Input_Text_FilePath.Text = fd.FileName
        End If
    End Sub

    Private Sub btn_Output_File_Entry_Click(sender As System.Object, e As System.EventArgs) Handles btn_Output_File_Entry.Click
        Dim fd As New OpenFileDialog

        fd.Multiselect = False
        fd.CheckFileExists = True
        fd.Filter = "TXT Files|*.txt|All Files|*.*"

        If fd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            txt_Output_FilePath.Text = Replace(fd.FileName, ".", "_Masked.")
            If chk_Unmask_Some_49s_For_EIA.Checked = True Then
                txt_Output_FilePath.Text = Replace(txt_Output_FilePath.Text, "Masked", "Unmasked_EIA")
            End If
        End If
    End Sub

    Private Sub btn_Execute_Click(sender As System.Object, e As System.EventArgs) Handles btn_Execute.Click
        Dim rst As ADODB.Recordset = Nothing
        Dim mSQLCmd As String

        Dim fileWriter As StreamWriter
        Dim stringReader As String
        Dim mOutString As StringBuilder
        Dim RecNum As Integer, TotalRecs As Integer
        Dim mSTCCs() As String
        Dim mWriteIt As Boolean

        TotalRecs = 0
        RecNum = 0
        ReDim mSTCCs(0)

        TotalRecs = File.ReadAllLines(txt_Input_Text_FilePath.Text).Length

        If chk_Unmask_Some_49s_For_EIA.Checked Then
            ' Get the STCCs that EIA requires to be unmasked
            gbl_Table_Name = Get_Table_Name_From_SQL("1", "EIA_STCCS")
            gbl_Database_Name = Get_Database_Name_From_SQL("1", "EIA_STCCS")

            OpenADOConnection(Get_Database_Name_From_SQL("1", "EIA_STCCs"))

            rst = SetRST()
            mSQLCmd = "SELECT * FROM " & Global_Variables.gbl_Table_Name

            rst.Open(mSQLCmd, Global_Variables.gbl_ADOConnection)
            rst.MoveFirst()

            ' Now that we have them, resize the array to hold them and load them into the array
            ReDim mSTCCs(rst.RecordCount)
            RecNum = 1

            Do While Not rst.EOF
                mSTCCs(RecNum) = Trim(rst.Fields("STCC").Value)
                RecNum = RecNum + 1
                rst.MoveNext()
            Loop
        End If

        gbl_Database_Name = Get_Database_Name_From_SQL("1", "ORDNANCE_STCCS")
        gbl_Table_Name = Get_Table_Name_From_SQL("1", "ORDNANCE_STCCS")
        OpenADOConnection(gbl_Database_Name)

        fileWriter = New StreamWriter(txt_Output_FilePath.Text, False, Encoding.ASCII)
        RecNum = 0

        Using reader As StreamReader = New StreamReader(txt_Input_Text_FilePath.Text)
            stringReader = reader.ReadLine

            Do While (Not stringReader Is Nothing)
                mOutString = New StringBuilder
                RecNum = RecNum + 1
                mWriteIt = False

                ' Let the user know where we are
                txt_StatusBox.Text = "Processing Line " & RecNum.ToString & " of " & TotalRecs.ToString
                Application.DoEvents()
                Refresh()

                ' If this is an EIA run, only write the records with STCCs they've requested
                If chk_Unmask_Some_49s_For_EIA.Checked = True Then
                    If Array1DFindFirst(mSTCCs, Mid(stringReader, 54, 7)) > 0 Then
                        mOutString.Append(Mid(stringReader, 1, 53) & Mid(stringReader, 54, 7))
                        mOutString.Append(Mid(stringReader, 61))
                        mWriteIt = True
                    Else
                        mWriteIt = False
                    End If
                Else
                    Select Case Mid(stringReader, 54, 2)
                        Case "19"
                            mOutString.Append(Mid(stringReader, 1, 53) & "1900000")
                            mOutString.Append(Mid(stringReader, 61))
                            mWriteIt = True
                        Case "49"
                            mOutString.Append(Mid(stringReader, 1, 53) & "4900000")
                            mOutString.Append(Mid(stringReader, 61))
                            mWriteIt = True
                        Case Else
                            mOutString.Append(Mid(stringReader, 1, 53) & Mid(stringReader, 54, 7))
                            mOutString.Append(Mid(stringReader, 61))
                            mWriteIt = True
                    End Select
                End If

                If mWriteIt = True Then
                    fileWriter.WriteLine(mOutString.ToString)
                End If

                stringReader = reader.ReadLine
            Loop
        End Using


        fileWriter.Flush()
        fileWriter.Close()
        fileWriter.Dispose()

        If chk_Unmask_Some_49s_For_EIA.Checked Then
            rst.Close()
            rst = Nothing
        End If

        txt_StatusBox.Text = "Done!"
        Refresh()

    End Sub

    Private Sub QuarterlyMaskingUtil_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
        Me.Refresh()
    End Sub

    Private Sub chk_Unmask_Some_49s_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chk_Unmask_Some_49s_For_EIA.CheckedChanged
        If chk_Unmask_Some_49s_For_EIA.Checked = True Then
            If InStr(txt_Output_FilePath.Text, "_EIA") Then
                ' do nothing
            Else
                txt_Output_FilePath.Text = Replace(txt_Output_FilePath.Text, "Masked", "Masked_EIA")
            End If
        Else
            If InStr(txt_Output_FilePath.Text, "_EIA") Then
                txt_Output_FilePath.Text = Replace(txt_Output_FilePath.Text, "_EIA", "")
            End If
        End If

    End Sub
End Class