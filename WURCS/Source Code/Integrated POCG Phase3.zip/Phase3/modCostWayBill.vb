﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient
Imports System.Text

Public Class CostWayBill

#Region "Declarations"

    'local data tables
    Private dtRailroads As DataTable
    Private dtCarTypes As DataTable
    Private dtEcodes As DataTable
    Private dtEtable As DataTable
    Private dtSegmentData As DataTable
    Private dtMasterData As DataTable
    Private dtTOFC_Serv_Code As DataTable
    Private dtSTCCLookup As DataTable

    'local SQL vars
    Dim cmdWriteCommand As SqlCommand
    Dim daWriteAdapter As SqlDataAdapter
    Dim dsWriteDataSet As New DataSet

    Dim cmdErrorCommand As SqlCommand
    Dim daErrorAdapter As SqlDataAdapter
    Dim dsErrorDataSet As New DataSet

    'local CRPRES arrays
    Private alCRPRES As New ArrayList()
    Private aCRPRES_Row As Double()
    Private iEAST_ID As Integer = 0
    Private iWEST_ID As Integer = 0
    Private iALL_EAST_ID As Integer = 0
    Private iALL_WEST_ID As Integer = 0

    'Private legacy boolean values
    Private bFilterNonUSMovements As Boolean
    Private bRoundTotalMiles As Boolean
    Private bRoundMiles As Boolean
    Private bFilterSingleMoveLessThan2Miles As Boolean
    Private bFilter0Revenue As Boolean
    Private bAdjustTonsFromLessThan1_To_LessThanorEqualTo0 As Boolean
    Private bAdjustTotalDistFromLessThan1_To_LessThanorEqualTo0 As Boolean
    Private bChangeCarType11Deletion_To_IMandTOFCServCodeX As Boolean
    Private bUse_Car_Own_Field As Boolean
    Private bAdjustLine257 As Boolean
    Private bAdjustRR769To777 As Boolean
    Private bAdjustLine307 As Boolean
    Private bUseSqlToDetermineSTCC As Boolean
    Private bLegacy As Boolean
    Private bWriteSeg1 As Boolean
    Private bWriteSeg2 As Boolean

    'local data variables
    Private iSerialNum As Integer
    Private iSegmentNumber As Integer
    Private dTotalMiles As Double
    Private dMiles As Double
    Private iTotalSegments As Integer
    Private sSegmentType As String
    Private sShipmentSize As String
    Private dInterlineCircuity As Double
    Private dLocalCircuity As Double
    Private sOwnership As String
    Private iCarType As Integer
    Private iExpantionFactor As Integer
    Private iNumCars As Integer
    Private iNumCarsExpanded As Integer
    Private sTOFC_Serv_Code As String
    Private dTOFC_Plan_Code As Double
    Private iRailroadNumber As Integer
    Private lSTCC As Long
    Private dBill_Wght_Tons As Double
    Private iTons As Integer
    Private iU_cars As Integer
    Private iU_TC_Units As Integer
    Private aRRID(7) As Integer

    Private aCol2 As Double()
    Private aCol3 As Double()
    Private aCol4 As Double()
    Private aCol5 As Double()
    Private aCol6 As Double()
    Private aCol7 As Double()
    Private aCol8 As Double()
    Private aCol9 As Double()
    Private aCol10 As Double()
    Private aCol11 As Double()
    Private aCol12 As Double()
    Private aCol13 As Double()
    Private aCol14 As Double()
    Private aCol15 As Double()
    Private aCol16 As Double()
    Private aCol17 As Double()
    Private aCol18 As Double()
    Private aCol19 As Double()

    Public Event StatusUpdated(Status As String)

#End Region

#Region "Line number variables"

    'output line number variables
    Private iL101 As Integer
    Private dL102a As Double
    Private iL102 As Integer
    Private iL103 As Integer
    Private iL104 As Integer
    Private dL105 As Double
    Private dL105R As Double
    Private dL105P As Double
    Private iL250 As Integer
    Private dL106 As Double
    Private dL107 As Double
    Private dL108 As Double
    Private dL109 As Double
    Private dL110 As Double
    Private dL111 As Double

    Private iL201 As Integer
    Private dL202a As Double
    Private dL202 As Double
    Private dL203 As Double
    Private dL204 As Double
    Private dL205 As Double
    Private dL206 As Double
    Private dL207 As Double
    Private dL208 As Double
    Private dL209 As Double
    Private dL210 As Double
    Private dL211 As Double
    Private dL212 As Double
    Private dL213 As Double
    Private dL214 As Double
    Private dL215 As Double
    Private dL216 As Double
    Private iL217 As Integer
    Private iL218 As Integer
    Private dL219 As Double
    Private dL220 As Double
    Private dL221 As Double
    Private dL222 As Double
    Private dL223 As Double
    Private dL224 As Double
    Private dL225 As Double
    Private dL226 As Double
    Private dL227 As Double
    Private dL228 As Double
    Private dL229 As Double
    Private dL230 As Double
    Private dL231 As Double
    Private dL232 As Double
    Private dL233 As Double
    Private dL234 As Double
    Private dL235 As Double
    Private dL236 As Double
    Private dL237 As Double
    Private dL238 As Double
    Private dL239 As Double
    Private dL240 As Double
    Private dL241 As Double
    Private dL242 As Double
    Private dL243 As Double
    Private dL244 As Double
    Private dL245 As Double
    Private dL246 As Double
    Private dL247 As Double
    Private dL248 As Double

    Private dL251 As Double
    Private dL252 As Double
    Private dL253 As Double
    Private dL254 As Double
    Private dL255 As Double
    Private dL256 As Double
    Private dL257 As Double
    Private dL258 As Double
    Private dL259 As Double
    Private dL260 As Double
    Private dL261 As Double
    Private dL262 As Double
    Private dL263 As Double
    Private dL264 As Double
    Private dL265 As Double
    Private dL266 As Double
    Private dL267 As Double
    Private dL268 As Double
    Private dL269 As Double
    Private dL270 As Double
    Private dL271 As Double
    Private dL272 As Double
    Private dL273 As Double
    Private dL274 As Double
    Private dL275 As Double
    Private dL276 As Double
    Private dL277 As Double
    Private dL278 As Double
    Private dL279 As Double
    Private dL280 As Double
    Private dL281 As Double
    Private dL282 As Double
    Private dL283 As Double
    Private dL284 As Double
    Private dL285 As Double
    Private dL286 As Double
    Private dL287 As Double
    Private dL288 As Double
    Private dL289 As Double
    Private dL290 As Double

    Private dL301 As Double
    Private dL302 As Double
    Private dL303 As Double
    Private dL304 As Double
    Private dL305 As Double
    Private dL306 As Double
    Private dL307 As Double
    Private dL308 As Double
    Private dL309 As Double
    Private dL310 As Double
    Private dL311 As Double
    Private dL312 As Double
    Private dL313 As Double
    Private dL314 As Double
    Private dL315 As Double
    Private dL316 As Double
    Private dL317 As Double
    Private dL318 As Double
    Private dL319 As Double
    Private dL320 As Double
    Private dL321 As Double
    Private dL322 As Double
    Private dL323 As Double
    Private dL324 As Double
    Private dL325 As Double
    Private dL326 As Double
    Private dL327 As Double
    Private dL328 As Double
    Private dL329 As Double
    Private dL330 As Double
    Private dL331 As Double
    Private dL332 As Double
    Private dL333 As Double
    Private dL334 As Double

    Private dL401 As Double
    Private dL402 As Double
    Private dL403 As Double
    Private dL404 As Double
    Private dL405 As Double
    Private dL406 As Double
    Private dL407 As Double
    Private dL408 As Double
    Private dL409 As Double
    Private dL410 As Double
    Private dL411 As Double
    Private dL412 As Double
    Private dL413 As Double
    Private dL414 As Double
    Private dL415 As Double
    Private dL416 As Double
    Private dL417 As Double
    Private dL418 As Double
    Private dL419 As Double
    Private dL420 As Double
    Private dL421 As Double
    Private dL422 As Double
    Private dL423 As Double
    Private dL424 As Double
    Private dL425 As Double
    Private dL426 As Double
    Private dL427 As Double
    Private dL428 As Double
    Private dL429 As Double
    Private dL430 As Double
    Private dL431 As Double
    Private dL432 As Double
    Private dL433 As Double
    Private dL434 As Double
    Private dL435 As Double
    Private dL436 As Double
    Private dL437 As Double
    Private dL438 As Double
    Private dL439 As Double
    Private dL440 As Double
    Private dL441 As Double
    Private dL442 As Double
    Private dL443 As Double
    Private dL444 As Double
    Private dL445 As Double
    Private dL446 As Double
    Private dL447 As Double
    Private dL448 As Double
    Private dL449 As Double
    Private dL450 As Double
    Private dL451 As Double
    Private dL452 As Double
    Private dL453 As Double
    Private dL454 As Double
    Private dL455 As Double
    Private dL456 As Double
    Private dL457 As Double
    Private dL458 As Double
    Private dL459 As Double
    Private dL460 As Double
    Private dL461 As Double
    Private dL462 As Double
    Private dL463 As Double
    Private dL464 As Double
    Private dL465 As Double
    Private dL466 As Double
    Private dL467 As Double
    Private dL468 As Double
    Private dL469 As Double
    Private dL470 As Double
    Private dL471 As Double
    Private dL472 As Double
    Private dL473 As Double
    Private dL474 As Double
    Private dL475 As Double
    Private dL476 As Double
    Private dL477 As Double
    Private dL478 As Double
    Private dL479 As Double
    Private dL480 As Double
    Private dL481 As Double
    Private dL482 As Double
    Private dL483 As Double
    Private dL484 As Double
    Private dL485 As Double
    Private dL486 As Double
    Private dL487 As Double
    Private dL488 As Double
    Private dL489 As Double
    Private dL490 As Double
    Private dL491 As Double
    Private dL492 As Double
    Private dL493 As Double
    Private dL494 As Double
    Private dL495 As Double
    Private dL496 As Double
    Private dL497 As Double
    Private dL498 As Double
    Private dL499 As Double
    Private dL499A As Double
    Private dL499B As Double
    Private dL499C As Double
    Private dL499D As Double
    Private dL501 As Double
    Private dL502 As Double
    Private dL503 As Double
    Private dL504 As Double
    Private dL505 As Double
    Private dL506 As Double
    Private dL507 As Double
    Private dL508 As Double
    Private dL509 As Double
    Private dL510 As Double
    Private dL511 As Double
    Private dL512 As Double
    Private dL513 As Double
    Private dL514 As Double
    Private dL515 As Double
    Private dL516 As Double
    Private dL517 As Double
    Private dL518 As Double
    Private dL519 As Double
    Private dL520 As Double
    Private dL521 As Double
    Private dL522 As Double
    Private dL523 As Double
    Private dL524 As Double
    Private dL525 As Double
    Private dL526 As Double
    Private dL527 As Double
    Private dL528 As Double
    Private dL529 As Double
    Private dL530 As Double
    Private dL531 As Double
    Private dL532 As Double
    Private dL533 As Double
    Private dL534 As Double
    Private dL535 As Double
    Private dL536 As Double
    Private dL537 As Double

    Private dL540 As Double
    Private dL541 As Double
    Private dL542 As Double
    Private dL543 As Double
    Private dL544 As Double
    Private dL545 As Double
    Private dL546 As Double
    Private dL547 As Double
    Private dL548 As Double
    Private dL549 As Double
    Private dL550 As Double
    Private dL551 As Double
    Private dL552 As Double
    Private dL553 As Double
    Private dL554 As Double
    Private dL555 As Double
    Private dL556 As Double
    Private dL557 As Double
    Private dL558 As Double
    Private dL559 As Double
    Private dL560 As Double
    Private dL561 As Double
    Private dL562 As Double
    Private dL563 As Double
    Private dL564 As Double
    Private dL565 As Double
    Private dL566 As Double

    Private dL570 As Double
    Private dL571 As Double
    Private dL572 As Double
    Private dL573 As Double
    Private dL574 As Double
    Private dL575 As Double
    Private dL576 As Double
    Private dL577 As Double
    Private dL578 As Double
    Private dL579 As Double
    Private dL580 As Double
    Private dL581 As Double
    Private dL582 As Double
    Private dL583 As Double
    Private dL584 As Double
    Private dL585 As Double
    Private dL586 As Double
    Private dL587 As Double

    Private dL601 As Double
    Private dL602 As Double
    Private dL603 As Double
    Private dL604 As Double
    Private dL605 As Double
    Private dL606 As Double
    Private dL607 As Double
    Private dL608 As Double
    Private dL609 As Double
    Private dL610 As Double
    Private dL611 As Double
    Private dL612 As Double
    Private dL613 As Double
    Private dL614 As Double
    Private dL615 As Double
    Private dL616 As Double
    Private dL617 As Double
    Private dL618 As Double
    Private dL619 As Double
    Private dL620 As Double
    Private dL621 As Double
    Private dL622 As Double
    Private dL623 As Double
    Private dL624 As Double
    Private dL625 As Double
    Private dL626 As Double
    Private dL627 As Double
    Private dL628 As Double
    Private dL629 As Double
    Private dL630 As Double
    Private dL631 As Double
    Private dL632 As Double
    Private dL633 As Double
    Private dL634 As Double
    Private dL635 As Double
    Private dL636 As Double
    Private dL637 As Double
    Private dL638 As Double
    Private dL639 As Double
    Private dL640 As Double
    Private dL641 As Double
    Private dL642 As Double
    Private dL643 As Double
    Private dL644 As Double
    Private dL645 As Double
    Private dL646 As Double
    Private dL647 As Double
    Private dL648 As Double
    Private dL649 As Double
    Private dL650 As Double
    Private dL651 As Double
    Private dL652 As Double
    Private dL653 As Double
    Private dL654 As Double
    Private dL655 As Double
    Private dL656 As Double
    Private dL657 As Double
    Private dL658 As Double
    Private dL659 As Double
    Private dL660 As Double
    Private dL661 As Double
    Private dL662 As Double
    Private dL663 As Double
    Private dL664 As Double
    Private dL665 As Double
    Private dL666 As Double
    Private dL667 As Double
    Private dL668 As Double
    Private dL669 As Double
    Private dL670 As Double
    Private dL671 As Double
    Private dL672 As Double
    Private dL673 As Double
    Private dL674 As Double
    Private dL675 As Double
    Private dL676 As Double
    Private dL677 As Double
    Private dL678 As Double
    Private dL679 As Double
    Private dL680 As Double
    Private dL681 As Double
    Private dL682 As Double
    Private dL683 As Double
    Private dL684 As Double
    Private dL685 As Double
    Private dL686 As Double
    Private dL687 As Double
    Private dL688 As Double
    Private dL689 As Double
    Private dL690 As Double
    Private dL691 As Double
    Private dL692 As Double
    Private dL693 As Double
    Private dL694 As Double
    Private dL695 As Double
    Private dL696 As Double
    Private dL697 As Double
    Private dL698 As Double
    Private dL699 As Double
    Private iL700 As Double

#End Region

#Region "CRPRES column funtions"

    Private Sub gatherLineCosts(ByVal segment As Integer)

        'convert segment number to element number
        segment = segment - 1

        aCol2(segment) = getCol2()
        aCol3(segment) = getCol3()
        aCol4(segment) = getCol4()
        aCol5(segment) = getCol5()
        aCol6(segment) = getCol6()
        aCol7(segment) = getCol7()
        aCol8(segment) = getCol8()
        aCol9(segment) = getCol9()
        aCol10(segment) = getCol10()
        aCol11(segment) = getCol11()
        aCol12(segment) = getCol12()
        aCol13(segment) = getCol13()
        aCol14(segment) = getCol14()
        aCol15(segment) = getCol15()
        aCol16(segment) = getCol16()
        aCol17(segment) = getCol17()
        aCol18(segment) = getCol18()
        aCol19(segment) = getCol19()

    End Sub

    Private Sub CalcCRPRESCosts()

        Dim iClassARR = getRailroadClassA(iRailroadNumber)
        Dim iReigon = getRailroadRegionID(iRailroadNumber)

        For Each rrArray In alCRPRES

            If iClassARR > 0 Then
                If rrArray(0) = Double.Parse(iClassARR) Then
                    setCosts(rrArray)
                End If
                If iReigon = 4 Then
                    If rrArray(0) = Double.Parse(iALL_EAST_ID) Then
                        setCosts(rrArray)
                    End If
                End If
                If iReigon = 7 Then
                    If rrArray(0) = Double.Parse(iALL_WEST_ID) Then
                        setCosts(rrArray)
                    End If
                End If
            Else
                If iReigon = 4 Then
                    If rrArray(0) = Double.Parse(iEAST_ID) Then
                        setCosts(rrArray)
                    End If
                    If rrArray(0) = Double.Parse(iALL_EAST_ID) Then
                        setCosts(rrArray)
                    End If
                End If
                If iReigon = 7 Then
                    If rrArray(0) = Double.Parse(iWEST_ID) Then
                        setCosts(rrArray)
                    End If
                    If rrArray(0) = Double.Parse(iALL_WEST_ID) Then
                        setCosts(rrArray)
                    End If
                End If
            End If
        Next


    End Sub

    Private Sub setCosts(ByRef aArray As Double())
        'Column 2
        aArray(1) += aCol2(1) - aCol2(2)

        'Column 3
        aArray(2) += aCol3(1) - aCol3(2)

        'Column 4
        aArray(3) += aCol4(1) - aCol4(2)

        'Column 5
        aArray(4) += aCol5(1) - aCol5(2)

        'Column 6
        aArray(5) += aCol6(1) - aCol6(2)

        'Column 7
        aArray(6) += aCol7(1) - aCol7(2)

        'Column 8
        aArray(7) += aCol8(1) - aCol8(2)

        'Column 9
        aArray(8) += aCol9(1) - aCol9(2)

        'Column 10
        aArray(9) += aCol10(1) - aCol10(2)

        'Column 11
        aArray(10) += aCol11(1) - aCol11(2)

        'Column 12
        aArray(11) += aCol12(0)

        'Column 13
        aArray(12) += aCol13(0)

        'Column 14
        aArray(13) += aCol14(0)

        'Column 15
        aArray(14) += aCol15(0)

        'Column 16
        aArray(15) += aCol16(0)

        'Column 17
        aArray(16) += aCol17(0)

        'Column 18
        aArray(17) += aCol18(0)

        'Column 19
        aArray(18) += aCol19(0)
    End Sub

    Private Function getCol2() As Double

        Dim c2 As Double = 0.0

        Try
            If sSegmentType = "IA" Then
                c2 = (dL323 / iU_cars) * (dL315 + dL317 + dL319)
            ElseIf sSegmentType = "IR" Then
                c2 = (dL324 / iU_cars) * (dL315 + dL317 + dL319)
            Else
                c2 = dL311 * (dL315 + dL317 + dL319)
            End If

            If Double.IsNaN(c2) Or Double.IsInfinity(c2) Then
                c2 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 2 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol2")
            c2 = 0.0
        End Try

        Return c2

    End Function

    Private Function getCol3() As Double

        Dim c3 As Double = 0.0

        Try
            If sSegmentType = "IA" Then
                c3 = dL327 * (dL315 + dL317 + dL319)
            ElseIf sSegmentType = "IR" Then
                c3 = dL328 * (dL315 + dL317 + dL319)
            Else
                c3 = dL312 * (dL315 + dL317 + dL319)
            End If

            If Double.IsNaN(c3) Or Double.IsInfinity(c3) Then
                c3 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 3 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol3")
            c3 = 0.0
        End Try

        Return c3

    End Function

    Private Function getCol4() As Double

        Dim c4 As Double = 0.0

        Try
            If sSegmentType = "IA" Then
                c4 = 0.0
            ElseIf sSegmentType = "IR" Then
                c4 = 0.0
            Else
                c4 = dL313 * (dL315 + dL317 + dL319)
            End If

            If Double.IsNaN(c4) Or Double.IsInfinity(c4) Then
                c4 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 4 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol4")
            c4 = 0.0
        End Try

        Return c4

    End Function

    Private Function getCol5() As Double

        Dim c5 As Double = 0.0
        Dim RRMC As Double = 0.0
        Dim RRTC As Double = 0.0
        Dim RRAC As Double = 0.0
        Dim RRAT As Double = 0.0

        Try
            RRMC = dL423 * (dL426 + dL428 + dL430)
            RRTC = dL447 * (dL452 + dL454 + dL456)
            RRAC = dL423 * (dL464 + dL466 + dL468)
            RRAT = dL447 * (dL476 + dL478 + dL480)

            c5 = RRMC + RRTC + RRAC + RRAT

            If Double.IsNaN(c5) Or Double.IsInfinity(c5) Then
                c5 = 0.0
            End If

        Catch ex as system.exception
            HandleError("Error while calculating costs for column 5 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol5")
            c5 = 0.0
        End Try

        Return c5

    End Function

    Private Function getCol6() As Double

        Dim c6 As Double = 0.0
        Dim RRMC As Double = 0.0
        Dim RRTC As Double = 0.0
        Dim RRAC As Double = 0.0
        Dim RRAT As Double = 0.0

        Try

            RRMC = dL424 * (dL426 + dL428 + dL430)
            RRTC = dL448 * (dL452 + dL454 + dL456)
            RRAC = dL424 * (dL464 + dL466 + dL468)
            RRAT = dL448 * (dL476 + dL478 + dL480)

            c6 = RRMC + RRTC + RRAC + RRAT

            If Double.IsNaN(c6) Or Double.IsInfinity(c6) Then
                c6 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 6 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol6")
            c6 = 0.0
        End Try

        Return c6

    End Function

    Private Function getCol7() As Double

        Dim c7 As Double = 0.0
        Dim RRMC As Double = 0.0
        Dim RRTC As Double = 0.0
        Dim RRAC As Double = 0.0
        Dim RRAT As Double = 0.0

        Try
            RRMC = dL422 * (dL426 + dL428 + dL430)
            RRTC = dL446 * (dL452 + dL454 + dL456)
            RRAC = dL422 * (dL464 + dL466 + dL468)
            RRAT = dL446 * (dL476 + dL478 + dL480)

            c7 = RRMC + RRTC + RRAC + RRAT

            If Double.IsNaN(c7) Or Double.IsInfinity(c7) Then
                c7 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 7 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol7")
            c7 = 0.0
        End Try

        Return c7

    End Function

    Private Function getCol8() As Double

        Dim c8 As Double = 0.0
        Dim RRCT As Double = 0.0
        Dim RRAT As Double = 0.0

        Try
            RRCT = dL450 * (dL452 + dL454 + dL456)
            RRAT = dL450 * (dL476 + dL478 + dL480)

            c8 = RRCT + RRAT

            If Double.IsNaN(c8) Or Double.IsInfinity(c8) Then
                c8 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 8 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol8")
            c8 = 0.0
        End Try

        Return c8

    End Function

    Private Function getCol9() As Double

        Dim c9 As Double = 0.0

        Try
            c9 = dL258

            If Double.IsNaN(c9) Or Double.IsInfinity(c9) Then
                c9 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 9 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol9")
            c9 = 0.0
        End Try

        Return c9

    End Function

    Private Function getCol10() As Double

        Dim c10 As Double = 0.0
        Dim GTMC As Double = 0.0
        Dim LUMC As Double = 0.0

        Try
            GTMC = dL219 * (dL220 + dL222 + dL224)
            LUMC = dL242 * (dL243 + dL245 + dL247)

            c10 = GTMC + LUMC

            If Double.IsNaN(c10) Or Double.IsInfinity(c10) Then
                c10 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 10 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol10")
            c10 = 0.0
        End Try

        Return c10

    End Function

    Private Function getCol11() As Double

        Dim c11 As Double = 0.0

        Try
            c11 = dL411 + dL413 + dL415 + dL438 + dL440 + dL442 + dL459 + dL461 + dL463 + dL471 + dL473 + dL475

            If Double.IsNaN(c11) Or Double.IsInfinity(c11) Then
                c11 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 11 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol11")
            c11 = 0.0
        End Try

        Return c11

    End Function

    Private Function getCol12() As Double

        Dim c12 As Double = 0.0

        Try
            If sShipmentSize = "SC" Then
                If sSegmentType = "IA" Then
                    c12 = dL323 / iNumCars
                ElseIf sSegmentType = "IR" Then
                    c12 = dL324 / iNumCars
                Else
                    c12 = dL305
                End If
            End If

            If Double.IsNaN(c12) Or Double.IsInfinity(c12) Then
                c12 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 12 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol12")
            c12 = 0.0
        End Try

        Return c12

    End Function

    Private Function getCol13() As Double

        Dim c13 As Double = 0.0

        Try
            If sShipmentSize = "SC" Then
                If sSegmentType = "IA" Then
                    c13 = dL323
                ElseIf sSegmentType = "IR" Then
                    c13 = dL324
                Else
                    c13 = dL251 + dL252
                End If
            End If

            If Double.IsNaN(c13) Or Double.IsInfinity(c13) Then
                c13 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 13 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol13")
            c13 = 0.0
        End Try

        Return c13
    End Function

    Private Function getCol14() As Double

        Dim c14 As Double = 0.0

        Try
            If sShipmentSize = "SC" And sOwnership = "R" Then
                c14 = dL305
            End If

            If sSegmentType = "IA" Or sSegmentType = "IR" Then
                c14 = 0.0
            End If

            If Double.IsNaN(c14) Or Double.IsInfinity(c14) Then
                c14 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 14 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol14")
            c14 = 0.0
        End Try

        Return c14

    End Function

    Private Function getCol15() As Double

        Dim c15 As Double = 0.0

        Try
            If sShipmentSize = "SC" And sOwnership = "R" Then
                c15 = dL251 + dL252
            End If

            If sSegmentType = "IA" Or sSegmentType = "IR" Then
                c15 = 0.0
            End If

            If Double.IsNaN(c15) Or Double.IsInfinity(c15) Then
                c15 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 15 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol15")
            c15 = 0.0
        End Try

        Return c15

    End Function

    Private Function getCol16() As Double

        Dim c16 As Double = 0.0

        Try
            If sShipmentSize = "SC" Or sShipmentSize = "MC" Then
                If sSegmentType = "IA" Then
                    c16 = dL323
                ElseIf sSegmentType = "IR" Then
                    c16 = dL324
                Else
                    c16 = dL308
                End If
            End If

            If Double.IsNaN(c16) Or Double.IsInfinity(c16) Then
                c16 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 16 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol16")
            c16 = 0.0
        End Try

        Return c16
    End Function

    Private Function getCol17() As Double

        Dim c17 As Double = 0.0

        Try
            If (sShipmentSize = "SC" Or sShipmentSize = "MC") And sOwnership = "R" Then
                c17 = dL308
            End If

            If sSegmentType = "IA" Or sSegmentType = "IR" Then
                c17 = 0.0
            End If

            If Double.IsNaN(c17) Or Double.IsInfinity(c17) Then
                c17 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 17 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol17")
            c17 = 0.0
        End Try

        Return c17

    End Function

    Private Function getCol18() As Double

        Dim c18 As Double = 0.0

        Try
            If sShipmentSize = "SC" Or sShipmentSize = "MC" Then
                c18 = dL205 '/ 1000
            End If

            If sSegmentType = "IA" Or sSegmentType = "IR" Then
                c18 = 0.0
            End If

            If Double.IsNaN(c18) Or Double.IsInfinity(c18) Then
                c18 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 18 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol18")
            c18 = 0.0
        End Try

        Return c18

    End Function

    Private Function getCol19() As Double

        Dim c19 As Double = 0.0

        Try
            If (sShipmentSize = "SC" Or sShipmentSize = "MC") And sOwnership = "R" Then
                c19 = dL205 '/ 1000
            End If

            If sSegmentType = "IA" Or sSegmentType = "IR" Then
                c19 = 0.0
            End If

            If Double.IsNaN(c19) Or Double.IsInfinity(c19) Then
                c19 = 0.0
            End If
        Catch ex as system.exception
            HandleError("Error while calculating costs for column 19 - value was forced to 0.0" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "getCol19")
            c19 = 0.0
        End Try

        Return c19

    End Function

#End Region

#Region "Public Functions"

    Public Sub New(ByVal sCurrentYear As String, _
               ByVal Legacy As Boolean, _
               ByVal bFilterNonUS As Boolean, _
               ByVal bRTotalMiles As Boolean, _
               ByVal bRMiles As Boolean, _
               ByVal WriteSeg1 As Boolean, _
               ByVal WriteSeg2 As Boolean, _
               ByVal bFilterSingleTotalDist As Boolean, _
               ByVal bFilterRev0 As Boolean, _
               ByVal bChangeTons As Boolean, _
               ByVal bChangeTotalDist As Boolean, _
               ByVal cChangeTSCAssignment As Boolean, _
               ByVal bUseCarOwn As Boolean, _
               ByVal bAdjust257 As Boolean, _
               ByVal bAdjustRR769 As Boolean, _
               ByVal bAdjust307 As Boolean, _
               ByVal bUseSQLforSTCC As Boolean)

        'Get Necessary Inputs
        '========================================================================
        'Open the global connection to the work database
        OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "MASKED"))

        bFilterNonUSMovements = bFilterNonUS
        bRoundTotalMiles = bRTotalMiles
        bRoundMiles = bRMiles
        bFilterSingleMoveLessThan2Miles = bFilterSingleTotalDist
        bFilter0Revenue = bFilterRev0
        bAdjustTonsFromLessThan1_To_LessThanorEqualTo0 = bChangeTons
        bAdjustTotalDistFromLessThan1_To_LessThanorEqualTo0 = bChangeTotalDist
        bChangeCarType11Deletion_To_IMandTOFCServCodeX = cChangeTSCAssignment
        bUse_Car_Own_Field = bUseCarOwn
        bAdjustLine257 = bAdjust257
        bAdjustRR769To777 = bAdjustRR769
        bAdjustLine307 = bAdjust307
        bUseSqlToDetermineSTCC = bUseSQLforSTCC
        bLegacy = Legacy
        bWriteSeg1 = WriteSeg1
        bWriteSeg2 = WriteSeg2

    End Sub

    Public Sub Process()
        Try
            'Data Truncation
            '========================================================================

            'First we need to truncate all data all CRPSEG tables
            'even if we do not intend to write it so we can avoid confusion,
            'but only within the current legacy assigment
            truncateTable(bLegacy, 1) ' seg1 table
            truncateTable(bLegacy, 2) ' seg2 table
            truncateTable(bLegacy, 3) ' seg3 table

            'Next truncate the CRPRES
            truncateCRPRESTable(bLegacy)

            'finally truncate the ERROR Table
            truncateERRORSTable()

            'announce the start of the process
            HandleError("Status", "Started Costing Process", "Started Costing Process", "Started Costing Process")

            'fill data tables for program use
            '========================================================================

            'Railroad data
            dtRailroads = fillRailroads()

            'Rail Car Types
            dtCarTypes = fillDataTable("Car_Type", "CarTypeData")

            'Ecode Data (specific to the ecode itself)
            dtEcodes = fillDataTable("ECodes", "ECodeData")

            'The actual etable data by railroad.
            'each table is named with a rr_id
            dtEtable = fillEtable()

            'TOFC_Serv_Code Data
            dtTOFC_Serv_Code = fillDataTable("TOFC_SERV_CODE", "TOFC_SERV_CODE")

            'STCC Lookup 
            dtSTCCLookup = fillDataTable("STCC_L_AND_D", "STCC")

            'Here is the biggie, get the master data
            dtMasterData = fillMasterData()

            'init the railroad arrays to hold the CRPRES output.
            '========================================================================
            For Each dr As DataRow In dtRailroads.Rows()
                If Integer.Parse(dr("RR_ID")) > 0 Then
                    If Integer.Parse(dr("RR_ID")) > iEAST_ID Then
                        iEAST_ID = Integer.Parse(dr("RR_ID"))
                    End If
                    aCRPRES_Row = New Double() {Double.Parse(dr("RR_ID")), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
                    alCRPRES.Add(aCRPRES_Row)
                End If
            Next

            'Now that we have the class A RRs, append east and west arrays
            iEAST_ID = iEAST_ID + 1
            iWEST_ID = iEAST_ID + 1
            iALL_EAST_ID = iWEST_ID + 1
            iALL_WEST_ID = iALL_EAST_ID + 1

            'east
            aCRPRES_Row = New Double() {Double.Parse(iEAST_ID), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
            alCRPRES.Add(aCRPRES_Row)

            'west
            aCRPRES_Row = New Double() {Double.Parse(iWEST_ID), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
            alCRPRES.Add(aCRPRES_Row)

            'alleast
            aCRPRES_Row = New Double() {Double.Parse(iALL_EAST_ID), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
            alCRPRES.Add(aCRPRES_Row)

            'allWest
            aCRPRES_Row = New Double() {Double.Parse(iALL_WEST_ID), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
            alCRPRES.Add(aCRPRES_Row)

            'init the column variables for segment costs
            aCol2 = New Double() {0.0, 0.0, 0.0}
            aCol3 = New Double() {0.0, 0.0, 0.0}
            aCol4 = New Double() {0.0, 0.0, 0.0}
            aCol5 = New Double() {0.0, 0.0, 0.0}
            aCol6 = New Double() {0.0, 0.0, 0.0}
            aCol7 = New Double() {0.0, 0.0, 0.0}
            aCol8 = New Double() {0.0, 0.0, 0.0}
            aCol9 = New Double() {0.0, 0.0, 0.0}
            aCol10 = New Double() {0.0, 0.0, 0.0}
            aCol11 = New Double() {0.0, 0.0, 0.0}
            aCol12 = New Double() {0.0, 0.0, 0.0}
            aCol13 = New Double() {0.0, 0.0, 0.0}
            aCol14 = New Double() {0.0, 0.0, 0.0}
            aCol15 = New Double() {0.0, 0.0, 0.0}
            aCol16 = New Double() {0.0, 0.0, 0.0}
            aCol17 = New Double() {0.0, 0.0, 0.0}
            aCol18 = New Double() {0.0, 0.0, 0.0}
            aCol19 = New Double() {0.0, 0.0, 0.0}


            'Create a collection of DataRows to loop on and fill them with filtered data
            '========================================================================
            Dim RowsForLoop As DataRow()

            If bLegacy Then
                RowsForLoop = getFilteredInputLegacy(dtMasterData)
            Else
                RowsForLoop = getFilteredInput(dtMasterData)
            End If

            RaiseEvent StatusUpdated("Costing of Waybill Segments started...")

            'Loop on RowsForLoop, set inputs
            '========================================================================
            Dim iRowNumber As Integer = 0
            For Each dr As DataRow In RowsForLoop

                'now lets zero out, or stage all input variables as expected
                RefreshLoopVars()

                'iSerialNum is set to Serial_no from U_CURRENT_MASKED
                Try
                    iSerialNum = Integer.Parse(dr("Serial_no"))
                    'Print(iSerialNum)
                Catch ex As System.Exception
                    HandleError("Cannot Set Serial_no", ex.Message, ex.StackTrace, "MainLoop-iSerialNum")
                End Try

                'iSegmentNumber is set to Seg_no from U_CURRENT_SEGMENTS
                Try
                    iSegmentNumber = Integer.Parse(dr("Seg_no"))
                Catch ex As System.Exception
                    HandleError("Cannot Set iSegmentNumber", ex.Message, ex.StackTrace, "MainLoop-iSegmentNumber")
                End Try

                'dTotalMiles *see getTotalMiles function for data definition
                Try
                    If bLegacy Then
                        dTotalMiles = getTotalMiles(Double.Parse(dr.Item("total_dist")), True)
                    Else
                        dTotalMiles = getTotalMiles(Double.Parse(dr.Item("total_dist")), bRoundTotalMiles)
                    End If
                Catch ex As System.Exception
                    HandleError("Cannot Set dTotalMiles" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-dTotalMiles")
                End Try

                'dMiles *see getMiles function for data definition
                Try
                    If bLegacy Then
                        dMiles = getMiles(Integer.Parse(dr("RR_dist")), True)
                    Else
                        dMiles = getMiles(Integer.Parse(dr("RR_dist")), bRoundMiles)
                    End If
                Catch ex As System.Exception
                    HandleError("Cannot Set dMiles" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-dMiles")
                End Try

                'iTotalSegments is set to Total_Segs from U_CURRENT_SEGMENTS
                Try
                    iTotalSegments = dr("Total_Segs").ToString
                Catch ex As System.Exception
                    HandleError("Cannot Set iTotalSegments" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-iTotalSegments")
                End Try

                'sSegmentType is set to ship_type from U_CURRENT_SEGMENTS
                Try
                    sSegmentType = dr("seg_type").ToString
                Catch ex As System.Exception
                    HandleError("Cannot Set sSegmentType" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-sSegmentType")
                End Try

                'sShipmentSize *see getShipmentSize function for data definition
                Try
                    sShipmentSize = getsShipmentSize(Integer.Parse(dr("STB_Car_Typ")), dr("TOFC_Serv_Code").ToString(), Integer.Parse(dr("U_Cars")))
                Catch ex As System.Exception
                    HandleError("Cannot Set sShipmentSize" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-sShipmentSize")
                End Try

                'sOwnership is by to U_Car_Init from U_CURRENT_MASKED
                Try
                    If bUse_Car_Own_Field Then
                        sOwnership = dr("car_own").ToString()
                    Else
                        sOwnership = getOwnership(dr("U_Car_Init").ToString())
                    End If
                Catch ex As System.Exception
                    HandleError("Cannot Set sOwnership" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-sOwnership")
                End Try

                'sTOFC_Serv_Code set from U_CURRENT_MASKED
                Try
                    sTOFC_Serv_Code = dr("TOFC_Serv_Code").ToString()
                Catch ex As System.Exception
                    HandleError("Cannot Set sTOFC_Serv_Code" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-sTOFC_Serv_Code")
                End Try

                'iCarType is set to car_own from mask.STB_Car_Typ adjusted to a Washburnian value
                Try
                    iCarType = setCarType(Integer.Parse(dr("STB_Car_Typ")), dr("TOFC_Serv_Code").ToString())
                Catch ex As System.Exception
                    HandleError("Cannot Set iCarType" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-iCarType")
                End Try

                'Delete any rows with bad car Types and jump out of the loop
                If iCarType = 18 Or iCarType = 0 Then
                    HandleError("Serial_No:" & iSerialNum.ToString() & ", Segment_No:" & iSegmentNumber.ToString(),
                                "Removed Row based on criteria enforcement: STB_Car_typ invalid",
                                "Caused a suppression of a datarow on input:",
                                "MainLoop-Filter")
                    Continue For
                End If

                'Delete any rows with a carType of 11 that do not have a TOFC_Serv_Code
                If bChangeCarType11Deletion_To_IMandTOFCServCodeX Then
                    If iCarType = 11 And dr("TOFC_Serv_Code").ToString() = "" Then
                        sTOFC_Serv_Code = "X"
                        sShipmentSize = "IM"
                    End If
                Else
                    If iCarType = 11 And dr("TOFC_Serv_Code").ToString() = "" Then
                        HandleError("Serial_No:" & iSerialNum.ToString() & ", Segment_No:" & iSegmentNumber.ToString(),
                                    "Removed Row based on criteria enforcement: If STB_Car_typ = 46, TOFC_Serv_Code cannot be null.",
                                    "Caused a suppression of a datarow on input:",
                                    "MainLoop-Filter")
                        Continue For
                    End If
                End If


                'Delete Intermodal movements for Coal ??? Washburn
                If iCarType = 11 And dr("STCC").ToString().Substring(0, 3) = "112" Then
                    HandleError("Serial_No:" & iSerialNum.ToString() & ", Segment_No:" & iSegmentNumber.ToString(),
                                "Removed Row based on criteria enforcement: Intermodal Shipments are not allowed for Coal",
                                "Caused a suppression of a datarow on input:",
                                "MainLoop-Filter")
                    Continue For
                End If

                'iRailroadNumber is set to RR_NUM from U_CURRENT_SEGMENTS
                Try
                    iRailroadNumber = Integer.Parse(dr("RR_Num"))
                    If bLegacy Then
                        If iRailroadNumber = 769 Then
                            iRailroadNumber = 777
                        End If
                    Else
                        If bAdjustRR769To777 Then
                            If iRailroadNumber = 769 Then
                                iRailroadNumber = 777
                            End If
                        End If
                    End If
                Catch ex As System.Exception
                    HandleError("Cannot Set iRailroadNumber" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-iRailroadNumber")
                End Try

                'iNumCars is set to U_Cars from U_CURRENT_MASKED
                Try
                    iNumCars = Integer.Parse(dr("U_Cars"))
                Catch ex As System.Exception
                    HandleError("Cannot Set iNumCars" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-iNumCars")
                End Try

                'iExpantionFactor is set to Exp_Factor_Th from U_CURRENT_MASKED
                Try
                    iExpantionFactor = Integer.Parse(dr("Exp_Factor_Th"))
                Catch ex As System.Exception
                    HandleError("Cannot Set iExpantionFactor" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-iExpantionFactor")
                End Try

                'iNumCarsExpanded is set to (U_Cars * Exp_Factor_Th) from U_CURRENT_MASKED
                Try
                    iNumCarsExpanded = iNumCars * iExpantionFactor
                Catch ex As System.Exception
                    HandleError("Cannot Set iNumCars" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-iNumCarsExpanded")
                End Try

                'dTOFC_Plan_Code is a lookup from sTOFC_Serv_Code value
                Try
                    dTOFC_Plan_Code = getTOFC_Plan_Code(sTOFC_Serv_Code)
                Catch ex As System.Exception
                    HandleError("Cannot Set dTOFC_Plan_Code" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-dTOFC_Plan_Code")
                End Try

                'dInterlineCircuity *see getInterlineCircuity function for data definition
                Try
                    dInterlineCircuity = getInterlineCircuity(iCarType, iRailroadNumber)
                Catch ex As System.Exception
                    HandleError("Cannot Set dInterlineCircuity" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-dInterlineCircuity")
                End Try

                'dLocalCircuity *see getLocalCircuity function for data definition
                Try
                    dLocalCircuity = getLocalCircuity(iCarType, iRailroadNumber)
                Catch ex As System.Exception
                    HandleError("Cannot Set dLocalCircuity" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-dLocalCircuity")
                End Try

                'lSTCC is set to STCC from the Masked Table
                Try
                    lSTCC = Long.Parse(dr("STCC"))
                Catch ex As System.Exception
                    HandleError("Cannot Set STCC" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-lSTCC")
                End Try

                'dBill_Wght_Tons is set to bill_Wght_tons from the Masked Table
                Try
                    dBill_Wght_Tons = Double.Parse(dr("bill_Wght_tons"))
                Catch ex As System.Exception
                    HandleError("Cannot Set bill_Wght_Tons" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-dBill_Wght_Tons")
                End Try

                'dU_cars is set to U_cars from the Masked Table
                Try
                    iU_cars = Integer.Parse(dr("u_cars"))
                Catch ex As System.Exception
                    HandleError("Cannot Set u_cars" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-dU_cars")
                End Try

                'iU_TC_Units is set to u_tc_units from the Masked Table
                Try
                    iU_TC_Units = Integer.Parse(dr("u_tc_units"))
                Catch ex As System.Exception
                    HandleError("Cannot Set U_TC_Units" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-iU_TC_Units")
                End Try

                'iTons is set to Tons from the Masked Table
                Try
                    iTons = Integer.Parse(dr("Tons"))
                Catch ex As System.Exception
                    HandleError("Cannot Set Serial_no", ex.Message, ex.StackTrace, "MainLoop-iTons")
                End Try

                'Array for RR ID
                Try
                    'set the first and last elements
                    aRRID(0) = Integer.Parse(dr("ORR"))
                    aRRID(7) = Integer.Parse(dr("TRR"))

                    'try to set all the rest
                    Try
                        aRRID(1) = Integer.Parse(dr("JRR1"))
                    Catch
                    End Try
                    Try
                        aRRID(2) = Integer.Parse(dr("JRR2"))
                    Catch
                    End Try
                    Try
                        aRRID(3) = Integer.Parse(dr("JRR3"))
                    Catch
                    End Try
                    Try
                        aRRID(4) = Integer.Parse(dr("JRR4"))
                    Catch
                    End Try
                    Try
                        aRRID(5) = Integer.Parse(dr("JRR5"))
                    Catch
                    End Try
                    Try
                        aRRID(6) = Integer.Parse(dr("JRR6"))
                    Catch
                    End Try

                    'now adjust the TRR to the correct location
                    Dim iJF As Integer = Integer.Parse(dr("JF"))
                    aRRID(iJF) = aRRID(7)


                Catch ex As System.Exception
                    HandleError("Cannot Set RR_ID Array", ex.Message, ex.StackTrace, "MainLoop-aRRID")
                End Try

                'Call the costing proc for each segment, then gather costs
                '========================================================================

                'Call the costing loop and store the costs for segment 1
                Cost(bLegacy, 1, bWriteSeg1)
                Try
                    If dL696 > 0 Then
                        gatherLineCosts(1)
                    Else
                        Continue For
                    End If
                Catch ex As System.Exception
                    HandleError("Cannot gather costs for loopSegment 1" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-loopSegment1")
                End Try

                'Call the costing loop and store the costs for segment 2
                Cost(bLegacy, 2, bWriteSeg2)
                Try
                    If dL696 > 0 Then
                        gatherLineCosts(2)
                    Else
                        Continue For
                    End If
                Catch ex As System.Exception
                    HandleError("Cannot gather costs for loopSegment 2" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-loopSegment2")
                End Try

                'Call the costing loop and store the costs for segment 3
                Cost(bLegacy, 3, True) 'we allways want to write out seg 3 as it is our CRPSEG file.
                Try
                    If dL696 > 0 Then
                        gatherLineCosts(3)
                    Else
                        Continue For
                    End If
                Catch ex As System.Exception
                    HandleError("Cannot gather costs for loopSegment 3" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-loopSegment3")
                End Try

                'Now calc costs and add to the railroad totals
                '========================================================================
                Try
                    CalcCRPRESCosts()
                Catch ex As System.Exception
                    HandleError("Error while calculating costs for serialNumber " & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-CalcCRPRESCosts")
                End Try

                iRowNumber = iRowNumber + 1
                If iRowNumber Mod 100 = 0 Then
                    RaiseEvent StatusUpdated("Costed row " + iRowNumber.ToString() + " out of " + RowsForLoop.Count.ToString())
                End If

            Next

            'Finally we can write the CRPRES File to SQL
            '========================================================================
            iRowNumber = 0
            Try
                For Each aD As Double() In alCRPRES
                    writeCRPRES(aD, bLegacy)

                    iRowNumber = iRowNumber + 1
                    If iRowNumber Mod 100 = 0 Then
                        RaiseEvent StatusUpdated("Writing CRPRES record " + iRowNumber.ToString() + " out of " + alCRPRES.Count.ToString())
                    End If
                Next

            Catch ex As System.Exception
                HandleError("Error while calculating costs for serialNumber " & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop-writeCRPRES")
            End Try


            'Write row to error table to announce end of processing
            HandleError("Status", "Ended Costing Process", "Ended Costing Process", "Ended Costing Process")

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError("Unhandled ex" & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace.ToString(), "MainLoop")
        End Try
    End Sub


    ''' <summary>
    ''' The STB_Car_Typ differes from the Phase_3_Car_Type_Code
    ''' This function will fetch the correct Phase_3_Car_Type_Code
    ''' using the STB_Car_Typ
    ''' </summary>
    ''' <param name="STB_CarType"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function getP3CarType(ByVal STB_CarType As Integer) As Integer

        Dim Rows() = dtCarTypes.Select("STB_Car_Typ = " & STB_CarType.ToString)

        If Rows(0) IsNot Nothing Then
            Return Integer.Parse(Rows(0)("Phase_3_Car_Type_Code"))
        Else
            Return 0
        End If

    End Function

    ''' <summary>
    ''' Uses supplied data to retrive the correct eTable value
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function getEcodeValue(ByVal Epart As String, ByVal Code As String,
                                          ByVal Railroad As Integer, ByVal lineA As String) As Double

        'First get the STB RR_ID and Region_ID from the railroad table
        '======================================================================
        Dim rr() = dtRailroads.Select("AARID = " & Railroad.ToString())
        Dim RR_ID As Integer = rr(0)("RR_ID")
        Dim RR_Region As Integer = rr(0)("REGION_ID")

        'If railroad id is 0 then decide if it is east or west.
        'Take the resulting and get the ecode 
        '======================================================================
        Dim ecode As Integer
        Dim ecodeRows As DataRow()
        Dim eTableRows As DataRow()

        ecodeRows = dtEcodes.Select("EPart = '" & Epart & "' AND Code = '" & Code & "' AND LineA = 'L" & lineA & "'")
        ecode = Integer.Parse(ecodeRows(0)("eCode_id"))

        If RR_ID = 0 Then
            If RR_Region = 4 Then
                'call the eastern railroad
                eTableRows = dtEtable.Select("eCode_id = " & ecode & " AND RR_id = 8")
            Else
                'call the western railroad
                eTableRows = dtEtable.Select("eCode_id = " & ecode & " AND RR_id = 9")
            End If

        Else
            eTableRows = dtEtable.Select("eCode_id = " & ecode & " AND RR_id = " & RR_ID.ToString())
        End If

        Return eTableRows(0)("Value")

    End Function

    ''' <summary>
    ''' Gets the Region for the specified RR_ID
    ''' </summary>
    ''' <param name="RR_ID"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function getRailroadRegionID(ByVal RR_ID As Integer) As Integer

        Dim rr() = dtRailroads.Select("AARID = " & RR_ID.ToString())
        Return Integer.Parse(rr(0)("REGION_ID"))

    End Function

    ''' <summary>
    ''' Gets the Class A RR_ID for the specified RR_ID
    ''' </summary>
    ''' <param name="RR_ID"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function getRailroadClassA(ByVal RR_ID As Integer) As Integer

        Dim rr() = dtRailroads.Select("AARID = " & RR_ID.ToString())
        Return Integer.Parse(rr(0)("RR_ID"))

    End Function

    ''' <summary>
    ''' Uses supplied data to retrive the correct eTable value
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function getEcodeValue_CarType(ByVal Epart As String, ByVal Code As String,
                                          ByVal Railroad As Integer, ByVal carType As Integer) As Double

        'First get the STB RR_ID and Region_ID from the railroad table
        '======================================================================
        Dim rr() = dtRailroads.Select("AARID = " & Railroad.ToString())
        Dim RR_ID As Integer = rr(0)("RR_ID")
        Dim RR_Region As Integer = rr(0)("REGION_ID")

        'If railroad id is 0 then decide if it is east or west.
        'Take the resulting and get the ecode 
        '======================================================================
        Dim ecode As Integer
        Dim ecodeRows As DataRow()
        Dim eTableRows As DataRow()

        ecodeRows = dtEcodes.Select("EPart = '" & Epart & "' AND Code = '" & Code & "' AND carType_ID = '" & carType & "'")
        ecode = Integer.Parse(ecodeRows(0)("eCode_id"))

        If RR_ID = 0 Then
            If RR_Region = 4 Then
                'call the eastern railroad
                eTableRows = dtEtable.Select("eCode_id = " & ecode & " AND RR_id = 8")
            Else
                'call the western railroad
                eTableRows = dtEtable.Select("eCode_id = " & ecode & " AND RR_id = 9")
            End If

        Else
            eTableRows = dtEtable.Select("eCode_id = " & ecode & " AND RR_id = " & RR_ID.ToString())
        End If

        Return eTableRows(0)("Value")

    End Function

    ''' <summary>
    ''' This function takes the TOFC_Serv_Code and returns the TOFC_Plan_Code
    ''' </summary>
    ''' <param name="serv_code"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function getTOFC_Plan_Code(ByVal serv_code As Char) As Double

        Try
            Dim Rows() = dtTOFC_Serv_Code.Select("tofc_serv_code = '" & serv_code.ToString() & "'")

            If Rows(0) IsNot Nothing Then
                Return Double.Parse(Rows(0)("tofc_plan_code"))
            Else
                Return 0
            End If
        Catch
            'TODO: readdress this issue.  For now, set it to 0
            Return 0
        End Try

    End Function

    ''' <summary>
    ''' This function takes the TOFC_Serv_Code and returns the intermodal_code
    ''' </summary>
    ''' <param name="serv_code"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function getIntermodal_Code(ByVal serv_code As Char) As Double

        Dim Rows() = dtTOFC_Serv_Code.Select("tofc_serv_code = " & serv_code.ToString())

        If Rows(0) IsNot Nothing Then
            Return Double.Parse(Rows(0)("intermodal_code"))
        Else
            Return 0
        End If

    End Function

#End Region

#Region "Line number functions"

    ''' <summary>
    ''' Calculation of Mileage by Train Type (Lines 101 - 111)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub milageByTrainType(ByVal bLeg As Boolean, ByVal lseg As Integer, ByVal car_type As Integer, ByVal railroad As Integer)
        Try

            'L101
            '============================================================
            Try
                iL101 = dMiles

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    iL101 = 0
                End If
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType-L101")
            End Try

            'L102a
            '============================================================
            ' Circuity - L102 is always 1 but actual circuity for a 
            ' car type is used in L106 - Est. of Way Train Miles so we will
            ' set it here
            Try
                If iTotalSegments > 1 Then
                    dL102a = dInterlineCircuity
                Else
                    dL102a = dLocalCircuity
                End If

                ' If single car movement but Rebill, use interline circuity
                If sSegmentType = "RT" Or sSegmentType = "OD" Then
                    dL102a = dInterlineCircuity
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType-L102a")
            End Try

            'L102
            '============================================================
            ' Cicuity is Assumed to be 1 unless segment type IA or IR
            Try
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    iL102 = 0
                Else
                    iL102 = 1
                End If
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType-L102")
            End Try

            'L103
            '============================================================
            ' Actual Miles including Circuity
            Try
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    iL103 = 0
                Else
                    iL103 = iL101 * iL102
                End If
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType-L103")
            End Try

            'L104
            '============================================================
            ' If Unit Train, all miles are unit train miles
            Try
                If sShipmentSize = "TL" Then
                    iL104 = iL101
                End If

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    iL104 = 0
                End If

                If sShipmentSize = "SC" Or sShipmentSize = "MC" Then
                    iL104 = 0
                End If

                If sShipmentSize = "IM" Then
                    iL104 = 0
                End If

                'adjust for seg 1 to cost as a SC movemnet
                If lseg = 1 Then
                    iL104 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType-L104")
            End Try

            'L105
            '============================================================
            ' L105 - Empty Load Ratio
            Try
                If sOwnership = "R" Then
                    'dL105 = dL105R 
                    Dim E2L101C2 As Double = getEcodeValue_CarType("E2", "C2", railroad, car_type)
                    dL105 = E2L101C2

                End If

                If sOwnership = "P" Or sOwnership = "T" Then
                    'dL105 = dL105P 
                    Dim E2L101C3 As Double = getEcodeValue_CarType("E2", "C3", railroad, car_type)
                    dL105 = E2L101C3
                End If

                If lseg = 3 Then
                    If sShipmentSize = "TL" Then
                        dL105 = 2
                    End If
                End If

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL105 = 0
                End If
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType-L105")
            End Try

            'L250 
            '============================================================
            ' needs to be created ahead of time - as it is part of the calculation in L106
            Try
                Select Case (sSegmentType)
                    Case "OT"
                        iL250 = 2
                    Case "OD"
                        iL250 = 1
                    Case "RT"
                        iL250 = 1
                    Case "RD"
                        iL250 = 0
                    Case "IA"
                        iL250 = 2
                    Case "IR"
                        iL250 = 1
                End Select
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType-L250")
            End Try

            'L106 (Way Train Miles Estimate)
            '============================================================
            ' The use of a circuity factor for the car type L102a is 
            ' inconstent and probably an oversight in the costing program 
            ' which was fixed in the interactive program - this does impact costs!

            ' Circuity is only needed when you don't know the actual route 
            ' miles - since we always know this information, it makes no sense 
            ' to include circuity in the calculations
            Try
                Dim E2L201C1 As Double = getEcodeValue("E2", "C1", railroad, "201")
                Dim E2L118C7 As Double = getEcodeValue("E2", "C7", railroad, "118")
                Dim E2L118C4 As Double = getEcodeValue("E2", "C4", railroad, "118")

                dL106 = (E2L201C1 / E2L118C7 * dL102a / E2L118C4) * iL250

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL106 = 0
                End If

                'adjust for seg 1 to ignore TL modifier
                If lseg <> 1 Then
                    If sShipmentSize = "TL" Then
                        dL106 = 0
                    End If
                End If

                If sShipmentSize = "IM" Then
                    dL106 = 0
                End If
                If sSegmentType = "RD" Then
                    dL106 = 0
                End If

                '*See L107 calculation for a late adjustment to dL106

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType-L106")
            End Try

            'L107 - Through Train Miles
            '============================================================
            ' If L107 < 0, then all miles is way train miles
            Try
                dL107 = iL103 - dL106

                If iL101 = 1 And sSegmentType <> "IR" Then
                    dL107 = iL101 * dL102a - dL106
                End If

                If sSegmentType = "RD" Then
                    dL107 = iL101 * iL102 - dL106
                End If

                If sShipmentSize = "TL" Then
                    dL107 = 0
                End If

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL107 = 0
                End If

                'This is the late adjustment to dL106
                If (sShipmentSize = "SC" And dL107 < 0) Or (sShipmentSize = "MC" And dL107 < 0) Then
                    dL106 = iL101 * iL102
                    dL107 = 0
                End If

                'adjust for seg 1 to cost as a SC movemnet
                If lseg = 1 Then

                    dL107 = iL103 - dL106

                    If sSegmentType = "RD" Then
                        dL107 = iL101 * iL102 - dL106
                    End If

                    If sSegmentType = "IA" Or sSegmentType = "IR" Then
                        dL107 = 0
                    End If

                    If dL107 < 0 Then
                        dL106 = iL101 * iL102
                        dL107 = 0
                    End If

                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType-L107")
            End Try

            'L108 - Total Unit Train Miles including Empty Return
            '============================================================
            Try

                dL108 = iL104 * dL105

                If sShipmentSize = "IM" Then
                    dL108 = 0
                End If

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL108 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType-L108")
            End Try

            'L109 - Total Way Train Miles including Empty Return
            '============================================================
            Try

                dL109 = dL105 * dL106

                If sShipmentSize = "IM" Then
                    dL109 = 0
                End If

                If sShipmentSize = "TL" Then
                    dL109 = 0
                End If

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL109 = 0
                End If

                'adjust for seg 1 to cost as a SC movemnet
                If lseg = 1 Then
                    dL109 = dL105 * dL106
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType-L109")
            End Try

            'L110 - Total Through Train Miles including Empty Return
            '============================================================
            Try

                dL110 = dL105 * dL107

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL110 = 0
                End If

                If sShipmentSize = "TL" Then
                    dL110 = 0
                End If

                If (dL107 < 0 And sShipmentSize = "SC") Or (dL107 < 0 And sShipmentSize = "MC") Then
                    dL110 = 0
                End If

                'adjust for seg 1 to cost as a SC movemnet
                If lseg = 1 Then
                    dL110 = dL105 * dL107
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType-L110")
            End Try

            'L111 = Unit + Through + Way Train Miles (All miles include empty return
            '============================================================
            Try

                dL111 = dL108 + dL109 + dL110

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL111 = 0
                End If

                'If (iL101 = 1 And sSegmentType = "OT") Or (iL101 = 1 And sSegmentType = "OD") Then
                '    dL111 = dL102a * iL101 * dL105
                'End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType-L111")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "milageByTrainType")
        End Try
    End Sub

    ''' <summary>
    ''' Calculation of Car-Mile Costs - Other than Clerical   (lines 201 - 211)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub carMileCosts(ByVal bLeg As Boolean, ByVal railroad As Integer, ByVal car_type As Integer, ByVal u_tc_units As Integer, ByVal tonscar As Integer)

        Try

            'L201 - Expanded Cars (Cars Variable in Waybill)
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    iL201 = 0
                Else
                    iL201 = iNumCarsExpanded
                End If
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carMileCosts-201")
            End Try

            'L202/L202a - Average TCU's from Sch. 755 (Always use originating carrier's TCU - L202)
            '============================================================
            If iSegmentNumber = 1 Then

                'first get the current railroad (STB)
                'Dim rr() = dtRailroads.Select("AARID = " & iRailroadNumber.ToString())
                'Dim RR_ID As Integer = rr(0)("RR_ID")
                'Dim RR_Region As Integer = rr(0)("REGION_ID")
                'If RR_ID = 0 Then
                '    If RR_Region = 4 Then
                '        RR_ID = 8
                '    Else
                '        RR_ID = 9
                '    End If
                'End If

                dL202a = getEcodeValue("E2", "C1", iRailroadNumber, "202")

                'now set the initial value for l202a
                'TODO: Discuss moving this to a table
                'Select Case (RR_ID)
                '    Case 1 : dL202a = 4.22
                '    Case 2 : dL202a = 3.93
                '    Case 3 : dL202a = 4.34
                '    Case 4 : dL202a = 6.48
                '    Case 5 : dL202a = 3.23
                '    Case 6 : dL202a = 2.31
                '    Case 7 : dL202a = 5.2
                '    Case 8 : dL202a = 4.12
                '    Case 9 : dL202a = 5.76
                'End Select
            End If

            Try
                If sShipmentSize = "IM" Then
                    dL202 = dL202a
                Else
                    dL202 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carMileCosts-202")
            End Try


            'L203 - Number of TCUs
            '============================================================
            Try

                'Pulling Exp. Factor for L203 - however, this value should be u_tc_units (u_tc_units = tc_units / exp_factor_th)
                Dim tofc_cars As Double

                If sShipmentSize = "IM" Then
                    tofc_cars = u_tc_units / dL202a
                Else
                    tofc_cars = 0
                End If

                If tofc_cars < 1 Then
                    tofc_cars = 1
                Else
                    tofc_cars = tofc_cars
                End If

                If sShipmentSize = "IM" Then
                    dL203 = u_tc_units * iExpantionFactor
                Else
                    dL203 = 0
                End If

                'Assumed Way to Est. No. of Cars - CT 47 is a 2 Level Flat Car"
                If car_type = 12 And (sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD") Then
                    dL203 = 0.5 * tonscar * iNumCars
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carMileCosts-203")
            End Try

            'L204 - TCU Freight Cars
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    If Double.IsNaN(dL203 / dL202) Or Double.IsInfinity(dL203 / dL202) Then
                        dL204 = 0.0
                    Else
                        dL204 = dL203 / dL202
                    End If

                    If dL204 < 1 Then
                        dL204 = 1
                    End If
                Else
                    dL204 = 0
                End If



            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carMileCosts-204")
            End Try

            'L205 - Empty Return Miles: Key MW Variable - Scaled Back by 1,000
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    dL205 = dL204 * dL111
                Else
                    dL205 = iL201 * dL111
                End If

                'scale it back
                dL205 = dL205 / 1000

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL205 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carMileCosts-L205")
            End Try

            'L206
            '============================================================
            Try
                Dim E1L102C1 As Double = getEcodeValue("E1", "C1", railroad, "102")
                dL206 = E1L102C1

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carMileCosts-L206")
            End Try

            'L207
            '============================================================
            Try
                dL207 = dL205 * dL206
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carMileCosts-L207")
            End Try

            'L208
            '============================================================
            Try
                Dim E1L102C2 As Double = getEcodeValue("E1", "C2", railroad, "102")
                dL208 = E1L102C2
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carMileCosts-L208")
            End Try

            'L209
            '============================================================
            Try
                dL209 = dL205 * dL208
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carMileCosts-L209")
            End Try

            'L210
            '============================================================
            Try
                Dim E1L102C3 As Double = getEcodeValue("E1", "C3", railroad, "102")
                dL210 = E1L102C3
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carMileCosts-L210")
            End Try

            'L211
            '============================================================
            Try
                dL211 = dL205 * dL210
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carMileCosts-L211")
            End Try


        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carMileCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Calculation of Gross Ton-Mile Costs (lines 212 - 225)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub grossTonMileCosts(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer, ByVal tons As Integer)

        Try

            'L212 = Tare weight (tons) based on car type
            '============================================================
            Try
                'dL212 = avg_tare_weight * 1
                Dim E2L101C1 As Double = getEcodeValue_CarType("E2", "C1", railroad, car_type)
                dL212 = E2L101C1

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL212 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "grossTonMileCosts-L212")
            End Try

            'L213
            '============================================================
            Try

                If sShipmentSize = "IM" Then
                    dL213 = dL111 * dL204 * dL212
                Else
                    dL213 = dL111 * iL201 * dL212
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "grossTonMileCosts-L213")
            End Try

            'L214, L215, L216
            '============================================================
            Try
                'CAR TYPE 46 - TOFC/COFC - INTERMODAL
                'CAR TYPE 45 - Refrigerator Cars-Non-Mechanical
                'CAR TYPE 44 - Refrigerator Cars-Mechanical

                If sShipmentSize = "IM" And car_type = 11 Then
                    Dim E2L204C1 As Double = getEcodeValue("E2", "C1", railroad, "204")
                    dL214 = E2L204C1
                End If

                If car_type = 9 Then
                    Dim E2L204C1 As Double = getEcodeValue("E2", "C1", railroad, "204")
                    dL214 = E2L204C1
                End If

                If car_type = 10 Then
                    Dim E2L203C1 As Double = getEcodeValue("E2", "C1", railroad, "203")
                    dL214 = E2L203C1
                End If

                If sShipmentSize = "IM" And car_type = 11 Then
                    Dim E2L207C1 As Double = getEcodeValue("E2", "C1", railroad, "207")
                    dL215 = E2L207C1
                End If

                If sShipmentSize = "IM" And car_type > 46 Then
                    'Probably Unnecessary - but Washburn does it
                    Dim E2L209C1 As Double = getEcodeValue("E2", "C1", railroad, "209")
                    dL215 = E2L209C1
                End If

                If sShipmentSize <> "IM" Then
                    dL215 = 0
                End If

                dL216 = iL103 * dL203 * dL214 * dL215

                'Making sure L214, L215, L216 are 0 for non-intermodal movements - yes this is redundant
                If sShipmentSize <> "IM" Then
                    dL214 = 0
                    dL215 = 0
                    dL216 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "grossTonMileCosts-L214-216")
            End Try

            'L217- Tons are backed out, actual tons are not used - key variable for Loss and Damage
            '============================================================
            Try

                iL217 = tons

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "grossTonMileCosts-L217")
            End Try

            'L218
            '============================================================
            Try
                iL218 = iL103 * iL217
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    iL218 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "grossTonMileCosts-L218")
            End Try

            'L219 - Gross Ton Miles* Key Variable
            '============================================================
            Try
                dL219 = dL213 + dL216 + iL218
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL219 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "grossTonMileCosts-L219")
            End Try

            'L220
            '============================================================
            ' Sometimes etable values are multiplied by 1 - 
            ' this was necessary when Paul first merged the Waybill and E-Table data as 
            ' certain numbers were changed to text - however, this problem should be resolved.  
            Try
                Dim E1L101C1 As Double = getEcodeValue("E1", "C1", railroad, "101")
                dL220 = E1L101C1 * 1
                'If mt <= 4 Then L220 = E1L101C1 'I am a little unclear about why this is here?
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL220 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "grossTonMileCosts-L220")
            End Try

            'L221
            '============================================================
            Try
                dL221 = dL219 * dL220

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "grossTonMileCosts-L221")
            End Try

            'L222
            '============================================================
            Try
                Dim E1L101C2 As Double = getEcodeValue("E1", "C2", railroad, "101")
                dL222 = E1L101C2
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL222 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "grossTonMileCosts-L222")
            End Try

            'L223
            '============================================================
            Try
                dL223 = dL219 * dL222

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "grossTonMileCosts-L223")
            End Try

            'L224
            '============================================================
            Try
                Dim E1L101C3 As Double = getEcodeValue("E1", "C3", railroad, "101")
                dL224 = E1L101C3
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL224 = 0
                End If
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "grossTonMileCosts-L224")
            End Try

            'L225
            '============================================================
            Try
                dL225 = dL219 * dL224
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "grossTonMileCosts-L225")
            End Try


        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "grossTonMileCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Calculation of Locomotive Unit-Miles (lines 226 - 248)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub locomotiveUnitMiles(ByVal bLeg As Boolean, ByVal lseg As Integer, ByVal railroad As Integer)

        Try

            'L226
            '============================================================
            Try
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL226 = 0
                Else
                    Dim E2L208C1 As Double = getEcodeValue("E2", "C1", railroad, "208")
                    dL226 = E2L208C1
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L226")
            End Try

            'L227
            '============================================================
            Try
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL227 = 0
                Else
                    Dim E2L209C1 As Double = getEcodeValue("E2", "C1", railroad, "209")
                    dL227 = E2L209C1
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L227")
            End Try

            'L228
            '============================================================
            Try
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL228 = 0
                Else
                    Dim E2L210C1 As Double = getEcodeValue("E2", "C1", railroad, "210")
                    dL228 = E2L210C1
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L228")
            End Try

            'L229 - Unit Train Loco Miles
            '============================================================
            Try
                dL229 = dL108 * dL226
                If sShipmentSize = "IM" Then
                    dL229 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L229")
            End Try

            'L230
            '============================================================
            Try
                dL230 = dL109 * dL227
                If sShipmentSize = "IM" Then
                    dL230 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L230")
            End Try

            'L231 - Through Train Loco Miles
            '============================================================
            Try
                dL231 = dL110 * dL228
                If sShipmentSize = "IM" Then
                    dL231 = dL111 * dL228
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L231")
            End Try

            'L232
            '============================================================
            Try
                Dim E2L211C1 As Double = getEcodeValue("E2", "C1", railroad, "211")
                dL232 = E2L211C1 * dL105

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L232")
            End Try

            'L233
            '============================================================
            Try
                Dim E2L212C1 As Double = getEcodeValue("E2", "C1", railroad, "212")
                dL233 = E2L212C1 * dL105

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L233")
            End Try

            'L234
            '============================================================
            Try
                Dim E2L213C1 As Double = getEcodeValue("E2", "C1", railroad, "213")
                dL234 = E2L213C1 * dL105

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L234")
            End Try

            'L235 - Gross Tons Cars & Contents
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    dL235 = (dL204 * dL212 * dL105) + (dL203 * dL214 * dL215) + iL217
                Else
                    dL235 = (iL201 * dL212 * dL105) + iL217
                End If

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL235 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L235")
            End Try

            'L236 - Percent of Unit Train Tonnage
            '============================================================
            Try
                If sShipmentSize = "TL" Then
                    If Double.IsNaN(dL235 / dL232) Or Double.IsInfinity(dL235 / dL232) Then
                        dL236 = 0.0
                    Else
                        dL236 = dL235 / dL232
                    End If

                End If
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL236 = 0
                End If
                If sShipmentSize = "IM" Then
                    dL236 = 0
                End If
                If sShipmentSize = "MC" Then
                    dL236 = 0
                End If
                If sShipmentSize = "SC" Then
                    dL236 = 0
                End If

                'adjust for seg 1 to cost as a SC movemnet
                If lseg = 1 Then
                    dL236 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L236")
            End Try

            'L237 - Percent of Way Train Tonnag
            '============================================================
            Try
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL237 = 0
                Else
                    If Double.IsNaN(dL235 / dL233) Or Double.IsInfinity(dL235 / dL233) Then
                        dL237 = 0.0
                    Else
                        dL237 = dL235 / dL233
                    End If
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L237")
            End Try

            'L238
            '============================================================
            Try
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL238 = 0
                Else
                    If Double.IsNaN(dL235 / dL234) Or Double.IsInfinity(dL235 / dL234) Then
                        dL238 = 0.0
                    Else
                        dL238 = dL235 / dL234
                    End If
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L238")
            End Try

            'L239
            '============================================================
            Try
                dL239 = 0

                If dL236 = 0 Then
                    dL239 = 0
                Else
                    dL239 = dL229 * dL236
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L239")
            End Try

            'L240
            '============================================================
            Try
                dL240 = dL230 * dL237

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L240")
            End Try

            'L241
            '============================================================
            Try
                dL241 = dL231 * dL238

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L241")
            End Try

            'L242 - Total Shipment LUM (Allocated)
            '============================================================
            Try
                dL242 = dL239 + dL240 + dL241

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L242")
            End Try

            'L243
            '============================================================
            Try
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    Dim E1L105C1 As Double = getEcodeValue("E1", "C1", railroad, "105")
                    dL243 = E1L105C1
                Else
                    dL243 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L243")
            End Try

            'L244
            '============================================================
            Try
                If sSegmentType = "IR" Then
                    dL244 = 0
                Else
                    dL244 = dL242 * dL243
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L244")
            End Try

            'L245
            '============================================================
            Try
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    Dim E1L105C2 As Double = getEcodeValue("E1", "C2", railroad, "105")
                    dL245 = E1L105C2
                Else
                    dL245 = 0
                End If
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L245")
            End Try

            'L246
            '============================================================
            Try
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    dL246 = dL242 * dL245
                Else
                    dL246 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L246")
            End Try

            'L247
            '============================================================
            Try
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    Dim E1L105C3 As Double = getEcodeValue("E1", "C3", railroad, "105")
                    dL247 = E1L105C3
                Else
                    dL247 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L247")
            End Try

            'L248
            '============================================================
            Try
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    dL248 = dL242 * dL247
                Else
                    dL248 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles-L248")
            End Try


        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "locomotiveUnitMiles")
        End Try
    End Sub

    ''' <summary>
    ''' Calculation of Carload and Clerical Costs (lines 250 - 268)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub carloadsAndClericalCosts(ByVal bLeg As Boolean, ByVal lSeg As Integer, ByVal railroad As Integer)

        Try

            'L250
            '============================================================
            ' This is still a bit hinky... iL205 was previously set in the 
            ' milageByTrainType function because it was needed for eariler 
            ' costing.  I am re-doing it here because Paul did, and because
            ' this is where someone would come to edit it.  If you edit this
            ' statement, remember to edit the statement in the milageByTrainType
            ' function.  (Long term we may want to move this to function that is
            ' called in both places, or something else less awkward.
            Try
                Select Case (sSegmentType)
                    Case "OT"
                        iL250 = 2
                    Case "OD"
                        iL250 = 1
                    Case "RT"
                        iL250 = 1
                    Case "RD"
                        iL250 = 0
                    Case "IA"
                        iL250 = 2
                    Case "IR"
                        iL250 = 1
                End Select

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L250")
            End Try

            'L251 - CLOT for IA, IR and Intermodal - Key Variable
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    dL251 = dL204 * iL250
                End If
                If sSegmentType = "IA" Then
                    dL251 = iL201 * iL250
                End If
                If sSegmentType = "IR" Then
                    dL251 = iL201 * iL250
                End If
                If sShipmentSize = "SC" And (sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD") Then
                    dL251 = 0
                End If
                If sShipmentSize = "MC" And (sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD") Then
                    dL251 = 0
                End If
                If sShipmentSize = "TL" And (sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD") Then
                    dL251 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L251")
            End Try

            'L252 - CLOT for OT, RT, RD, and OD Movements
            '============================================================
            Try
                dL252 = iL201 * iL250
                If sShipmentSize = "IM" Then
                    dL252 = 0
                End If
                If sSegmentType = "IA" Then
                    dL252 = 0
                End If
                If sSegmentType = "IR" Then
                    dL252 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L252")
            End Try

            'L253
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    dL253 = dL204
                Else
                    dL253 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L253")
            End Try

            'L254 - Carloads Not Handled
            '============================================================
            Try
                If sShipmentSize = "SC" Or sShipmentSize = "MC" Or sShipmentSize = "TL" Then
                    dL254 = iL201
                End If
                If sShipmentSize = "IM" Then
                    dL254 = 0
                End If
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL254 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L254")
            End Try

            'L255
            '============================================================
            Try
                Dim E1L110C1 As Double = getEcodeValue("E1", "C1", railroad, "110")
                dL255 = E1L110C1

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L255")
            End Try

            'L256
            '============================================================
            Try
                dL256 = dL205 * dL255

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L256")
            End Try

            'L257
            '============================================================
            Try
                Dim E1L109C1 As Double = getEcodeValue("E1", "C1", railroad, "109")

                'If sShipmentSize = "SC" Then dL257 = E1L109C1
                dL257 = E1L109C1

                'Efficiency Adjustments - Station/Clerical Costs
                If lSeg = 3 Then
                    If sShipmentSize = "MC" Or sShipmentSize = "TL" Then
                        dL257 = ((0.75) + (0.25 / iNumCars)) * E1L109C1
                    End If

                    If bLeg Then
                        If sShipmentSize = "IM" And iNumCars >= 25 Then
                            Dim iTCUCars As Integer = Int((iNumCars - 1) / 4)
                            dL257 = ((0.75) + (0.25 / iTCUCars)) * E1L109C1
                        End If
                    Else
                        If bAdjustLine257 Then
                            If sShipmentSize = "IM" And iNumCars >= 25 Then
                                Dim iTCUCars As Integer = Math.Round(dL204, MidpointRounding.AwayFromZero)
                                dL257 = ((0.75) + (0.25 / iTCUCars)) * E1L109C1 ' for lagacy replace iTCUCars with l204 rounded up
                            End If
                        Else
                            If sShipmentSize = "IM" And iNumCars >= 25 Then
                                Dim iTCUCars As Integer = Int((iNumCars - 1) / 4)
                                dL257 = ((0.75) + (0.25 / iTCUCars)) * E1L109C1
                            End If
                        End If
                    End If
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L257")
            End Try

            'L258 is the basis for the Station Clerical Portion of the Add-On
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    dL258 = dL251 * dL257
                Else
                    dL258 = dL252 * dL257
                End If

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL258 = dL251 * dL257
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L258")
            End Try

            'L259
            '============================================================
            Try
                Dim E1L107C1 As Double = getEcodeValue("E1", "C1", railroad, "107")
                dL259 = E1L107C1

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L259")
            End Try

            'L260
            '============================================================
            Try
                dL260 = dL254 * dL259
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L260")
            End Try

            'L261
            '============================================================
            Try
                Dim E1L108C1 As Double = getEcodeValue("E1", "C1", railroad, "108")
                dL261 = E1L108C1
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L261")
            End Try

            'L262
            '============================================================
            Try
                dL262 = dL252 * dL261

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L262")
            End Try

            'L263
            '============================================================
            Try
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL263 = 0
                Else
                    Dim E1L106C1 As Double = getEcodeValue("E1", "C1", railroad, "106")
                    dL263 = E1L106C1
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L263")
            End Try

            'L264
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    dL264 = dL253 * dL263
                Else
                    dL264 = dL254 * dL263
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L264")
            End Try

            'L265
            '============================================================
            Try
                Dim E1L106C2 As Double = getEcodeValue("E1", "C2", railroad, "106")
                dL265 = E1L106C2

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L265")
            End Try

            'L266
            '============================================================
            Try
                dL266 = dL254 * dL265

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L266")
            End Try

            'L267
            '============================================================
            Try
                Dim E1L106C3 As Double = getEcodeValue("E1", "C3", railroad, "106")
                dL267 = E1L106C3

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L267")
            End Try

            'L268
            '============================================================
            Try
                dL268 = dL254 * dL267

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts-L268")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carloadsAndClericalCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Calculation of Train-Mile Costs (lines 269 - 284 (Crew Wages) and lines 285 - 290 (Other Expenses)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub trainMileCostsCrewWagesOther(ByVal bLeg As Boolean, ByVal railroad As Integer)

        Try

            'L269
            '============================================================
            Try
                If sSegmentType = "IR" Then
                    dL269 = 0
                Else
                    dL269 = dL108
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L269")
            End Try

            'L270
            '============================================================
            Try
                dL270 = dL109 * dL237

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L270")
            End Try

            'L271
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    dL271 = dL111 * dL238
                Else
                    dL271 = dL110 * dL238
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L271")
            End Try

            'L272
            '============================================================
            Try
                dL272 = dL269 + dL270 + dL271

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L272")
            End Try

            'L273, L274, and L275 
            '============================================================
            ' These are always zero - this must be due to numbers which 
            ' are no longer used.  Also, this is redundant because the 
            ' Refresh() function allready sets these.
            Try
                dL273 = 0
                dL274 = 0
                dL275 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L273")
            End Try


            'L276
            '============================================================
            Try
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL276 = 0
                Else
                    Dim E2L218C1 As Double = getEcodeValue("E2", "C1", railroad, "218")
                    dL276 = E2L218C1
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L276")
            End Try

            'L277
            '============================================================
            ' Not sure why this is not just set to 1 we just garuenteed that 
            ' dL273 was = 0 in a direct assignment...
            Try
                If dL273 = 0 Then
                    dL277 = 1
                Else
                    If Double.IsNaN(dL273 / dL276) Or Double.IsInfinity(dL273 / dL276) Then
                        dL277 = 0
                    Else
                        dL277 = dL273 / dL276
                    End If
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L277")
            End Try

            'L278
            '============================================================
            ' Not sure why this is not just set to 1 we just garuenteed that 
            ' dL274 was = 0 in a direct assignment...
            Try
                If dL274 = 0 Then
                    dL278 = 1
                Else
                    If Double.IsNaN(dL274 / dL276) Or Double.IsInfinity(dL274 / dL276) Then
                        dL278 = 0.0
                    Else
                        dL278 = dL274 / dL276
                    End If
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L278")
            End Try

            'L279
            '============================================================
            ' Not sure why this is not just set to 1 we just garuenteed that 
            ' dL275 was = 0 in a direct assignment...
            Try
                If dL275 = 0 Then
                    dL279 = 1
                Else
                    If Double.IsNaN(dL275 / dL276) Or Double.IsInfinity(dL275 / dL276) Then
                        dL279 = 0.0
                    Else
                        dL279 = dL275 / dL276
                    End If
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L279")
            End Try

            'L280
            '============================================================
            ' I don't understand why we multiply an expanded value by the 
            ' expansion factor for Trainload/Unit Train Movements, but 
            ' Washburn did this for some reason..
            Try
                Dim E1L104C1 As Double = getEcodeValue("E1", "C1", railroad, "104")

                If sShipmentSize = "TL" Then
                    dL280 = E1L104C1 * iExpantionFactor
                ElseIf sShipmentSize = "IM" Then
                    dL280 = E1L104C1
                Else
                    dL280 = E1L104C1
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L280")
            End Try

            'L281
            '============================================================
            Try
                dL281 = dL269 * dL277 * dL280

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L281")
            End Try

            'L282
            '============================================================
            Try
                dL282 = dL270 * dL278 * dL280

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L282")
            End Try

            'L283
            '============================================================
            Try
                dL283 = dL271 * dL279 * dL280

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L283")
            End Try

            'L284
            '============================================================
            Try
                dL284 = dL281 + dL282 + dL283

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L284")
            End Try

            ' UGLYNESS
            '============================================================
            ' This is Redundat and should be removed once we validate that 
            ' these values are 0 for IA and IR movements 
            ' TODO: ADD THIS CODE TO THE INDIVIDUAL LINE NUMBERS
            Try
                If sSegmentType = "IR" Or sSegmentType = "IA" Then
                    dL277 = 0
                    dL278 = 0
                    dL279 = 0
                    dL280 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-UGLYNESS")
            End Try

            'L285
            '============================================================
            Try
                If sSegmentType = "IR" Or sSegmentType = "IA" Then
                    dL285 = 0
                Else
                    Dim E1L103C1 As Double = getEcodeValue("E1", "C1", railroad, "103")
                    dL285 = E1L103C1
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L285")
            End Try

            'L286
            '============================================================
            Try
                dL286 = dL272 * dL285

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L286")
            End Try

            'L287
            '============================================================
            Try
                If sSegmentType = "IR" Or sSegmentType = "IA" Then
                    dL287 = 0
                Else
                    Dim E1L103C2 As Double = getEcodeValue("E1", "C2", railroad, "103")
                    dL287 = E1L103C2
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L287")
            End Try

            'L288
            '============================================================
            Try
                dL288 = dL272 * dL287

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L288")
            End Try

            'L289
            '============================================================
            Try
                If sSegmentType = "IR" Or sSegmentType = "IA" Then
                    dL289 = 0
                Else
                    Dim E1L103C3 As Double = getEcodeValue("E1", "C3", railroad, "103")
                    dL289 = E1L103C3
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L289")
            End Try

            'L290
            '============================================================
            Try
                dL290 = dL272 * dL289

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther-L290")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "trainMileCostsCrewWagesOther")
        End Try
    End Sub

    ''' <summary>
    ''' Calculation of Industry, Interchange and Intertrain and Intratrain Switching Cost (lines 301 – 320)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub industryInterchangeIntertrain_IntertrainSwitching(ByVal bLeg As Boolean, ByVal lSeg As Integer, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            'L301 - Current Year Switch Engine Minutes - Key Variable and Efficiency Adjustment is Applied
            '============================================================
            Try
                'L301 = cyear_SEM_per_Switch*1
                Dim E2L101C25 As Double = getEcodeValue_CarType("E2", "C25", railroad, car_type)
                dL301 = E2L101C25

                'Adjusting L301 - Industry Switches
                If lSeg = 3 Then
                    If sShipmentSize = "TL" Or sShipmentSize = "IM" Then dL301 = dL301 * 0.25
                    If sShipmentSize = "MC" Then dL301 = dL301 * 0.5
                End If

                If sSegmentType = "RD" And sShipmentSize <> "SC" Then dL301 = E2L101C25 * 1
                If sSegmentType = "IA" Or sSegmentType = "IR" Then dL301 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L301")
            End Try

            'L302 
            '============================================================
            Try
                'L302 = cyear_SEM_per_interchg_switch*1
                Dim E2L101C26 As Double = getEcodeValue_CarType("E2", "C26", railroad, car_type)
                dL302 = E2L101C26

                'Adjusting L302 (Interchange)
                If lSeg = 3 Then
                    If sShipmentSize = "TL" Or sShipmentSize = "IM" Then dL302 = dL302 * 0.5
                End If

                If sSegmentType = "IA" Or sSegmentType = "IR" Then dL302 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L302")
            End Try

            'L303 
            '============================================================
            Try
                'L303 = cyear_intra_intertrain_switch*1
                Dim E2L101C29 As Double = getEcodeValue_CarType("E2", "C29", railroad, car_type)
                dL303 = E2L101C29

                If lSeg = 3 Then
                    If sShipmentSize = "TL" Then
                        dL303 = 0
                    End If

                    If sShipmentSize = "IM" And iNumCars >= 25 Then
                        dL303 = 0
                    End If
                End If

                If sSegmentType = "IA" Then dL303 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L303")
            End Try

            'L304
            '============================================================
            ' L304 is already in data set - Spotted Pull Ratio for this Car Type
            ' Another Weird Car Type Value - Is there a manual change in the program? - Did not find - 
            Try

                dL304 = getEcodeValue_CarType("E2", "C8", railroad, car_type)

                If car_type = 17 And sShipmentSize <> "IM" Then
                    dL304 = 2
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L304")
            End Try

            'L305 - Key Variable - Industry Switches
            '============================================================
            ' Some question on how industry switches are calculated for IA and IR movements 
            ' Right now, we get equivalent values but use a slightly different formula than 
            ' washburn, who divides Interchanges for IA and IR movements by U_Cars
            ' if st = 6 then L305 =0
            ' if st = 7 then L305 =0
            Try
                dL305 = dL252 * dL304

                If sShipmentSize = "SC" Or sShipmentSize = "MC" Or sShipmentSize = "TL" Then
                    dL305 = dL304 * iNumCars * iExpantionFactor * iL250
                End If

                If sSegmentType = "IA" Then
                    dL305 = dL304 * iExpantionFactor
                End If

                If sSegmentType = "IR" Then
                    dL305 = dL304 * iExpantionFactor
                End If

                If sShipmentSize = "IM" Then
                    dL305 = iL250 * dL204 * dL304
                End If

                If sSegmentType = "RD" Then
                    dL305 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L305")
            End Try

            'L306 
            '============================================================
            Try
                'L306 = avg_miles_interchange_events*1
                Dim E2L101C24 As Double = getEcodeValue_CarType("E2", "C24", railroad, car_type)
                dL306 = E2L101C24

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL306 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L306")
            End Try

            'L307
            '============================================================
            ' Number of interchange events is 2 for "RD", 1 for "OD and "RT", 0 for "OT", 
            ' movements have interchanges computed on a mileage basis
            '
            ' Does it equal 2 if rounded miles < 8 and also unit?
            ' Or if number of carriers is 2, it's also unit? is it 2
            Try

                If sSegmentType = "RD" Then
                    dL307 = 2
                End If
                If sSegmentType = "OD" Then
                    dL307 = 1
                End If
                If sSegmentType = "RT" Then
                    dL307 = 1
                End If
                If sSegmentType = "OT" Then
                    dL307 = 0
                End If
                If sSegmentType = "IA" Then
                    dL307 = 0
                End If
                If sSegmentType = "IR" Then
                    dL307 = 0
                End If

                If Not bLeg Then
                    If bAdjustLine307 Then
                        '-1 if prev AARID = current AARID
                        If iSegmentNumber > 1 Then
                            If aRRID(iSegmentNumber - 1) = aRRID(iSegmentNumber) Then
                                dL307 = dL307 - 1
                            End If
                        End If

                        'TODO -1 if next AARIC = current AARID 
                        If iSegmentNumber < 7 Then
                            If aRRID(iSegmentNumber + 1) = aRRID(iSegmentNumber) Then
                                dL307 = dL307 - 1
                            End If
                        End If
                    End If
                End If
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L307")
            End Try

            'L308 - Number of Interchanges - Key Variable
            '============================================================
            ' IA and IR Interchanges are estimated in L323 and L324 - I think 
            ' Washburn forgot this in the Interactive Program
            Try
                If sShipmentSize = "IM" Then
                    dL308 = dL105 * dL307 * dL204
                Else
                    dL308 = dL105 * dL307 * iL201
                End If

                If sSegmentType = "IR" Or sSegmentType = "IA" Then
                    dL308 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L308")
            End Try

            'L309 ave miles between I&I sw event
            '============================================================
            Try
                'L309 = avg_miles_IandI_Switch * 1
                Dim E2L101C23 As Double = getEcodeValue_CarType("E2", "C23", railroad, car_type)
                dL309 = E2L101C23

                If sSegmentType = "IR" Or sSegmentType = "IA" Then
                    dL309 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L309")
            End Try

            'L310
            '============================================================
            Try
                If Double.IsNaN(dL205 / dL309) Or Double.IsInfinity(dL205 / dL309) Then
                    dL310 = 0.0
                Else
                    dL310 = (dL205 / dL309)
                End If

                If sSegmentType = "IR" Or sSegmentType = "IA" Then
                    dL310 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L310")
            End Try

            'L311
            '============================================================
            Try
                dL311 = dL301 * dL305

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L311")
            End Try

            'L312
            '============================================================
            Try
                dL312 = dL302 * dL308

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L312")
            End Try

            'L313
            '============================================================
            ' Scaling - Paul messed around with the scaling to get the right numbers - 
            ' there is some redudnancy in the scaling as we move down - but since the 
            ' program works, he did not want to mess with the scaling - will do so at a later time
            Try
                dL313 = (dL303 * dL310) * 1000

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L313")
            End Try

            'L314
            '============================================================
            Try
                dL314 = dL311 + dL312 + dL313

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L314")
            End Try

            'L315
            '============================================================
            Try
                Dim E1L111C1 As Double = getEcodeValue("E1", "C1", railroad, "111")
                dL315 = E1L111C1

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L315")
            End Try

            'L316
            '============================================================
            Try
                dL316 = dL314 * dL315

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L316")
            End Try

            'L317
            '============================================================
            Try
                Dim E1L111C2 As Double = getEcodeValue("E1", "C2", railroad, "111")
                dL317 = E1L111C2

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L317")
            End Try

            'L318
            '============================================================
            Try
                dL318 = dL314 * dL317

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L318")
            End Try

            'L319
            '============================================================
            Try
                Dim E1L111C3 As Double = getEcodeValue("E1", "C3", railroad, "111")
                dL319 = E1L111C3

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L319")
            End Try

            'L320
            '============================================================
            Try
                dL320 = dL314 * dL319

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching-L320")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "industryInterchangeIntertrain_IntertrainSwitching")
        End Try
    End Sub

    ''' <summary>
    ''' Calculation of Intraterminal and Interterminal Switching Costs  (lines 321 - 334)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub intraterminal_IntraterminalSwitching(ByVal bLeg As Boolean, ByVal lseg As Integer, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            'L321
            '============================================================
            Try
                If sSegmentType = "IA" Then
                    dL321 = iNumCarsExpanded
                Else
                    dL321 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L321")
            End Try

            'L322
            '============================================================
            Try
                If sSegmentType = "IR" Then
                    dL322 = dL251
                Else
                    dL322 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L322")
            End Try

            'L323 - Cars-Intraterm Switching Including Empty
            '============================================================
            Try
                dL323 = dL304 * dL321

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L323")
            End Try

            'L324 - Cars Interterm Switching including Empty
            '============================================================
            Try
                dL324 = dL304 * dL322

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L324")
            End Try

            '' Industry Switch Event's Test for IA/IR 
            ''============================================================
            'if st  = 6 then industry_switch_eventsp  = L323/u_cars;
            'if st  = 7 then industry_switch_eventsp  = L324/u_cars;
            'if st  < 6 then industry_switch_eventsp  = L305;

            'L325 - SEM per intraterminal switch - C27
            '============================================================
            ' Note the SEM Efficiency Adjustment for IA and IR - the .125 is not documented
            Try
                If sSegmentType = "IA" Then
                    'L325 = cyear_SEM_Per_intraterm_switch (C27)
                    Dim E2L101C27 As Double = getEcodeValue_CarType("E2", "C27", railroad, car_type)
                    dL325 = E2L101C27
                Else
                    dL325 = 0
                End If

                If lseg = 3 Then
                    If sSegmentType = "IA" And sShipmentSize = "MC" Then
                        dL325 = dL325 * 0.5
                    End If
                    If sSegmentType = "IA" And sShipmentSize = "TL" Then
                        dL325 = dL325 * 0.125
                    End If
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L325")
            End Try

            'L326 - SEM per interterminal switch - C28
            '============================================================
            ' Note the SEM Efficiency Adjustment for IA and IR - the .125 is not documented
            Try
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    'L326 = cyear_SEM_Per_interterm_switch (C28)
                    Dim E2L101C28 As Double = getEcodeValue_CarType("E2", "C28", railroad, car_type)
                    dL326 = E2L101C28
                Else
                    dL326 = 0
                End If

                If lseg = 3 Then
                    If sSegmentType = "IA" And sShipmentSize = "MC" Then
                        dL326 = dL326 * 0.5
                    End If
                    If sSegmentType = "IA" And sShipmentSize = "TL" Then
                        dL326 = dL326 * 0.125
                    End If
                    If sSegmentType = "IR" And sShipmentSize = "MC" Then
                        dL326 = dL326 * 0.5
                    End If
                    If sSegmentType = "IR" And sShipmentSize = "TL" Then
                        dL326 = dL326 * 0.125
                    End If
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L326")
            End Try

            'L327
            '============================================================
            Try
                dL327 = dL323 * dL325

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L327")
            End Try

            'L328
            '============================================================
            Try
                dL328 = dL324 * dL326

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L328")
            End Try

            'L329
            '============================================================
            Try
                dL329 = dL315 * dL327

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L329")
            End Try

            'L330
            '============================================================
            Try
                dL330 = dL317 * dL327

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L330")
            End Try

            'L331
            '============================================================
            Try
                dL331 = dL319 * dL327

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L331")
            End Try

            'L332
            '============================================================
            Try
                dL332 = dL315 * dL328

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L332")
            End Try

            'L333
            '============================================================
            Try
                dL333 = dL317 * dL328

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L333")
            End Try

            'L334
            '============================================================
            Try
                dL334 = dL319 * dL328

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching-L334")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "intraterminal_IntraterminalSwitching")
        End Try
    End Sub

    ''' <summary>
    ''' Private Line Car Rentals (lines 401 - 405)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub privateLineCarRentals(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            '401
            '============================================================
            Try
                If sOwnership = "P" Or sOwnership = "T" Then
                    dL401 = dL205 * 1000
                Else
                    dL401 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "privateLineCarRentals-401")
            End Try

            '403
            '============================================================
            Try
                If sOwnership = "P" Or sOwnership = "T" Then
                    Dim E2L219C1 As Double = getEcodeValue("E2", "C1", railroad, "219")
                    dL403 = E2L219C1
                Else
                    dL403 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "privateLineCarRentals-403")
            End Try

            '404
            '============================================================
            Try
                If sOwnership = "P" Or sOwnership = "T" Then
                    'L404 = cm_lease_ucost_pown * 1
                    Dim E1L201C13 As Double = getEcodeValue_CarType("E1", "C13", railroad, car_type)
                    dL404 = E1L201C13
                Else
                    dL404 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "privateLineCarRentals-404")
            End Try

            '402 - we need to set this out of order as it uses L404
            '============================================================
            Try
                dL402 = dL404

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "privateLineCarRentals-402")
            End Try

            'Out of Line adjustment for segmentType of IA or IR
            '============================================================
            Try
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL402 = 0
                    dL403 = 0
                    dL404 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "privateLineCarRentals-IA/IR adjustment")
            End Try

            '405
            '============================================================
            Try
                dL405 = dL401 * dL404

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "privateLineCarRentals-405")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "privateLineCarRentals")
        End Try
    End Sub

    ''' <summary>
    ''' Calculation of Railroad Owned Cars Mileage Costs (Lines 406-431)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub railroadOwnedCars_MileageCosts(ByVal bLeg As Boolean, ByVal lSeg As Integer, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            '406
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL406 = dL205
                Else
                    dL406 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-406")
            End Try

            '407
            '============================================================
            ' Always 0 for Waybill Costing Purposes - this is Actual Charges Per Car Mile - 
            ' can be manually entered in Interactive Program
            Try
                dL407 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-407")
            End Try

            '408 - General Overhead Ratio - is E2L219C1
            '============================================================
            Try
                If sOwnership = "R" Then
                    Dim E2L219C1 As Double = getEcodeValue("E2", "C1", railroad, "219")
                    dL408 = E2L219C1
                Else
                    dL408 = 0
                End If

                If sSegmentType = "IA" Then
                    dL408 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-408")
            End Try

            '409 - VC-CM - Total
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL409 = dL406 * dL407 * dL408
                Else
                    dL409 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-409")
            End Try

            '410 = Car days in yard switching service, operating unit cost expense for railroad  owned equipment
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L410 = cm_run_operating_ucost_rrown*1
                    Dim E1L201C1 As Double = getEcodeValue_CarType("E1", "C1", railroad, car_type)
                    dL410 = E1L201C1
                Else
                    dL410 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-410")
            End Try

            '411
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL411 = dL406 * dL410 * 1000
                Else
                    dL411 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-411")
            End Try

            '412 - Car miles in running service, lease unit cost expense for railroad owned  equipment.
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L412= cm_run_lease_ucost_rrown*1
                    Dim E1L201C2 As Double = getEcodeValue_CarType("E1", "C2", railroad, car_type)
                    dL412 = E1L201C2
                Else
                    dL412 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-412")
            End Try

            '413
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL413 = dL406 * dL412 * 1000
                Else
                    dL413 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-413")
            End Try

            '414
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L414 = cm_run_roi_rrown
                    Dim E1L201C3 As Double = getEcodeValue_CarType("E1", "C3", railroad, car_type)
                    dL414 = E1L201C3
                Else
                    dL414 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-414")
            End Try

            '415 - VC-CM(R) - ROI
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL415 = (dL406 * dL414) * 1000
                Else
                    dL415 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-415")
            End Try

            '416 - Industry Switch Event 
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL416 = dL305
                Else
                    dL416 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-416")
            End Try

            '417 - Interchanges
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL417 = dL308
                Else
                    dL417 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-417")
            End Try

            '418 - I&I Train Switch Event
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL418 = dL310 * 1000
                Else
                    dL418 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-418")
            End Try

            '419 - CM(Y)/Industry Switch
            '============================================================
            ' RR Owned Car L419 gets efficiency adjustment
            Try
                'L419 = cm_per_industry_switch*1
                Dim E2L101C17 As Double = getEcodeValue_CarType("E2", "C17", railroad, car_type)
                dL419 = E2L101C17

                If lSeg = 3 Then
                    If sOwnership = "R" And sShipmentSize = "SC" Then
                        dL419 = E2L101C17 * 1
                    End If

                    If sOwnership = "R" And sShipmentSize = "MC" Then
                        dL419 = E2L101C17 * 0.5
                    End If

                    If sOwnership = "R" And sShipmentSize = "TL" Then
                        dL419 = E2L101C17 * 0.5
                    End If

                    If sOwnership = "R" And sShipmentSize = "IM" Then
                        dL419 = E2L101C17 * 1
                    End If

                    If sOwnership = "R" And sSegmentType = "RD" Then
                        dL419 = E2L101C17 * 1
                    End If

                    If sOwnership = "R" And sSegmentType = "RT" Then
                        dL419 = dL419
                    End If

                    If sOwnership = "R" And (sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT") And sShipmentSize = "IM" Then
                        dL419 = dL419 * 0.5
                    End If
                End If

                If sOwnership = "P" Then
                    dL419 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-419")
            End Try

            '420 - CM(Y)/Interchange Switch 
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L420 = cm_per_interchange_swich*1
                    Dim E2L101C18 As Double = getEcodeValue_CarType("E2", "C18", railroad, car_type)
                    dL420 = E2L101C18 * 1
                Else
                    dL420 = 0
                End If

                If lSeg = 3 Then
                    If sOwnership = "R" And (sShipmentSize = "TL" Or sShipmentSize = "IM") Then
                        dL420 = dL420 * 0.5
                    End If
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-420")
            End Try

            '421 - CM(Y)/I&I Switch
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L421 = cm_per_inter_intra_train_switch * 1
                    Dim E2L101C21 As Double = getEcodeValue_CarType("E2", "C21", railroad, car_type)
                    dL421 = E2L101C21
                Else
                    dL421 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-421")
            End Try

            '422 - CM(Y) - Industry
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL422 = dL416 * dL419
                Else
                    dL422 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-422")
            End Try

            '423 - CM(Y) - Interchange
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL423 = dL417 * dL420
                Else
                    dL423 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-423")
            End Try

            '424 - CM(Y) - I&I Train
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL424 = (dL418 * dL421)
                Else
                    dL424 = 0
                End If

                If lSeg = 3 Then
                    If sShipmentSize = "TL" Then
                        dL424 = 0
                    End If
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-424")
            End Try

            '425 - CM(Y) - Total
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL425 = dL422 + dL423 + dL424
                Else
                    dL425 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-425")
            End Try

            '426
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L426 = cm_yswitch_oper_ucost_rrown * 1
                    Dim E1L201C4 As Double = getEcodeValue_CarType("E1", "C4", railroad, car_type)
                    dL426 = E1L201C4
                Else
                    dL426 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-426")
            End Try

            'IA - 409 - 426 = 0 - adding the redundancy to make sure values are zeroed out
            '============================================================
            Try
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL409 = 0
                    dL410 = 0
                    dL411 = 0
                    dL412 = 0
                    dL413 = 0
                    dL414 = 0
                    dL415 = 0
                    dL416 = 0
                    dL417 = 0
                    dL418 = 0
                    dL419 = 0
                    dL420 = 0
                    dL421 = 0
                    dL422 = 0
                    dL423 = 0
                    dL424 = 0
                    dL425 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-IA/IR Recalc")
            End Try

            '427 - VC-CM(Y) - OPR
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL427 = dL426 * dL425
                Else
                    dL427 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-427")
            End Try

            '428
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L428 = cm_yswitch_lease_ucost_rrown * 1
                    Dim E1L201C5 As Double = getEcodeValue_CarType("E1", "C5", railroad, car_type)
                    dL428 = E1L201C5
                Else
                    dL428 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-428")
            End Try

            '429 - VC-CM(Y) - DRL
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL429 = dL425 * dL428
                Else
                    dL429 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-429")
            End Try

            '430
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L430 = cm_yswitch_roi_rrown * 1
                    Dim E1L201C6 As Double = getEcodeValue_CarType("E1", "C6", railroad, car_type)
                    dL430 = E1L201C6
                Else
                    dL430 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-430")
            End Try

            '431 - VC-CM(Y) - ROI
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL431 = dL425 * dL430
                Else
                    dL431 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts-431")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_MileageCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Calculation of Railroad-Owned Car Time Costs (lines 432 - 457)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub railroadOwnedCars_TimeCosts(ByVal bLeg As Boolean, ByVal lSeg As Integer, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            '432 - Actual Charge Per Day - Can be overwritten by user - 0 when costing waybill sample
            '============================================================
            Try
                dL432 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-432")
            End Try

            '433 - Always 0, unless user inputs - this is never the case with Waybill Costing
            '============================================================
            Try
                dL433 = 0

                'TODO: I Really question this code...
                If sOwnership = "P" Or sOwnership = "T" Then
                    dL433 = dL436 * dL451
                Else
                    dL433 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-433")
            End Try

            '434
            '============================================================
            ' not sure why this code is executed after L451 in the original code
            Try
                If sOwnership = "R" Then
                    dL434 = dL408 * dL432 * dL433
                Else
                    dL434 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-434")
            End Try

            '435
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L435 = avg_cm_for_rr_fc_per_day * 1
                    Dim E2L101C22 As Double = getEcodeValue_CarType("E2", "C22", railroad, car_type)
                    dL435 = E2L101C22
                Else
                    dL435 = 0
                End If

                If sSegmentType = "IA" Then
                    dL435 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-435")
            End Try

            '436 - Car Days Running
            '============================================================
            Try
                If sOwnership = "R" Then
                    If Double.IsNaN(dL406 / dL435) Or Double.IsInfinity(dL406 / dL435) Then
                        dL436 = 0.0
                    Else
                        dL436 = (dL406 / dL435)
                    End If
                Else
                    dL436 = 0
                End If

                If sSegmentType = "IA" Then
                    dL436 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-436")
            End Try

            '437
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L437 = cd_run_oprer_ucost_rrown * 1
                    Dim E1L201C7 As Double = getEcodeValue_CarType("E1", "C7", railroad, car_type)
                    dL437 = E1L201C7
                Else
                    dL437 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-437")
            End Try

            '438 - VC-CD(R) - OPR
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL438 = dL436 * dL437 * 1000
                Else
                    dL438 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-438")
            End Try

            '439
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L439 = cd_run_lease_ucost_rrown * 1
                    Dim E1L201C8 As Double = getEcodeValue_CarType("E1", "C8", railroad, car_type)
                    dL439 = E1L201C8
                Else
                    dL439 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-439")
            End Try

            '440 - VC-CD(R) - DRL
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL440 = dL436 * dL439 * 1000
                Else
                    dL440 = 0
                End If

                If sSegmentType = "IA" Then
                    dL440 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-440")
            End Try

            '441
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L441 = cd_run_roi_rrown * 1
                    Dim E1L201C9 As Double = getEcodeValue_CarType("E1", "C9", railroad, car_type)
                    dL441 = E1L201C9
                Else
                    dL441 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-441")
            End Try

            '442 - VC-CD(R) - ROI
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL442 = dL436 * dL441 * 1000
                Else
                    dL442 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-442")
            End Try

            '443 - Gets effiency Adjustments
            '============================================================
            Try
                'L443 = cd_per_industry_switch*1
                Dim E2L101C9 As Double = getEcodeValue_CarType("E2", "C9", railroad, car_type)
                dL443 = E2L101C9

                If lSeg = 3 Then
                    If sOwnership = "R" And sShipmentSize = "SC" Then
                        dL443 = dL443 * 1
                    End If
                    If sOwnership = "R" And sShipmentSize = "MC" Then
                        dL443 = dL443 * 0.5
                    End If
                    If sOwnership = "R" And sShipmentSize = "TL" Then
                        dL443 = dL443 * 0.5
                    End If
                    If sOwnership = "R" And sShipmentSize = "IM" Then
                        dL443 = dL443 * 0.5
                    End If
                    If sOwnership = "R" And sSegmentType = "RD" Then
                        dL443 = E2L101C9 * 1
                    End If
                    If sOwnership = "R" And sShipmentSize = "IM" And sSegmentType = "RT" Then
                        dL443 = E2L101C9 * 0.5
                    End If
                End If

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL443 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-443")
            End Try

            '444 - Gets efficiency Adjustments
            '============================================================
            Try
                'L444 = cd_per_interchange_switch * 1
                Dim E2L101C10 As Double = getEcodeValue_CarType("E2", "C10", railroad, car_type)
                dL444 = E2L101C10

                If lSeg = 3 Then
                    If sOwnership = "R" And (sShipmentSize = "TL" Or sShipmentSize = "IM") Then
                        dL444 = E2L101C10 * 0.5
                    End If
                End If

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL444 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-444")
            End Try

            '445
            '============================================================
            ' If Privately-Owned Car then value is 0, if Railroad-Owned Cars then value = 1,  
            ' if not MT = Unit Train (MT Code = 3) or if MT = intermodal (MT Code = 4)
            ' then E-Table value is scaled by .50. E-Table value is based on Car Type.
            '
            ' L445 is one of those confusing lines which differentiates a Unit Train Movement 
            ' from an Intermodal Movement - This is somewhat inconsistent with EP 431 Sub 2
            Try
                'L445 = cd_per_inter_intra_train_switch * 1
                Dim E2L101C13 As Double = getEcodeValue_CarType("E2", "C13", railroad, car_type)
                dL445 = E2L101C13

                If lSeg = 3 Then
                    If sOwnership = "R" And sShipmentSize = "TL" Then
                        dL445 = dL445 * 0.5
                    End If

                    If sOwnership = "R" And sShipmentSize = "TL" Then
                        dL445 = 0
                    End If
                End If
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-445")
            End Try

            'unnecessary and redundant...
            '============================================================
            Try
                If sOwnership = "P" Or sOwnership = "T" Then
                    dL443 = 0
                    dL444 = 0
                    dL445 = 0
                    dL446 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-unnecessary")
            End Try

            '446
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL446 = dL443 * dL416
                Else
                    dL446 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-446")
            End Try

            '447
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL447 = dL444 * dL417
                Else
                    dL447 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-447")
            End Try

            '448
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL448 = dL445 * dL418
                Else
                    dL448 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-448")
            End Try

            '449 CD(Y) - Per Loading & Unloading for Industry Switch
            '============================================================
            Try
                'L449 = cd_per_load_industry_switch * 1
                Dim E2L101C14 As Double = getEcodeValue_CarType("E2", "C14", railroad, car_type)
                dL449 = E2L101C14

                'L449 Gets Effiency Adjustment
                If lSeg = 3 Then
                    If (sShipmentSize = "MC" Or sShipmentSize = "TL" Or sShipmentSize = "IM") And sOwnership = "R" Then
                        dL449 = dL449 * 0.5
                    End If
                    If sShipmentSize = "SC" And sSegmentType = "RT" Then
                        dL449 = E2L101C14 * 1
                    End If
                    If sShipmentSize = "IM" And sSegmentType = "RT" Then
                        dL449 = E2L101C14 * 0.5
                    End If
                    If sSegmentType = "RD" Then
                        dL449 = E2L101C14 * 1
                    End If
                End If
                If sOwnership = "P" Or sOwnership = "T" Then
                    dL449 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-449")
            End Try

            '450
            '============================================================
            Try
                If sOwnership = "R" And (sShipmentSize = "SC" Or sShipmentSize = "MC" Or sShipmentSize = "TL") Then
                    dL450 = dL252 * dL449
                End If
                If sOwnership = "R" And sShipmentSize = "IM" Then
                    dL450 = dL251 * dL449
                End If
                If sOwnership = "P" Or sOwnership = "T" Then
                    dL450 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-450")
            End Try

            '451 - Car Days (Y) Total
            '============================================================
            Try
                dL451 = dL446 + dL447 + dL448 + dL450

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-451")
            End Try

            '452
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L452 = cd_yswitch_oper_ucost_rrown * 1
                    Dim E1L201C10 As Double = getEcodeValue_CarType("E1", "C10", railroad, car_type)
                    dL452 = E1L201C10

                Else
                    dL452 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-452")
            End Try

            '453
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL453 = dL451 * dL452
                Else
                    dL453 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-453")
            End Try

            '454
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L454 = cd_yswitch_lease_ucost_rrown * 1
                    Dim E1L201C11 As Double = getEcodeValue_CarType("E1", "C11", railroad, car_type)
                    dL454 = E1L201C11
                Else
                    dL454 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-454")
            End Try

            '455
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL455 = dL451 * dL454
                Else
                    dL455 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-455")
            End Try

            '456
            '============================================================
            Try
                If sOwnership = "R" Then
                    'L456 = cd_yswitch_roi_rrown * 1
                    Dim E1L201C12 As Double = getEcodeValue_CarType("E1", "C12", railroad, car_type)
                    dL456 = E1L201C12
                Else
                    dL456 = 0
                End If
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-456")
            End Try

            '457
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL457 = dL451 * dL456
                Else
                    dL457 = 0
                End If
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-457")
            End Try

            'IR/IA zero adjustment (this may not be necessary...
            '============================================================
            Try
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL431 = 0
                    dL432 = 0
                    dL433 = 0
                    dL434 = 0
                    dL435 = 0
                    dL436 = 0
                    dL437 = 0
                    dL438 = 0
                    dL439 = 0
                    dL440 = 0
                    dL441 = 0
                    dL442 = 0
                    dL443 = 0
                    dL444 = 0
                    dL445 = 0
                    dL446 = 0
                    dL447 = 0
                    dL448 = 0
                    dL449 = 0
                    dL450 = 0
                    dL451 = 0
                End If
            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts-IR/IA zero")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_TimeCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Calculation of Railroad-Owned Cars - Accessorial Services Costs (lines 458 - 481)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub railroadOwnedCars_AccessorialServicesCosts(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            '458
            '============================================================
            Try
                'L458 = E1L219C1 / 1000
                Dim E1L219C1 As Double = getEcodeValue("E1", "C1", railroad, "219")
                dL458 = E1L219C1 / 1000

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL458 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-458")
            End Try

            '459
            '============================================================
            Try
                dL459 = dL406 * dL458 * 1000000

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL459 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-459")
            End Try

            '460
            '============================================================
            Try
                'L460	=E1L219C2/1000
                Dim E1L219C2 As Double = getEcodeValue("E1", "C2", railroad, "219")
                dL460 = E1L219C2 / 1000

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL460 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-460")
            End Try

            '461
            '============================================================
            Try
                dL461 = dL406 * dL460 * 1000000

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL461 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-461")
            End Try

            '462
            '============================================================
            Try
                'L462 = E1L219C3 / 1000
                Dim E1L219C3 As Double = getEcodeValue("E1", "C3", railroad, "219")
                dL462 = E1L219C3 / 1000

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL462 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-462")
            End Try

            '463
            '============================================================
            Try
                dL463 = dL406 * dL462 * 1000000

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL463 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-463")
            End Try

            '464
            '============================================================
            Try
                'L464 = E1L219C4
                Dim E1L219C4 As Double = getEcodeValue("E1", "C4", railroad, "219")
                dL464 = E1L219C4

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL464 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-464")
            End Try

            '465
            '============================================================
            ' Note this is re-costed in the next formula - search for L465' 
            Try
                If sSegmentType = "IA" Then
                    dL465 = dL484 * dL464
                ElseIf sSegmentType = "IR" Then
                    dL465 = dL485 * dL464
                Else
                    dL465 = dL425 * dL464
                End If

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL465 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-465")
            End Try

            '466
            '============================================================
            Try
                'L466 = E1L219C5
                Dim E1L219C5 As Double = getEcodeValue("E1", "C5", railroad, "219")
                dL466 = E1L219C5

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL466 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-466")
            End Try

            '467
            '============================================================
            ' Note this is re-costed in the next formula - search for L467' 
            Try
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    dL467 = dL425 * dL466
                End If

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL467 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-467")
            End Try

            '468
            '============================================================
            Try
                'L468 = E1L219C6
                Dim E1L219C6 As Double = getEcodeValue("E1", "C6", railroad, "219")
                dL468 = E1L219C6

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL468 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-468")
            End Try

            '469
            '============================================================
            ' Note this is re-costed in the next formula - search for L469' 
            Try
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    dL469 = dL425 * dL468
                End If

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL469 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-469")
            End Try

            '470
            '============================================================
            Try
                'L470 = E1L219C7
                Dim E1L219C7 As Double = getEcodeValue("E1", "C7", railroad, "219")
                dL470 = E1L219C7

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL470 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-470")
            End Try

            '471
            '============================================================
            Try
                dL471 = dL436 * dL470 * 1000

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL471 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-471")
            End Try

            '472
            '============================================================
            Try
                'L472 = E1L219C8
                Dim E1L219C8 As Double = getEcodeValue("E1", "C8", railroad, "219")
                dL472 = E1L219C8

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL472 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-472")
            End Try

            '473
            '============================================================
            Try
                dL473 = dL436 * dL472 * 1000

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL473 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-473")
            End Try

            '474
            '============================================================
            Try
                'L474 = E1L219C9
                Dim E1L219C9 As Double = getEcodeValue("E1", "C9", railroad, "219")
                dL474 = E1L219C9

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL474 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-474")
            End Try

            '475
            '============================================================
            Try
                dL475 = dL436 * dL474 * 1000

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL475 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-475")
            End Try

            '476
            '============================================================
            Try
                'L476 = E1L219C10
                Dim E1L219C10 As Double = getEcodeValue("E1", "C10", railroad, "219")
                dL476 = E1L219C10

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL476 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-476")
            End Try

            '477
            '============================================================
            ' Note - this is recosted in the next function - search for L477'
            Try
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    dL477 = dL451 * dL476
                End If

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL477 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-477")
            End Try

            '478
            '============================================================
            Try
                'L478 = E1L219C11
                Dim E1L219C11 As Double = getEcodeValue("E1", "C11", railroad, "219")
                dL478 = E1L219C11

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL478 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-478")
            End Try

            '479
            '============================================================
            ' Note - this is recosted in the next function - search for L479'
            Try
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    dL479 = dL451 * dL478
                End If

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL479 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-479")
            End Try

            '480
            '============================================================
            Try
                'L480 = E1L219C12
                Dim E1L219C12 As Double = getEcodeValue("E1", "C12", railroad, "219")
                dL480 = E1L219C12

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL480 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-480")
            End Try

            '481
            '============================================================
            ' Note - this is recosted in the next function - search for (L481'
            Try
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    dL481 = dL451 * dL480
                End If

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL481 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts-481")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_AccessorialServicesCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Railroad-Owned Cars - Intraterminal and Interterminal Switching Costs(lines 482 - 499D)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            '482
            '============================================================
            Try
                'L482 = cm_per_intraterminal_switch * 1
                Dim E2L101C19 As Double = getEcodeValue_CarType("E2", "C19", railroad, car_type)
                dL482 = E2L101C19

                If sSegmentType = "OT" Then
                    dL482 = 0
                End If
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    dL482 = 0
                End If
                If sOwnership = "P" Or sOwnership = "T" Then
                    dL482 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-482")
            End Try

            '483
            '============================================================
            Try
                'L483 = cm_per_interterminal_switch * 1
                Dim E2L101C20 As Double = getEcodeValue_CarType("E2", "C20", railroad, car_type)
                dL483 = E2L101C20

                If sSegmentType = "OT" Then
                    dL483 = 0
                End If
                If sShipmentSize <> "SC" And (sSegmentType = "IA" Or sSegmentType = "IR") Then
                    dL483 = 0
                End If
                If sOwnership = "P" Or sOwnership = "T" Then
                    dL483 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-483")
            End Try

            '484
            '============================================================
            Try
                dL484 = dL323 * dL482

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL484 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-484")
            End Try

            '485
            '============================================================
            Try
                dL485 = dL324 * dL483

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL485 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-485")
            End Try

            'L467' - I really do not like this... But whatever
            '============================================================
            Try
                If sSegmentType = "IA" Then
                    dL467 = dL484 * dL466
                End If
                If sSegmentType = "IR" Then
                    dL467 = dL485 * dL466
                End If

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL467 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-467'")
            End Try

            'L465' - I really do not like this... But whatever
            '============================================================
            Try
                If sSegmentType = "IA" Then
                    dL465 = dL484 * dL464
                ElseIf sSegmentType = "IR" Then
                    dL465 = dL485 * dL464
                Else
                    dL465 = dL425 * dL464
                End If

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL465 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-465'")
            End Try

            'L469' - I really do not like this... But whatever
            '============================================================
            Try
                If sSegmentType = "IA" Then
                    dL469 = dL484 * dL468
                End If
                If sSegmentType = "IR" Then
                    dL469 = dL485 * dL468
                End If

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL469 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-469'")
            End Try


            '486
            '============================================================
            Try
                dL486 = dL426 * dL484

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL486 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-486")
            End Try

            '487
            '============================================================
            Try
                dL487 = dL428 * dL484

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL487 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-487")
            End Try

            '488
            '============================================================
            Try
                dL488 = dL430 * dL484

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL488 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-488")
            End Try

            '489
            '============================================================
            Try
                dL489 = dL426 * dL485

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL489 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-489")
            End Try

            '490
            '============================================================
            Try
                dL490 = dL428 * dL485

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL490 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-490")
            End Try

            '491
            '============================================================
            Try
                dL491 = dL430 * dL485

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL491 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-491")
            End Try

            '492
            '============================================================
            Try
                'L492 = cd_per_intraterminal_switch * 1
                Dim E2L101C11 As Double = getEcodeValue_CarType("E2", "C11", railroad, car_type)
                dL492 = E2L101C11

                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    dL492 = 0
                End If
                If sOwnership = "P" Or sOwnership = "T" Then
                    dL492 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-492")
            End Try

            '493
            '============================================================
            Try
                'L493 = cd_per_load_intraterm_switch * 1
                Dim E2L101C15 As Double = getEcodeValue_CarType("E2", "C15", railroad, car_type)
                dL493 = E2L101C15

                If sOwnership = "IA" Then
                    dL493 = 0
                End If
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    dL493 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-493")
            End Try

            '494
            '============================================================
            Try
                'L494 = cd_per_interterminal_switch*1
                Dim E2L101C12 As Double = getEcodeValue_CarType("E2", "C12", railroad, car_type)
                dL494 = E2L101C12

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL494 = 0
                End If
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    dL494 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-494")
            End Try

            '495
            '============================================================
            Try
                'L495 = cd_per_load_interterm_switch * 1
                Dim E2L101C16 As Double = getEcodeValue_CarType("E2", "C16", railroad, car_type)
                dL495 = E2L101C16

                If sOwnership = "P" Or sOwnership = "T" Then
                    dL495 = 0
                End If
                If sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD" Then
                    dL495 = 0
                End If

                'Why if segment = 4 does L495 = 0? - Washburned? */
                If iSegmentNumber = 4 Then
                    dL495 = 0
                End If

                If sShipmentSize = "TL" And (sSegmentType = "OT" Or sSegmentType = "OD" Or sSegmentType = "RT" Or sSegmentType = "RD") Then
                    dL495 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-495")
            End Try

            '496
            '============================================================
            Try
                dL496 = (dL323 * dL492) + (dL321 * dL493)

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-496")
            End Try

            '497
            '============================================================
            Try
                dL497 = (dL324 * dL494) + (dL322 * dL495)

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-497")
            End Try

            'L477' - I really do not like this... But whatever
            '============================================================
            Try
                If sSegmentType = "IA" Then
                    dL477 = dL496 * dL476
                End If
                If sSegmentType = "IR" Then
                    dL477 = dL497 * dL476
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-477'")
            End Try

            'L479' - I really do not like this... But whatever
            '============================================================
            Try
                If sSegmentType = "IA" Then
                    dL479 = dL496 * dL478
                End If
                If sSegmentType = "IR" Then
                    dL479 = dL497 * dL478
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-479'")
            End Try

            'L481' - I really do not like this... But whatever
            '============================================================
            Try
                If sSegmentType = "IA" Then
                    dL481 = dL496 * dL480
                End If
                If sSegmentType = "IR" Then
                    dL481 = dL497 * dL480
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-481'")
            End Try

            '498
            '============================================================
            Try
                dL498 = dL452 * dL496

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-498")
            End Try

            '499
            '============================================================
            Try
                dL499 = dL454 * dL496

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-499")
            End Try

            '499A
            '============================================================
            Try
                dL499A = dL456 * dL496

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-499A")
            End Try

            '499B
            '============================================================
            Try
                dL499B = dL452 * dL497

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-499B")
            End Try

            '499C
            '============================================================
            Try
                dL499C = dL454 * dL497

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-499C")
            End Try

            '499D
            '============================================================
            Try
                dL499D = dL456 * dL497

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts-499D")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Lake Transfer Service Costs (lines 501 - 507)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub lakeTransferServiceCosts(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            'L501 - Lake Transfer Ton Miles - Always Zero
            '============================================================
            Try
                dL501 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "lakeTransferServiceCosts-501")
            End Try

            'L502
            '============================================================
            Try
                'L502 = E1L112C1
                Dim E1L112C1 As Double = getEcodeValue("E1", "C1", railroad, "112")
                dL502 = E1L112C1

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "lakeTransferServiceCosts-502")
            End Try

            'L503
            '============================================================
            Try
                dL503 = dL501 * dL502

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "lakeTransferServiceCosts-503")
            End Try

            'L504
            '============================================================
            Try
                'L504 = E1L112C2
                Dim E1L112C2 As Double = getEcodeValue("E1", "C2", railroad, "112")
                dL504 = E1L112C2

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "lakeTransferServiceCosts-504")
            End Try

            'L505
            '============================================================
            Try
                dL505 = dL501 * dL504

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "lakeTransferServiceCosts-505")
            End Try

            'L506
            '============================================================
            Try
                'L506 = E1L112C3
                Dim E1L112C3 As Double = getEcodeValue("E1", "C3", railroad, "112")
                dL506 = E1L112C3

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "lakeTransferServiceCosts-506")
            End Try

            'L507
            '============================================================
            Try
                dL507 = dL501 * dL506

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "lakeTransferServiceCosts-507")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "lakeTransferServiceCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Coal Terminal Service Costs (lines 508 - 514)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub coalTerminalServiceCosts(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            'L508 - Coal Terminal - Always 0
            '============================================================
            Try
                dL508 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "coalTerminalServiceCosts-508")
            End Try

            'L509
            '============================================================
            Try
                'L509 = E1L113C1
                Dim E1L113C1 As Double = getEcodeValue("E1", "C1", railroad, "113")
                dL509 = E1L113C1

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL509 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "coalTerminalServiceCosts-509")
            End Try

            'L510
            '============================================================
            Try
                dL510 = dL508 * dL509

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "coalTerminalServiceCosts-510")
            End Try

            'L511
            '============================================================
            Try
                'L511 = E1L113C2
                Dim E1L113C2 As Double = getEcodeValue("E1", "C2", railroad, "113")
                dL511 = E1L113C2

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL511 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "coalTerminalServiceCosts-511")
            End Try

            'L512
            '============================================================
            Try
                dL512 = dL508 * dL511

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "coalTerminalServiceCosts-512")
            End Try

            'L513
            '============================================================
            Try
                'L513 = E1L113C3
                Dim E1L113C3 As Double = getEcodeValue("E1", "C3", railroad, "113")
                dL513 = E1L113C3

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL513 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "coalTerminalServiceCosts-513")
            End Try

            'L514
            '============================================================
            Try
                dL514 = dL508 * dL513

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "coalTerminalServiceCosts-514")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "coalTerminalServiceCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Ore Terminal Service Costs (lines 515 - 521) 
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub oreTerminalServiceCosts(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            'L515 - Ore Terminal - Alway 0
            '============================================================
            Try
                dL515 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "oreTerminalServiceCosts-515")
            End Try

            'L516
            '============================================================
            Try
                'L516 = E1L114C1
                Dim E1L114C1 As Double = getEcodeValue("E1", "C1", railroad, "114")
                dL516 = E1L114C1

                If sShipmentSize = "IM" Then
                    dL516 = 0
                End If

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL516 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "oreTerminalServiceCosts-516")
            End Try

            'L517
            '============================================================
            Try
                dL517 = dL515 * dL516

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "oreTerminalServiceCosts-517")
            End Try

            'L518
            '============================================================
            Try
                'L518 = E1L114C2
                Dim E1L114C2 As Double = getEcodeValue("E1", "C2", railroad, "114")
                dL518 = E1L114C2

                If sShipmentSize = "IM" Then
                    dL518 = 0
                End If

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL518 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "oreTerminalServiceCosts-518")
            End Try

            'L519
            '============================================================
            Try
                dL519 = dL515 * dL518

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "oreTerminalServiceCosts-519")
            End Try

            'L520
            '============================================================
            Try
                'L520 = E1L114C3
                Dim E1L114C3 As Double = getEcodeValue("E1", "C3", railroad, "114")
                dL520 = E1L114C3

                If sShipmentSize = "IM" Then
                    dL520 = 0
                End If

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL520 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "oreTerminalServiceCosts-520")
            End Try

            'L521
            '============================================================
            Try
                dL521 = dL515 * dL520

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "oreTerminalServiceCosts-521")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "oreTerminalServiceCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Other Marine Terminal Costs (lines 522 - 528) 
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub otherMarineTerminalCosts(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            'L522 - Other Marine Terminals - Always 0
            '============================================================
            Try
                dL522 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "otherMarineTerminalCosts-522")
            End Try

            'L523
            '============================================================
            Try
                'L523 = E1L115C1
                Dim E1L115C1 As Double = getEcodeValue("E1", "C1", railroad, "115")
                dL523 = E1L115C1

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL523 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "otherMarineTerminalCosts-523")
            End Try

            'L524
            '============================================================
            Try
                dL524 = dL522 * dL523

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "otherMarineTerminalCosts-524")
            End Try

            'L525
            '============================================================
            Try
                'L525 = E1L115C2
                Dim E1L115C2 As Double = getEcodeValue("E1", "C2", railroad, "115")
                dL525 = E1L115C2

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL525 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "otherMarineTerminalCosts-525")
            End Try

            'L526
            '============================================================
            Try
                dL526 = dL522 * dL525

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "otherMarineTerminalCosts-526")
            End Try

            'L527
            '============================================================
            Try
                'L527 = E1L115C3
                Dim E1L115C3 As Double = getEcodeValue("E1", "C3", railroad, "115")
                dL527 = E1L115C3

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL527 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "otherMarineTerminalCosts-527")
            End Try

            'L528
            '============================================================
            Try
                dL528 = dL522 * dL527

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "otherMarineTerminalCosts-528")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "otherMarineTerminalCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Motor Vehicle Unit Loading and Unloading Costs  (lines 529 - 531)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub motorVehicleUnitLoading_UnloadingCosts(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer, ByVal tonscar As Double, ByVal u_cars As Double)

        Try

            'L529
            '============================================================
            Try
                If car_type = 12 And sSegmentType = "OT" Then
                    dL529 = 0.5 * (tonscar / u_cars) * iNumCarsExpanded * 2
                End If
                If car_type = 12 And sSegmentType = "OD" Then
                    dL529 = 0.5 * (tonscar / u_cars) * iNumCarsExpanded
                End If
                If car_type = 12 And sSegmentType = "RT" Then
                    dL529 = 0.5 * (tonscar / u_cars) * iNumCarsExpanded
                End If
                If car_type = 12 And sSegmentType = "RD" Then
                    dL529 = 0
                End If
                If car_type = 12 And sSegmentType = "IA" Then
                    dL529 = 0.5 * (tonscar / u_cars) * iNumCarsExpanded * 2
                End If
                If car_type = 12 And sSegmentType = "IR" Then
                    dL529 = 0.5 * (tonscar / u_cars) * iNumCarsExpanded
                End If

                Try
                    If dL529 = "." Then dL529 = 0
                Catch
                End Try

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "motorVehicleUnitLoading_UnloadingCosts-529")
            End Try

            'L530
            '============================================================
            Try
                If car_type = 12 Then
                    Dim E1L121C1 As Double = getEcodeValue("E1", "C1", railroad, "121")
                    dL530 = E1L121C1
                End If

                If sSegmentType = "RD" Then
                    dL530 = 0
                End If

                Try
                    If dL530 = "." Then dL530 = 0
                Catch
                End Try

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "motorVehicleUnitLoading_UnloadingCosts-530")
            End Try

            'L531
            '============================================================
            Try
                If car_type = 12 Then
                    dL531 = dL529 * dL530
                End If

                If sSegmentType = "RD" Then
                    dL531 = 0
                End If

                Try
                    If dL531 = "." Then dL531 = 0
                Catch
                End Try

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "motorVehicleUnitLoading_UnloadingCosts-531")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "motorVehicleUnitLoading_UnloadingCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Car Refrigerated Protective Service Cost (lines 532 - 534)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub carRegrigeratedProtectiveServiceCost(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            'L532
            '============================================================
            Try
                If car_type = 9 Then
                    dL532 = iL103 * iL201
                End If

                Try
                    If dL532 = "." Then dL532 = 0
                Catch
                End Try

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carRegrigeratedProtectiveServiceCost-532")
            End Try

            'L533
            '============================================================
            Try
                If car_type = 9 Then
                    Dim E1L116C1 As Double = getEcodeValue("E1", "C1", railroad, "116")
                    dL533 = E1L116C1
                End If

                Try
                    If dL533 = "." Then dL533 = 0
                Catch
                End Try

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carRegrigeratedProtectiveServiceCost-533")
            End Try

            'L534
            '============================================================
            Try
                If car_type = 9 Then
                    dL534 = dL532 * dL533
                End If

                Try
                    If dL534 = "." Then dL534 = 0
                Catch
                End Try

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carRegrigeratedProtectiveServiceCost-534")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "carRegrigeratedProtectiveServiceCost")
        End Try
    End Sub

    ''' <summary>
    ''' Loss and Damage Claim Payment Cost (lines 535 - 537)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub lossAndDamageClaimPaymentCost(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer, ByVal STCC As Long)

        Try

            'L535
            '============================================================
            Try
                dL535 = iL217

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "lossAndDamageClaimPaymentCost-535")
            End Try

            'L536
            '============================================================
            Try
                Dim CommodityIdx As Integer = SetCommodityIdx(STCC)
                Dim E1P3L101C1 As Double = getEcodeValue("E1", "C1", railroad, (300 + CommodityIdx).ToString())
                dL536 = E1P3L101C1

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "lossAndDamageClaimPaymentCost-536")
            End Try

            'L537
            '============================================================
            Try
                dL537 = (dMiles / dTotalMiles) * dL536 * dL535

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "lossAndDamageClaimPaymentCost-537")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "lossAndDamageClaimPaymentCost")
        End Try
    End Sub

    ''' <summary>
    ''' TCU's Loading and Unloading (Tie and Untie) Costs (lines 540 - 547)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub TCUsLoading_Unloading(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            'L540
            '============================================================
            Try
                dL540 = dL203

                If sShipmentSize <> "IM" Then
                    dL540 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUsLoading_Unloading-540")
            End Try

            'L541
            '============================================================
            Try
                dL541 = dL540 * iL250

                If sShipmentSize <> "IM" Then
                    dL541 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUsLoading_Unloading-541")
            End Try

            'L542
            '============================================================
            Try
                Dim E1L120C1 As Double = getEcodeValue("E1", "C1", railroad, "120")
                dL542 = E1L120C1

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL542 = 0
                End If

                If sShipmentSize <> "IM" Then
                    dL542 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUsLoading_Unloading-542")
            End Try

            'L543
            '============================================================
            Try
                dL543 = dL541 * dL542

                If sShipmentSize <> "IM" Then
                    dL543 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUsLoading_Unloading-543")
            End Try

            'L544
            '============================================================
            Try
                Dim E1L120C2 As Double = getEcodeValue("E1", "C2", railroad, "120")
                dL544 = E1L120C2

                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL544 = 0
                End If

                If sShipmentSize <> "IM" Then
                    dL544 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUsLoading_Unloading-544")
            End Try

            'L545
            '============================================================
            Try
                dL545 = dL541 * dL544

                If sShipmentSize <> "IM" Then
                    dL545 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUsLoading_Unloading-545")
            End Try

            'L546
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    Dim E1L120C3 As Double = getEcodeValue("E1", "C3", railroad, "120")
                    dL546 = E1L120C3
                Else
                    dL546 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUsLoading_Unloading-546")
            End Try

            'L547
            '============================================================
            Try
                dL547 = dL541 * dL546

                If sShipmentSize <> "IM" Then
                    dL547 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUsLoading_Unloading-547")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUsLoading_Unloading")
        End Try
    End Sub

    ''' <summary>
    ''' TCU Ownership and Protective Service Cost (lines 548 - 666)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub TCUOwnershipProtectiveServiceCost(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            'L548
            '============================================================
            Try
                dL548 = iL103 * dL203 * dL215

                If sShipmentSize <> "IM" Then
                    dL548 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-548")
            End Try

            'L549
            '============================================================
            Try
                Dim E2L205C1 As Double = getEcodeValue("E2", "C1", railroad, "205")

                If Double.IsNaN(dL548 / E2L205C1) Or Double.IsInfinity(dL548 / E2L205C1) Then
                    dL549 = 0.0
                Else
                    dL549 = dL548 / E2L205C1
                End If

                If sShipmentSize <> "IM" Then
                    dL549 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-549")
            End Try

            'L550
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    Dim E2L206C1 As Double = getEcodeValue("E2", "C1", railroad, "206")
                    dL550 = E2L206C1
                Else
                    dL550 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-550")
            End Try

            'L551
            '============================================================
            Try
                dL551 = dL203 * iL250 * dL550

                If sShipmentSize <> "IM" Then
                    dL551 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-551")
            End Try

            'L552
            '============================================================
            Try
                dL552 = dL549 + dL551

                If sShipmentSize <> "IM" Then
                    dL552 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-552")
            End Try

            'L553
            '============================================================
            Try
                Dim E1L118C1 As Double = getEcodeValue("E1", "C1", railroad, "118")
                dL553 = E1L118C1

                'The WayBill Data doesn't contain suffecient data to determine this value
                dL553 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-553")
            End Try

            'L554
            '============================================================
            Try
                dL554 = dL552 * dL553

                If dTOFC_Plan_Code = 1 Then dL554 = 0
                If dTOFC_Plan_Code = 3 Then dL554 = 0
                If dTOFC_Plan_Code = 4 Then dL554 = 0
                If dTOFC_Plan_Code = 5.3 Then dL554 = 0
                If dTOFC_Plan_Code = 5.4 Then dL554 = 0
                If dTOFC_Plan_Code = 5.5 Then dL554 = 0
                If dTOFC_Plan_Code = 5.1 Then dL554 = 0

                If sOwnership = "P" Or sOwnership = "T" Then dL554 = 0

                If sShipmentSize <> "IM" Then
                    dL554 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-554")
            End Try

            'L555
            '============================================================
            Try
                Dim E1L118C2 As Double = getEcodeValue("E1", "C2", railroad, "118")
                dL555 = E1L118C2

                If sSegmentType = "IA" Or sSegmentType = "IR" Then dL555 = 0

                If sShipmentSize <> "IM" Then
                    dL555 = 0
                End If

                'The WayBill Data doesn't contain suffecient data to determine this value
                dL555 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-555")
            End Try

            'L556
            '============================================================
            Try
                dL556 = dL552 * dL555

                If dTOFC_Plan_Code = 1 Then dL556 = 0
                If dTOFC_Plan_Code = 3 Then dL556 = 0
                If dTOFC_Plan_Code = 4 Then dL556 = 0
                If dTOFC_Plan_Code = 5.3 Then dL556 = 0
                If dTOFC_Plan_Code = 5.4 Then dL556 = 0
                If dTOFC_Plan_Code = 5.5 Then dL556 = 0
                If dTOFC_Plan_Code = 2.25 Then dL556 = 0
                If dTOFC_Plan_Code = 5.1 Then dL556 = 0

                If sOwnership = "P" Or sOwnership = "T" Then dL556 = 0

                If sShipmentSize <> "IM" Then
                    dL556 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-556")
            End Try

            'L557
            '============================================================
            Try
                Dim E1L118C3 As Double = getEcodeValue("E1", "C3", railroad, "118")
                dL557 = E1L118C3

                If sSegmentType = "IA" Or sSegmentType = "IR" Then dL557 = 0

                If sShipmentSize <> "IM" Then
                    dL557 = 0
                End If

                'The WayBill Data doesn't contain suffecient data to determine this value
                dL557 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-557")
            End Try

            'L558
            '============================================================
            Try
                dL558 = dL552 * dL557

                If dTOFC_Plan_Code = 1 Then dL558 = 0
                If dTOFC_Plan_Code = 3 Then dL558 = 0
                If dTOFC_Plan_Code = 4 Then dL558 = 0
                If dTOFC_Plan_Code = 5.3 Then dL558 = 0
                If dTOFC_Plan_Code = 5.4 Then dL558 = 0
                If dTOFC_Plan_Code = 5.5 Then dL558 = 0
                If dTOFC_Plan_Code = 5.1 Then dL558 = 0
                If dTOFC_Plan_Code = 2.25 Then dL558 = 0

                If sOwnership = "P" Or sOwnership = "T" Then dL558 = 0

                If sShipmentSize <> "IM" Then
                    dL558 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-558")
            End Try

            'L559
            '============================================================
            Try
                Dim E1L117C1 As Double = getEcodeValue("E1", "C1", railroad, "117")
                dL559 = E1L117C1

                If sSegmentType = "IA" Or sSegmentType = "IR" Then dL559 = 0

                If sShipmentSize <> "IM" Then
                    dL559 = 0
                End If

                'The WayBill Data doesn't contain suffecient data to determine this value
                dL559 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-559")
            End Try

            'L560
            '============================================================
            Try
                dL560 = dL552 * dL559

                If dTOFC_Plan_Code = 1 Then dL560 = 0
                If dTOFC_Plan_Code = 3 Then dL560 = 0
                If dTOFC_Plan_Code = 4 Then dL560 = 0
                If dTOFC_Plan_Code = 5.3 Then dL560 = 0
                If dTOFC_Plan_Code = 5.4 Then dL560 = 0
                If dTOFC_Plan_Code = 5.5 Then dL560 = 0
                If dTOFC_Plan_Code = 5.1 Then dL560 = 0

                If sOwnership = "P" Or sOwnership = "T" Then dL560 = 0

                If sShipmentSize <> "IM" Then
                    dL560 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-560")
            End Try

            'L561
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    Dim E1L119C1 As Double = getEcodeValue("E1", "C1", railroad, "119")
                    dL561 = E1L119C1
                Else
                    dL561 = 0
                End If

                If sShipmentSize <> "IM" Then
                    dL561 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-561")
            End Try

            'L562
            '============================================================
            Try
                dL562 = dL552 * dL561

                If dTOFC_Plan_Code = 1 Then dL562 = 0
                If dTOFC_Plan_Code = 3 Then dL562 = 0
                If dTOFC_Plan_Code = 4 Then dL562 = 0
                If dTOFC_Plan_Code = 5.3 Then dL562 = 0
                If dTOFC_Plan_Code = 5.4 Then dL562 = 0
                If dTOFC_Plan_Code = 5.5 Then dL562 = 0

                If dTOFC_Plan_Code = 2.25 Then
                    dL562 = dL552 * dL561
                End If

                If sShipmentSize <> "IM" Then
                    dL562 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-562")
            End Try

            'L563
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    Dim E1L119C2 As Double = getEcodeValue("E1", "C2", railroad, "119")
                    dL563 = E1L119C2
                Else
                    dL563 = 0
                End If

                If sShipmentSize <> "IM" Then
                    dL563 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-563")
            End Try

            'L564
            '============================================================
            Try
                dL564 = dL552 * dL563

                If dTOFC_Plan_Code = 1 Then dL564 = 0
                If dTOFC_Plan_Code = 3 Then dL564 = 0
                If dTOFC_Plan_Code = 4 Then dL564 = 0
                If dTOFC_Plan_Code = 5.3 Then dL564 = 0
                If dTOFC_Plan_Code = 5.4 Then dL564 = 0
                If dTOFC_Plan_Code = 5.5 Then dL564 = 0

                If sShipmentSize <> "IM" Then
                    dL564 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-564")
            End Try

            'L565
            '============================================================
            Try
                If sShipmentSize = "IM" Then
                    Dim E1L119C3 As Double = getEcodeValue("E1", "C3", railroad, "119")
                    dL565 = E1L119C3
                Else
                    dL565 = 0
                End If

                If sShipmentSize <> "IM" Then
                    dL565 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-565")
            End Try

            'L566
            '============================================================
            Try
                dL566 = dL552 * dL565

                If dTOFC_Plan_Code = 1 Then dL566 = 0
                If dTOFC_Plan_Code = 3 Then dL566 = 0
                If dTOFC_Plan_Code = 4 Then dL566 = 0
                If dTOFC_Plan_Code = 5.3 Then dL566 = 0
                If dTOFC_Plan_Code = 5.4 Then dL566 = 0
                If dTOFC_Plan_Code = 5.5 Then dL566 = 0

                If sShipmentSize <> "IM" Then
                    dL566 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost-566")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUOwnershipProtectiveServiceCost")
        End Try
    End Sub

    ''' <summary>
    ''' TCU Pickup and Delivery Costs (lines 570 - 572)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub TCUPickupDelieveryCosts(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            'L570-572 This code was so tangled, that I did not seperate it.
            '============================================================
            Try

                Dim E1L122C1 As Double = getEcodeValue("E1", "C1", railroad, "122")
                dL571 = E1L122C1
                dL572 = dL570 * dL571


                If dTOFC_Plan_Code = 1 Then dL570 = 0
                If dTOFC_Plan_Code = 1 Then dL571 = 0

                If dTOFC_Plan_Code = 2 Then dL570 = dL203 * iL250

                If dTOFC_Plan_Code = 2.25 And sSegmentType = "OT" Then dL570 = dL203
                If dTOFC_Plan_Code = 2.25 And sSegmentType = "OD" Then dL570 = dL203

                If dTOFC_Plan_Code = 2.25 And sSegmentType = "RT" Then
                    dL570 = 0
                    dL571 = 0
                End If

                If dTOFC_Plan_Code = 2.25 And sSegmentType = "RD" Then
                    dL570 = 0
                    dL571 = 0
                End If

                If dTOFC_Plan_Code = 2.5 Then dL570 = 0
                If dTOFC_Plan_Code = 3 Then dL570 = 0
                If dTOFC_Plan_Code = 4 Then dL570 = 0
                If dTOFC_Plan_Code = 5.1 Then dL570 = 0



                If dTOFC_Plan_Code = 5.2 And sSegmentType = "OT" Then dL570 = dL203

                If dTOFC_Plan_Code = 5.2 And sSegmentType = "OD" Then
                    dL570 = 0
                    dL571 = 0
                End If

                If dTOFC_Plan_Code = 5.2 And sSegmentType = "RT" Then dL570 = dL203

                If dTOFC_Plan_Code = 5.2 And sSegmentType = "RD" Then
                    dL570 = 0
                    dL571 = 0
                End If

                If dTOFC_Plan_Code = 5.3 And sSegmentType = "OT" Then
                    dL570 = iL250 * dL203
                End If

                If dTOFC_Plan_Code = 5.3 And sSegmentType = "OD" Then dL570 = dL203
                If dTOFC_Plan_Code = 5.3 And sSegmentType = "RT" Then dL570 = dL203

                If dTOFC_Plan_Code = 5.3 And sSegmentType = "RD" Then
                    dL570 = 0
                    dL571 = 0
                End If

                If dTOFC_Plan_Code = 5.4 And sSegmentType = "OT" Then dL570 = dL203
                If dTOFC_Plan_Code = 5.4 And sSegmentType = "OD" Then dL570 = dL203

                If dTOFC_Plan_Code = 5.4 And sSegmentType = "RT" Then
                    dL570 = 0
                    dL571 = 0
                End If

                If dTOFC_Plan_Code = 5.4 And sSegmentType = "RD" Then
                    dL570 = 0
                    dL571 = 0
                End If

                If dTOFC_Plan_Code = 5.5 And sSegmentType = "OT" Then dL570 = dL203

                If dTOFC_Plan_Code = 5.5 And sSegmentType = "OD" Then
                    dL570 = 0
                    dL571 = 0
                End If

                If dTOFC_Plan_Code = 5.5 And sSegmentType = "RT" Then dL570 = dL203

                If dTOFC_Plan_Code = 5.5 And sSegmentType = "RD" Then
                    dL570 = 0
                    dL571 = 0
                End If

                'after all that it seems we just re-assign the original values???
                dL571 = E1L122C1
                dL572 = dL570 * dL571

                If dTOFC_Plan_Code = 1 Then dL572 = 0
                If dTOFC_Plan_Code = 5.1 Then dL572 = 0

                If sShipmentSize <> "IM" Then
                    dL570 = 0
                    dL571 = 0
                    dL572 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUPickupDelieveryCosts-570-572")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "TCUPickupDelieveryCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Jurisdictional Add-On Costs (lines 573 – 587)
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub jurisdictionalAddOnCosts(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            'L573
            '============================================================
            Try

                'If sSegmentType = "IR" or If sSegmentType = "IA" Then dL573 = 0
                If sSegmentType = "IA" Then
                    dL573 = dL323 / iNumCars
                ElseIf sSegmentType = "IR" Then
                    dL573 = dL324 / iNumCars
                Else
                    dL573 = dL305
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-573")
            End Try

            'L574
            '============================================================
            Try

                If sOwnership = "R" Then
                    dL574 = getEcodeValue("E2", "C1", railroad, "301")
                Else
                    dL574 = getEcodeValue("E2", "C2", railroad, "301")
                End If

                'IA IR adjustment
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL574 = getEcodeValue("E2", "C2", railroad, "301")
                End If


            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-574")
            End Try

            'L575
            '============================================================
            Try
                dL575 = dL573 * dL574
                If sShipmentSize <> "SC" Then dL575 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-575")
            End Try

            'L576
            '============================================================
            Try
                If sSegmentType = "IA" Then
                    dL576 = dL323
                ElseIf sSegmentType = "IR" Then
                    dL576 = dL324
                Else
                    dL576 = dL251 + dL252
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-576")
            End Try

            'L577
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL577 = getEcodeValue("E2", "C1", railroad, "302")
                Else
                    dL577 = getEcodeValue("E2", "C2", railroad, "302")
                End If

                'IA IR adjustment
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL577 = getEcodeValue("E2", "C2", railroad, "302")
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-577")
            End Try

            'L578
            '============================================================
            Try
                dL578 = dL576 * dL577
                If sShipmentSize <> "SC" Then dL578 = 0

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-578")
            End Try

            'L579
            '============================================================
            Try
                dL579 = dL308

                If sSegmentType = "IA" Then dL579 = dL323
                If sSegmentType = "IR" Then dL579 = dL324

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-579")
            End Try

            'L580
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL580 = getEcodeValue("E2", "C1", railroad, "303")
                Else
                    dL580 = getEcodeValue("E2", "C2", railroad, "303")
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-580")
            End Try

            'L581
            '============================================================
            Try
                dL581 = dL579 * dL580

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-581")
            End Try

            'L582
            '============================================================
            Try
                dL582 = dL205

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-582")
            End Try

            'L583
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL583 = getEcodeValue("E2", "C1", railroad, "304")
                Else
                    dL583 = getEcodeValue("E2", "C2", railroad, "304")
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-583")
            End Try

            'L584
            '============================================================
            Try
                dL584 = (dL582) * dL583

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-584")
            End Try

            'L585
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL585 = getEcodeValue("E2", "C1", railroad, "305")
                Else
                    dL585 = getEcodeValue("E2", "C2", railroad, "305")
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-585")
            End Try

            'L586
            '============================================================
            Try
                dL586 = (dL582) * dL585

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-586")
            End Try

            'L587
            '============================================================
            Try
                dL587 = dL575 + dL578 + dL581 + dL584 + dL586

                'If (sSegmentType = "IA" Or sSegmentType = "IR") And sShipmentSize = "OT" Then
                If sSegmentType = "OR" And sShipmentSize = "SC" Then
                    dL587 = dL578 + dL581
                End If
                If sShipmentSize = "TL" Or sShipmentSize = "IM" Then
                    dL587 = 0
                End If

            Catch ex As System.Exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts-587")
            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "jurisdictionalAddOnCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Output lines 601-700 contain the summary of all variable costs developed in the Phase III process.
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub shipmentCosts(ByVal bLeg As Boolean, ByVal car_type As Integer, ByVal railroad As Integer, ByVal STCC As Long)

        Try

            dL601 = dL206
            dL602 = dL208
            dL603 = dL210
            dL604 = dL221
            dL605 = dL223
            dL606 = dL225
            dL607 = dL244
            dL608 = dL246
            dL609 = dL248
            dL610 = dL256
            dL611 = dL258
            dL612 = dL260
            dL613 = dL262
            dL614 = dL264
            dL615 = dL266
            dL616 = dL268
            dL617 = dL281
            dL618 = dL282
            dL619 = dL283
            dL620 = dL286
            dL621 = dL288
            dL622 = dL290
            dL623 = dL316
            dL624 = dL318
            dL625 = dL320
            dL626 = dL329
            dL627 = dL330
            dL628 = dL331
            dL629 = dL332
            dL630 = dL333
            dL631 = dL334
            dL632 = dL405

            'Don't Ask - Just Do - Car Type 41 is a Covered Hopper - Washburned*/
            If CreateStccCode(STCC, 2) = "11" Then dL632 = 0
            If CreateStccCode(STCC, 2) = "11" And car_type = 6 Then dL632 = dL405

            dL633 = dL409
            dL634 = dL411
            dL635 = dL413
            dL636 = dL415
            dL637 = dL427
            dL638 = dL429
            dL639 = dL431
            dL640 = dL434
            dL641 = dL438
            dL642 = dL440
            dL643 = dL442
            dL644 = dL453
            dL645 = dL455
            dL646 = dL457
            dL647 = dL459
            dL648 = dL461
            dL649 = dL463
            dL650 = dL465
            dL651 = dL467
            dL652 = dL469
            dL653 = dL471
            dL654 = dL473
            dL655 = dL475
            dL656 = dL477
            dL657 = dL479
            dL658 = dL481
            dL659 = dL486
            dL660 = dL487
            dL661 = dL488
            dL662 = dL489
            dL663 = dL490
            dL664 = dL491
            dL665 = dL498
            dL666 = dL499
            dL667 = dL499A
            dL668 = dL499B
            dL669 = dL499C
            dL670 = dL499D
            dL671 = dL503
            dL672 = dL505
            dL673 = dL507
            dL674 = dL510
            dL675 = dL512
            dL676 = dL514
            dL677 = dL517
            dL678 = dL519
            dL679 = dL521
            dL680 = dL524
            dL681 = dL526
            dL682 = dL528
            dL683 = dL531
            dL684 = dL534
            dL685 = dL543
            dL686 = dL545
            dL687 = dL547
            dL688 = dL560
            dL689 = dL554
            dL690 = dL556
            dL691 = dL558
            dL692 = dL562
            dL693 = dL564
            dL694 = dL566
            dL695 = dL572

            ' L696 is Variable Cost
            dL696 = (dL601 + dL602 + dL603 + dL604 + dL605 + dL606 + dL607 + dL608 + dL609 + dL610 + dL611 + dL612 + dL613 + dL614 + dL615 +
            dL616 + dL617 + dL618 + dL619 + dL620 + dL621 + dL622 + dL623 + dL624 + dL625 + dL626 + dL627 + dL628 + dL629 + dL630 + dL631 +
            dL632 + dL633 + dL634 + dL635 + dL636 + dL637 + dL638 + dL639 + dL640 + dL641 + dL642 + dL643 + dL644 + dL645 + dL646 + dL647 +
            dL648 + dL649 + dL650 + dL651 + dL652 + dL653 + dL654 + dL655 + dL656 + dL657 + dL658 + dL659 + dL660 + dL661 + dL662 + dL663 +
            dL664 + dL665 + dL666 + dL667 + dL668 + dL669 + dL670 + dL671 + dL672 + dL673 + dL674 + dL675 + dL676 + dL677 + dL678 + dL679 +
            dL680 + dL681 + dL682 + dL683 + dL684 + dL685 + dL686 + dL687 + dL688 + dL689 + dL690 + dL691 + dL692 + dL693 + dL694 + dL695)

            dL697 = getEcodeValue("E2", "C1", railroad, "220")
            dL698 = dL696 * dL697
            dL699 = dL537
            iL700 = dL696 + dL699 ' CRPSEG Costs - Different than Washburn's code

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "shipmentCosts")
        End Try
    End Sub

#End Region

#Region "Data memeber assignments"

    ''' <summary>
    ''' Takes the total_dist value from U_CURRENT_MASKED and divides by 10
    ''' then rounds to the nearest whole number
    ''' </summary>
    ''' <param name="tot_dist"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getTotalMiles(ByVal tot_dist As Double, ByVal bRound As Boolean) As Double
        Dim rUP As System.MidpointRounding = MidpointRounding.AwayFromZero
        If bRound Then
            Return Double.Parse(Math.Round(tot_dist / 10, rUP))
        Else
            Return Double.Parse(tot_dist / 10)
        End If

    End Function

    ''' <summary>
    ''' Takes the RR_dist value from U_CURRENT_SEG and divides by 10
    ''' </summary>
    ''' <param name="rrDist"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getMiles(ByVal rrDist As Integer, ByVal bRound As Boolean) As Integer
        Dim d As Double = rrDist / 10
        Dim rUP As System.MidpointRounding = MidpointRounding.AwayFromZero

        If bRound Then
            Return Math.Round(d, rUP)
        Else
            Return d
        End If

    End Function

    ''' <summary>
    ''' Takes the U_Car_Init value from the masked table and returns ownership
    ''' </summary>
    ''' <param name="U_Car_Init"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getOwnership(ByVal U_Car_Init As String) As String
        If U_Car_Init = "ABOX" Or U_Car_Init = "RBOX" Or U_Car_Init = "CSX" Or U_Car_Init = "CSXT" Or U_Car_Init = "GONX" Then
            Return "R"
        End If

        If Right(U_Car_Init, 1) = "X" Or Right(U_Car_Init, 2) = "X " Then
            Return "P"
        Else
            Return "R"
        End If
    End Function

    ''' <summary>
    ''' Using STB_Car_Typ, TOFC_Serv_Code, and U_Cars from the 
    ''' U_CURRENT_MASKED table, this function assigns a Shipment
    ''' Size of IM (Intermodal), SC (SingleCar), MC (MultiCar), 
    ''' or TL
    ''' </summary>
    ''' <param name="carType"></param>
    ''' <param name="servCode"></param>
    ''' <param name="cars"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getsShipmentSize(ByVal carType As Integer, ByVal servCode As String, ByVal cars As Integer) As String

        Dim sReturnString As String = ""

        If (carType = 46 Or carType = 49 Or carType = 52 Or carType = 54) And Not IsDBNull(servCode) And Not servCode = "" Then
            sReturnString = "IM"
        ElseIf cars <= 5 Then
            sReturnString = "SC"
        ElseIf cars <= 49 Then
            sReturnString = "MC"
        Else
            sReturnString = "TL"
        End If

        Return sReturnString

    End Function

    ''' <summary>
    ''' Gets an adjusted car type from the STB_Car_Type in the data set
    ''' </summary>
    ''' <param name="STB_CAR_Type"></param>
    ''' <param name="sTOFC_SC"> We have not set sTOFC_Serv_Code yet so pass the actual value from the row.</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function setCarType(ByVal STB_CAR_Type As Integer, ByVal sTOFC_SC As String) As Integer

        'First set to 18
        Dim LocalCarType As Integer = 18

        'Next, try to set as STB Type
        Try
            LocalCarType = getP3CarType(STB_CAR_Type)
        Catch
        End Try

        'washburn adjustment #1 (If intermodal set to 11
        If Not LTrim(RTrim(sTOFC_SC)) = "" Then
            If LocalCarType = 14 Or LocalCarType = 17 Or LocalCarType = 18 Then
                LocalCarType = 11
            End If
        End If

        Return LocalCarType

    End Function

    ''' <summary>
    ''' Uses carType, Railroad, and eTable data to return an Interline circuity value
    ''' </summary>
    ''' <param name="carType"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getInterlineCircuity(ByVal carType As Integer, ByVal RailRoad As Integer) As Double

        'Get the ecode value
        Return getEcodeValue_CarType("E2", "C6", RailRoad, carType)

    End Function

    ''' <summary>
    ''' Uses carType, Railroad, and eTable data to return an local circuity value
    ''' </summary>
    ''' <param name="carType"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getLocalCircuity(ByVal carType As Integer, ByVal RailRoad As Integer) As Double

        'Get the ecode value
        Return getEcodeValue_CarType("E2", "C5", RailRoad, carType)

    End Function

    ''' <summary>
    ''' Old Washburn code to format STCC Code
    ''' </summary>
    ''' <param name="STCC"></param>
    ''' <param name="NumberofDigits"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CreateStccCode(ByVal STCC As Long, ByVal NumberofDigits As Integer) As String
        If (NumberofDigits < 1 Or NumberofDigits > 7) Then Return ""
        Dim sSTCC As New StringBuilder
        sSTCC.AppendFormat("{0:0000000}", STCC)
        Return sSTCC.ToString.Substring(0, NumberofDigits)
    End Function

    ''' <summary>
    ''' old Washburn code to take the STCC  - Standard transportation commodity code from waybill
    ''' and get a line number to use in a lookup to the etables.
    ''' </summary>
    ''' <param name="STCC"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SetCommodityIdx(ByVal STCC As Long) As Integer
        Dim Stcc5 As String = CreateStccCode(STCC, 5)
        Dim Stcc4 As String = CreateStccCode(STCC, 4)
        Dim Stcc3 As String = CreateStccCode(STCC, 3)
        Dim Stcc2 As String = CreateStccCode(STCC, 2)
        Dim Stcc1 As String = CreateStccCode(STCC, 1)

        If bUseSqlToDetermineSTCC Then
            Return getSTCCLegacy(Stcc5, Stcc4, Stcc3, Stcc2)
        Else
            Dim Sdx As Integer = 0
            If (Stcc2 = "37") Then
                Sdx = 71 'Transportation equipment
                If (Stcc4 = "3714") Then Sdx = 74 'Motor vehicle parts
                If (Stcc5 = "37111") Then Sdx = 72 'Motor passenger cars
                If (Stcc5 = "37112") Then Sdx = 73 'Motor trucks
                Return Sdx
            End If
            If (Stcc2 = "11") Then
                Sdx = 8 'Coal
                Return Sdx
            End If
            If (Stcc2 = "28") Then
                Sdx = 40 'Chemicals
                If (Stcc3 = "281") Then Sdx = 41 'Industrial chemicals
                If (Stcc3 = "282") Then Sdx = 43 'Syn fibres/resins/rubber
                If (Stcc3 = "289") Then Sdx = 44 'Misc chemicals products
                If (Stcc4 = "2812") Then Sdx = 42 'Potassium or sodium
                Return Sdx
            End If
            If (Stcc2 = "20") Then
                Sdx = 10 'Food & kindered products
                If (Stcc3 = "202") Then Sdx = 12 'Dairy Products
                If (Stcc3 = "203") Then Sdx = 13 'Canned fruits/veg
                If (Stcc3 = "204") Then Sdx = 14 'Grain mill products
                If (Stcc3 = "209") Then Sdx = 25 'Misc food preparations
                If (Stcc4 = "2011") Then Sdx = 11 'Fresh meats
                If (Stcc4 = "2041") Then Sdx = 15 'Flour
                If (Stcc4 = "2042") Then Sdx = 16 'Prepared feeds
                If (Stcc4 = "2043") Then Sdx = 17 'Cereals
                If (Stcc4 = "2044") Then Sdx = 18 'Rice
                If (Stcc4 = "2045") Then Sdx = 19 'Prepared flour
                If (Stcc4 = "2046") Then Sdx = 20 'Corn products
                If (Stcc4 = "2062") Then Sdx = 21 'Refined sugar
                If (Stcc4 = "2084") Then Sdx = 23 'Wines
                If (Stcc5 = "20851") Then Sdx = 24 'Whiskey
                Return Sdx
            End If
            If (Stcc2 = "24") Then
                Sdx = 28 'Lumber and wood ex furniture
                If (Stcc4 = "2421") Then Sdx = 29 'Lumber/dimension stock
                If (Stcc4 = "2432") Then Sdx = 30 'Plywood or veneer
                Return Sdx
            End If
            If (Stcc2 = "26") Then
                Sdx = 33 'Pulp, paper and allied products
                If (Stcc3 = "263") Then Sdx = 36 'Fibrebd/paperdb/pulpbd
                If (Stcc3 = "264") Then Sdx = 37 'Cov paper/paperboard
                If (Stcc5 = "26211") Then Sdx = 34 'Newsprint
                If (Stcc5 = "26213") Then Sdx = 35 'Printing paper
                If (Stcc5 = "26471") Then Sdx = 38 'Sanitary tissues
                Return Sdx
            End If
            If (Stcc2 = "44") Then Sdx = 76 'Freight forwarder traffic
            If (Stcc2 = "45") Then Sdx = 77 'Shipper association traffic
            If (Stcc2 = "46") Then
                Sdx = 78 'Misc mixed shipments
                If (Stcc3 = "461") Then Sdx = 79 'Misc mixed shipments inc TOFC
                Return Sdx
            End If
            If (Stcc1 = "0") Then 'STCC is farm products
                If (Stcc5 = "01195") Then Sdx = 3 'Potatoes other than sweet
                If (Stcc4 = "0113") Then Sdx = 2 'Grain
                If (Stcc3 = "012") Then Sdx = 4 'Fresh Fruits
                If (Stcc3 = "013") Then Sdx = 5 'Fresh vegetables
                If (Sdx = 0) Then Sdx = 1 'Farm Products
                Return Sdx
            End If
            If (Stcc2 = "10") Then Sdx = 7 'Metallic Ores
            If (Stcc2 = "14") Then Sdx = 9 'Nonmetallic minerals
            If (Stcc2 = "21") Then Sdx = 27 'Tobacco products
            If (Stcc2 = "25") Then Sdx = 32 'Furniture and fixtures
            If (Stcc2 = "29") Then Sdx = 46 'Petroleum or coal products
            If (Stcc2 = "30") Then
                Sdx = 47 'Rubber and misc plastics
                If (Stcc3 = "301") Then Sdx = 48 'Rubber tires/inner tubes
                Return Sdx
            End If
            If (Stcc2 = "32") Then
                Sdx = 50 'Stone, clay and glass products
                If (Stcc3 = "321") Then Sdx = 51 'Flat glass
                If (Stcc4 = "3295") Then Sdx = 52 'Nonmetallic earth/min
                Return Sdx
            End If
            If (Stcc2 = "33") Then
                Sdx = 54 'Primary metal products
                If (Stcc4 = "3312") Then Sdx = 55 'Primary iron/steel products
                If (Stcc4 = "3352") Then Sdx = 56 'Aluminum basic shapes
                Return Sdx
            End If
            If (Stcc2 = "34") Then
                Sdx = 58 'Fabricated metal products
                If (Stcc3 = "344") Then Sdx = 59 'Fab struc metal products
                Return Sdx
            End If
            If (Stcc2 = "35") Then
                Sdx = 61 'Machinery except electrical
                If (Stcc3 = "351") Then Sdx = 62 'Engines/turbines
                If (Stcc3 = "352") Then Sdx = 63 'Farm machinery
                If (Stcc3 = "353") Then Sdx = 64 'Const min/mat hand machinery
                Return Sdx
            End If
            If (Stcc2 = "36") Then
                Sdx = 66 'Electrical machinery
                If (Stcc3 = "361") Then Sdx = 67 'Electrical trans/dist equipment
                If (Stcc3 = "362") Then Sdx = 68 'Household appliances
                If (Stcc3 = "365") Then Sdx = 69 'Radio or TV sets

                Return Sdx
            End If
            If (Stcc2 = "48") Then Sdx = 81 'Hazardous materials
            If (Sdx = 0) Then Sdx = 82 'All other commodities
            Return Sdx
        End If

    End Function

    Private Function getSTCCLegacy(ByVal stcc5 As String, ByVal stcc4 As String, ByVal stcc3 As String, ByVal stcc2 As String) As Integer

        'stcc5
        Dim Rows5() = dtSTCCLookup.Select("Lookup = " & stcc5)
        If Rows5(0) IsNot Nothing Then
            Return Integer.Parse(Rows5(0)("Idx"))
        End If

        'stcc4
        Dim Rows4() = dtSTCCLookup.Select("Lookup = " & stcc4)
        If Rows4(0) IsNot Nothing Then
            Return Integer.Parse(Rows4(0)("Idx"))
        End If

        'stcc3
        Dim Rows3() = dtSTCCLookup.Select("Lookup = " & stcc3)
        If Rows3(0) IsNot Nothing Then
            Return Integer.Parse(Rows3(0)("Idx"))
        End If

        'stcc2 oth
        Dim Rows2oth() = dtSTCCLookup.Select("Lookup = " & stcc2 & "oth")
        If Rows2oth(0) IsNot Nothing Then
            Return Integer.Parse(Rows2oth(0)("Idx"))
        End If

        'stcc2 all
        Dim Rows2all() = dtSTCCLookup.Select("Lookup = " & stcc2 & "all")
        If Rows2all(0) IsNot Nothing Then
            Return Integer.Parse(Rows2all(0)("Idx"))
        End If

        Return 82

    End Function

#End Region

#Region "Filtered Input Functions"

    ''' <summary>
    ''' Triggered by bInputFilter = False or bLegacy = False, this function holds all legacy logic necessary 
    ''' to filter the dataset in the non-legacy fashion
    ''' </summary>
    ''' <param name="originalTable"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getFilteredInput(ByVal originalTable As DataTable) As DataRow()

        'Filter non us moves
        If bFilterNonUSMovements Then
            For Each drTons As DataRow In originalTable.Select("RR_Cntry <> 'US'")
                HandleError("Serial_No:" & drTons("Serial_no") & ", Segment_No:" & drTons("Seg_no"),
                            "Removed Row based on criteria enforcement: Non US Movement",
                            "Caused a suppression of a datarow on input:",
                            "FilteredInputFunction")
                drTons.Delete()
            Next
        End If

        'Delete if Tons are less than 1
        If bAdjustTonsFromLessThan1_To_LessThanorEqualTo0 Then
            For Each drTons As DataRow In originalTable.Select("(bill_Wght_tons / U_cars) <= 0")
                HandleError("Serial_No:" & drTons("Serial_no") & ", Segment_No:" & drTons("Seg_no"),
                            "Removed Row based on criteria enforcement: TONS > 1",
                            "Caused a suppression of a datarow on input:",
                            "FilteredInputFunction")
                drTons.Delete()
            Next
        Else
            For Each drTons As DataRow In originalTable.Select("(bill_Wght_tons / U_cars) < 1")
                HandleError("Serial_No:" & drTons("Serial_no") & ", Segment_No:" & drTons("Seg_no"),
                            "Removed Row based on criteria enforcement: TONS > 1",
                            "Caused a suppression of a datarow on input:",
                            "FilteredInputFunction")
                drTons.Delete()
            Next
        End If

        'Delete if RR_Rev <= 0
        If bFilter0Revenue Then
            For Each drRev As DataRow In originalTable.Select("RR_Rev <= 0")
                HandleError("Serial_No:" & drRev("Serial_no") & ", Segment_No:" & drRev("Seg_no"),
                            "Removed Row based on criteria enforcement: RR_Rev > 0",
                            "Caused a suppression of a datarow on input:",
                            "FilteredInputFunction")
                drRev.Delete()
            Next
        End If

        'Delete if U_Cars < 1
        For Each drCars As DataRow In originalTable.Select("U_Cars < 1")
            HandleError("Serial_No:" & drCars("Serial_no") & ", Segment_No:" & drCars("Seg_no"),
                        "Removed Row based on criteria enforcement: U_Cars >= 1",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drCars.Delete()
        Next

        'Delete if mileage < 1 miles 
        If bAdjustTotalDistFromLessThan1_To_LessThanorEqualTo0 Then
            For Each drDist As DataRow In originalTable.Select("total_dist <= 0")
                HandleError("Serial_No:" & drDist("Serial_no") & ", Segment_No:" & drDist("Seg_no"),
                            "Removed Row based on criteria enforcement: total_dist < 1",
                            "Caused a suppression of a datarow on input:",
                            "FilteredInputFunction")
                drDist.Delete()
            Next
        Else
            For Each drDist As DataRow In originalTable.Select("total_dist < 10")
                HandleError("Serial_No:" & drDist("Serial_no") & ", Segment_No:" & drDist("Seg_no"),
                            "Removed Row based on criteria enforcement: total_dist < 1",
                            "Caused a suppression of a datarow on input:",
                            "FilteredInputFunction")
                drDist.Delete()
            Next
        End If

        'Delete if any And JF >= 0 ORR_dist < 5
        For Each drJF0 As DataRow In originalTable.Select("JF >= 0 And ORR_dist < 5")
            HandleError("Serial_No:" & drJF0("Serial_no") & ", Segment_No:" & drJF0("Seg_no"),
                        "Removed Row based on criteria enforcement: JF >= 0 ORR_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF0.Delete()
        Next

        'Delete if any And JF > 0 TRR_dist < 5 
        For Each drJF0T As DataRow In originalTable.Select("JF > 0 And TRR_dist < 5 ")
            HandleError("Serial_No:" & drJF0T("Serial_no") & ", Segment_No:" & drJF0T("Seg_no"),
                        "Removed Row based on criteria enforcement: JF > 0 TRR_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF0T.Delete()
        Next


        'Delete if any And JF >= 2 JRR1_dist < 5  
        For Each drJF2 As DataRow In originalTable.Select("JF >= 2 And JRR1_dist < 5")
            HandleError("Serial_No:" & drJF2("Serial_no") & ", Segment_No:" & drJF2("Seg_no"),
                        "Removed Row based on criteria enforcement: JF > 0 TRR_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF2.Delete()
        Next

        'Delete if any And JF >= 3 JRR2_dist < 5
        For Each drJF3 As DataRow In originalTable.Select("JF >= 3 And JRR2_dist < 5")
            HandleError("Serial_No:" & drJF3("Serial_no") & ", Segment_No:" & drJF3("Seg_no"),
                        "Removed Row based on criteria enforcement: JF >= 3 JRR2_dist be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF3.Delete()
        Next

        'Delete if any And JF >= 4 JRR3_dist < 5
        For Each drJF4 As DataRow In originalTable.Select("JF >= 4 And JRR3_dist < 5")
            HandleError("Serial_No:" & drJF4("Serial_no") & ", Segment_No:" & drJF4("Seg_no"),
                        "Removed Row based on criteria enforcement: JF >= 4 JRR3_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF4.Delete()
        Next

        'Delete if any And JF >= 5 JRR4_dist < 5
        For Each drJF5 As DataRow In originalTable.Select("JF >= 5 And JRR4_dist < 5")
            HandleError("Serial_No:" & drJF5("Serial_no") & ", Segment_No:" & drJF5("Seg_no"),
                        "Removed Row based on criteria enforcement: JF >= 5 JRR4_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF5.Delete()
        Next

        'Delete if any And JF >= 6 JRR5_dist < 5 
        For Each drJF6 As DataRow In originalTable.Select("JF >= 6 And JRR5_dist < 5 ")
            HandleError("Serial_No:" & drJF6("Serial_no") & ", Segment_No:" & drJF6("Seg_no"),
                        "Removed Row based on criteria enforcement: JF >= 6 JRR5_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF6.Delete()
        Next

        'Delete if any And JF >= 7 JRR6_dist < 5 
        For Each drJF7 As DataRow In originalTable.Select("JF >= 7 And JRR6_dist < 5")
            HandleError("Serial_No:" & drJF7("Serial_no") & ", Segment_No:" & drJF7("Seg_no"),
                        "Removed Row based on criteria enforcement: JF >= 7 JRR6_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF7.Delete()
        Next

        'Delete if any And JF > 0 & Total_dist < 45 (50 washburn adds .5 and truncates)
        For Each drJF050 As DataRow In originalTable.Select("JF > 0 And Total_dist < 45")
            HandleError("Serial_No:" & drJF050("Serial_no") & ", Segment_No:" & drJF050("Seg_no"),
                        "Removed Row based on criteria enforcement: JF > 0 Total_dist must be >= 50",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF050.Delete()
        Next

        'Delete if JF = 0 and Total_dist < 15 (20 washburn adds .5 and truncates)
        If bFilterSingleMoveLessThan2Miles Then
            For Each drJF020 As DataRow In originalTable.Select("JF = 0 And Total_dist < 15")
                HandleError("Serial_No:" & drJF020("Serial_no") & ", Segment_No:" & drJF020("Seg_no"),
                            "Removed Row based on criteria enforcement: JF = 0 Total_dist must be >= 20",
                            "Caused a suppression of a datarow on input:",
                            "FilteredInputFunction")
                drJF020.Delete()
            Next
        End If

        Return originalTable.Select()

    End Function

    ''' <summary>
    ''' Triggered by bInputFilter = True, this function holds all legacy logic necessary 
    ''' to filter the dataset prior to looping.
    ''' </summary>
    ''' <param name="originalTable"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getFilteredInputLegacy(ByVal originalTable As DataTable) As DataRow()

        'Delete if Tons are less than 1
        For Each drTons As DataRow In originalTable.Select("(bill_Wght_tons / U_cars) < 1")
            HandleError("Serial_No:" & drTons("Serial_no") & ", Segment_No:" & drTons("Seg_no"),
                        "Removed Row based on criteria enforcement: TONS > 1",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drTons.Delete()
        Next

        'Delete if RR_Rev <= 0
        For Each drRev As DataRow In originalTable.Select("RR_Rev <= 0")
            HandleError("Serial_No:" & drRev("Serial_no") & ", Segment_No:" & drRev("Seg_no"),
                        "Removed Row based on criteria enforcement: RR_Rev > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drRev.Delete()
        Next

        'Delete if U_Cars < 1
        For Each drCars As DataRow In originalTable.Select("U_Cars < 1")
            HandleError("Serial_No:" & drCars("Serial_no") & ", Segment_No:" & drCars("Seg_no"),
                        "Removed Row based on criteria enforcement: U_Cars >= 1",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drCars.Delete()
        Next

        'Delete if mileage < 1 miles TODO: Confirm this filter
        For Each drDist As DataRow In originalTable.Select("total_dist < 10")
            HandleError("Serial_No:" & drDist("Serial_no") & ", Segment_No:" & drDist("Seg_no"),
                        "Removed Row based on criteria enforcement: total_dist < 1",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drDist.Delete()
        Next


        'Delete if any And JF >= 0 ORR_dist < 5
        For Each drJF0 As DataRow In originalTable.Select("JF >= 0 And ORR_dist < 5")
            HandleError("Serial_No:" & drJF0("Serial_no") & ", Segment_No:" & drJF0("Seg_no"),
                        "Removed Row based on criteria enforcement: JF >= 0 ORR_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF0.Delete()
        Next

        'Delete if any And JF > 0 TRR_dist < 5 
        For Each drJF0T As DataRow In originalTable.Select("JF > 0 And TRR_dist < 5 ")
            HandleError("Serial_No:" & drJF0T("Serial_no") & ", Segment_No:" & drJF0T("Seg_no"),
                        "Removed Row based on criteria enforcement: JF > 0 TRR_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF0T.Delete()
        Next


        'Delete if any And JF >= 2 JRR1_dist < 5  
        For Each drJF2 As DataRow In originalTable.Select("JF >= 2 And JRR1_dist < 5")
            HandleError("Serial_No:" & drJF2("Serial_no") & ", Segment_No:" & drJF2("Seg_no"),
                        "Removed Row based on criteria enforcement: JF > 0 TRR_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF2.Delete()
        Next

        'Delete if any And JF >= 3 JRR2_dist < 5
        For Each drJF3 As DataRow In originalTable.Select("JF >= 3 And JRR2_dist < 5")
            HandleError("Serial_No:" & drJF3("Serial_no") & ", Segment_No:" & drJF3("Seg_no"),
                        "Removed Row based on criteria enforcement: JF >= 3 JRR2_dist be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF3.Delete()
        Next

        'Delete if any And JF >= 4 JRR3_dist < 5
        For Each drJF4 As DataRow In originalTable.Select("JF >= 4 And JRR3_dist < 5")
            HandleError("Serial_No:" & drJF4("Serial_no") & ", Segment_No:" & drJF4("Seg_no"),
                        "Removed Row based on criteria enforcement: JF >= 4 JRR3_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF4.Delete()
        Next

        'Delete if any And JF >= 5 JRR4_dist < 5
        For Each drJF5 As DataRow In originalTable.Select("JF >= 5 And JRR4_dist < 5")
            HandleError("Serial_No:" & drJF5("Serial_no") & ", Segment_No:" & drJF5("Seg_no"),
                        "Removed Row based on criteria enforcement: JF >= 5 JRR4_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF5.Delete()
        Next

        'Delete if any And JF >= 6 JRR5_dist < 5 
        For Each drJF6 As DataRow In originalTable.Select("JF >= 6 And JRR5_dist < 5 ")
            HandleError("Serial_No:" & drJF6("Serial_no") & ", Segment_No:" & drJF6("Seg_no"),
                        "Removed Row based on criteria enforcement: JF >= 6 JRR5_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF6.Delete()
        Next

        'Delete if any And JF >= 7 JRR6_dist < 5 
        For Each drJF7 As DataRow In originalTable.Select("JF >= 7 And JRR6_dist < 5")
            HandleError("Serial_No:" & drJF7("Serial_no") & ", Segment_No:" & drJF7("Seg_no"),
                        "Removed Row based on criteria enforcement: JF >= 7 JRR6_dist must be > 0",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF7.Delete()
        Next

        'Delete if any And JF > 0 & Total_dist < 45 (50 washburn adds .5 and truncates)
        For Each drJF050 As DataRow In originalTable.Select("JF > 0 And Total_dist < 45")
            HandleError("Serial_No:" & drJF050("Serial_no") & ", Segment_No:" & drJF050("Seg_no"),
                        "Removed Row based on criteria enforcement: JF > 0 Total_dist must be >= 50",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF050.Delete()
        Next

        'Delete if JF = 0 and Total_dist < 15 (20 washburn adds .5 and truncates)
        For Each drJF020 As DataRow In originalTable.Select("JF = 0 And Total_dist < 15")
            HandleError("Serial_No:" & drJF020("Serial_no") & ", Segment_No:" & drJF020("Seg_no"),
                        "Removed Row based on criteria enforcement: JF = 0 Total_dist must be >= 20",
                        "Caused a suppression of a datarow on input:",
                        "FilteredInputFunction")
            drJF020.Delete()
        Next

        Return originalTable.Select()

    End Function

#End Region

#Region "Private Functions"

    ''' <summary>
    ''' Main function to move through each segment and cost each line number
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Cost(ByVal legacy As Boolean, ByVal loopSegment As Integer, ByVal writeLoopOutput As Boolean)

        Try

            RefreshLineNumbers()

            'Calculation of Mileage by Train Type (Lines 101 - 111)
            milageByTrainType(legacy, loopSegment, iCarType, iRailroadNumber)

            'Calculation of Car-Mile Costs - Other than Clerical   (lines 201 - 211)
            carMileCosts(legacy, iRailroadNumber, iCarType, iU_TC_Units, dBill_Wght_Tons)

            'Calculation of Gross Ton-Mile Costs (lines 212 - 225)
            grossTonMileCosts(legacy, iCarType, iRailroadNumber, iTons)

            'Calculation of Locomotive Unit-Miles (lines 226 - 248)
            locomotiveUnitMiles(legacy, loopSegment, iRailroadNumber)

            'Calculation of Carload and Clerical Costs (lines 250 - 268)
            carloadsAndClericalCosts(legacy, loopSegment, iRailroadNumber)

            'Calculation of Train-Mile Costs (lines 269 - 284 (Crew Wages) and lines 285 - 290 (Other Expenses)
            trainMileCostsCrewWagesOther(legacy, iRailroadNumber)

            'Calculation of Industry, Interchange and Intertrain and Intratrain Switching Cost (lines 301 – 320)
            industryInterchangeIntertrain_IntertrainSwitching(legacy, loopSegment, iCarType, iRailroadNumber)

            'Calculation of Intraterminal and Interterminal Switching Costs  (lines 321 - 334)
            intraterminal_IntraterminalSwitching(legacy, loopSegment, iCarType, iRailroadNumber)

            'Private Line Car Rentals (lines 401 - 405)
            privateLineCarRentals(legacy, iCarType, iRailroadNumber)

            'Calculation of Railroad Owned Cars Mileage Costs (Lines 406-431)
            railroadOwnedCars_MileageCosts(legacy, loopSegment, iCarType, iRailroadNumber)

            'Calculation of Railroad-Owned Car Time Costs (lines 432 - 457)
            railroadOwnedCars_TimeCosts(legacy, loopSegment, iCarType, iRailroadNumber)

            'Calculation of Railroad-Owned Cars - Accessorial Services Costs (lines 458 - 481)
            railroadOwnedCars_AccessorialServicesCosts(legacy, iCarType, iRailroadNumber)

            'Railroad-Owned Cars - Intraterminal and Interterminal Switching Costs(lines 482 - 499D )
            railroadOwnedCars_Intraterminal_InteraterminalSwitchingCosts(legacy, iCarType, iRailroadNumber)

            'Lake Transfer Service Costs (lines 501 - 507)
            lakeTransferServiceCosts(legacy, iCarType, iRailroadNumber)

            'Coal Terminal Service Costs (lines 508 - 514)
            coalTerminalServiceCosts(legacy, iCarType, iRailroadNumber)

            'Ore Terminal Service Costs (lines 515 - 521) 
            oreTerminalServiceCosts(legacy, iCarType, iRailroadNumber)

            'Other Marine Terminal Costs (lines 522 - 528) 
            otherMarineTerminalCosts(legacy, iCarType, iRailroadNumber)

            'Motor Vehicle Unit Loading and Unloading Costs  (lines 529 - 531)
            motorVehicleUnitLoading_UnloadingCosts(legacy, iCarType, iRailroadNumber, dBill_Wght_Tons, iU_cars)

            'Car Refrigerated Protective Service Cost (lines 532 - 534)
            carRegrigeratedProtectiveServiceCost(legacy, iCarType, iRailroadNumber)

            'Loss and Damage Claim Payment Cost (lines 535 - 537)
            lossAndDamageClaimPaymentCost(legacy, iCarType, iRailroadNumber, lSTCC)

            'TCU's Loading and Unloading (Tie and Untie) Costs (lines 540 - 547)
            TCUsLoading_Unloading(legacy, iCarType, iRailroadNumber)

            'TCU Ownership and Protective Service Cost (lines 548 - 666)
            TCUOwnershipProtectiveServiceCost(legacy, iCarType, iRailroadNumber)

            'TCU Pickup and Delivery Costs (lines 570 - 572)
            TCUPickupDelieveryCosts(legacy, iCarType, iRailroadNumber)

            'Jurisdictional Add-On Costs (lines 573 – 587)
            jurisdictionalAddOnCosts(legacy, iCarType, iRailroadNumber)

            'Output lines 601-700 contain the summary of all variable costs developed in the Phase III process.
            shipmentCosts(legacy, iCarType, iRailroadNumber, lSTCC)

            'Write the output row to SQL
            '============================================================================

            'if L696 =< 0 then do not write the line
            If dL696 <= 0 Then
                HandleError("Serial_No:" & iSerialNum.ToString() & ", Segment_No:" & iSegmentNumber.ToString(),
                            "Removed Row based on criteria enforcement: L696 > 0",
                            "Caused a suppression of a datarow on output:",
                            "MainLoop-writeOutput")
            Else
                'write out to SQL if desired
                If writeLoopOutput Then
                    writeOutput(legacy, loopSegment)
                End If
            End If


        Catch ex As System.Exception
            HandleError("Unhandled Error while calculating costs for serialNumber " & iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message, ex.StackTrace, "MainLoop")
        End Try
    End Sub

    ''' <summary>
    ''' Writes the current row back to SQL for the CRPSEG Files.  If we are in legacy mode, then we write to a seperate table
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub writeOutput(ByVal bLeg As Boolean, ByVal loopSeg As Integer)

        Try

            'create params
            Dim pLoopSegment As SqlClient.SqlParameter
            Dim pSerialNum As SqlClient.SqlParameter
            Dim pSegmentNumber As SqlClient.SqlParameter
            Dim pShipmentSize As SqlClient.SqlParameter
            Dim pSegmentType As SqlClient.SqlParameter
            Dim pCarType As SqlClient.SqlParameter
            Dim pOwnership As SqlClient.SqlParameter
            Dim pRR_ID As SqlClient.SqlParameter
            Dim pRR_Region As SqlClient.SqlParameter
            Dim pNum_Cars As SqlClient.SqlParameter
            Dim pNum_Cars_Expanded As SqlClient.SqlParameter


            Dim pL101 As SqlClient.SqlParameter
            Dim pL102 As SqlClient.SqlParameter
            Dim pL103 As SqlClient.SqlParameter
            Dim pL104 As SqlClient.SqlParameter
            Dim pL105 As SqlClient.SqlParameter
            Dim pL106 As SqlClient.SqlParameter
            Dim pL107 As SqlClient.SqlParameter
            Dim pL108 As SqlClient.SqlParameter
            Dim pL109 As SqlClient.SqlParameter
            Dim pL110 As SqlClient.SqlParameter
            Dim pL111 As SqlClient.SqlParameter
            Dim pL201 As SqlClient.SqlParameter
            Dim pL202 As SqlClient.SqlParameter
            Dim pL203 As SqlClient.SqlParameter
            Dim pL204 As SqlClient.SqlParameter
            Dim pL205 As SqlClient.SqlParameter
            Dim pL206 As SqlClient.SqlParameter
            Dim pL207 As SqlClient.SqlParameter
            Dim pL208 As SqlClient.SqlParameter
            Dim pL209 As SqlClient.SqlParameter
            Dim pL210 As SqlClient.SqlParameter
            Dim pL211 As SqlClient.SqlParameter
            Dim pL212 As SqlClient.SqlParameter
            Dim pL213 As SqlClient.SqlParameter
            Dim pL214 As SqlClient.SqlParameter
            Dim pL215 As SqlClient.SqlParameter
            Dim pL216 As SqlClient.SqlParameter
            Dim pL217 As SqlClient.SqlParameter
            Dim pL218 As SqlClient.SqlParameter
            Dim pL219 As SqlClient.SqlParameter
            Dim pL220 As SqlClient.SqlParameter
            Dim pL221 As SqlClient.SqlParameter
            Dim pL222 As SqlClient.SqlParameter
            Dim pL223 As SqlClient.SqlParameter
            Dim pL224 As SqlClient.SqlParameter
            Dim pL225 As SqlClient.SqlParameter
            Dim pL226 As SqlClient.SqlParameter
            Dim pL227 As SqlClient.SqlParameter
            Dim pL228 As SqlClient.SqlParameter
            Dim pL229 As SqlClient.SqlParameter
            Dim pL230 As SqlClient.SqlParameter
            Dim pL231 As SqlClient.SqlParameter
            Dim pL232 As SqlClient.SqlParameter
            Dim pL233 As SqlClient.SqlParameter
            Dim pL234 As SqlClient.SqlParameter
            Dim pL235 As SqlClient.SqlParameter
            Dim pL236 As SqlClient.SqlParameter
            Dim pL237 As SqlClient.SqlParameter
            Dim pL238 As SqlClient.SqlParameter
            Dim pL239 As SqlClient.SqlParameter
            Dim pL240 As SqlClient.SqlParameter
            Dim pL241 As SqlClient.SqlParameter
            Dim pL242 As SqlClient.SqlParameter
            Dim pL243 As SqlClient.SqlParameter
            Dim pL244 As SqlClient.SqlParameter
            Dim pL245 As SqlClient.SqlParameter
            Dim pL246 As SqlClient.SqlParameter
            Dim pL247 As SqlClient.SqlParameter
            Dim pL248 As SqlClient.SqlParameter
            Dim pL250 As SqlClient.SqlParameter
            Dim pL251 As SqlClient.SqlParameter
            Dim pL252 As SqlClient.SqlParameter
            Dim pL253 As SqlClient.SqlParameter
            Dim pL254 As SqlClient.SqlParameter
            Dim pL255 As SqlClient.SqlParameter
            Dim pL256 As SqlClient.SqlParameter
            Dim pL257 As SqlClient.SqlParameter
            Dim pL258 As SqlClient.SqlParameter
            Dim pL259 As SqlClient.SqlParameter
            Dim pL260 As SqlClient.SqlParameter
            Dim pL261 As SqlClient.SqlParameter
            Dim pL262 As SqlClient.SqlParameter
            Dim pL263 As SqlClient.SqlParameter
            Dim pL264 As SqlClient.SqlParameter
            Dim pL265 As SqlClient.SqlParameter
            Dim pL266 As SqlClient.SqlParameter
            Dim pL267 As SqlClient.SqlParameter
            Dim pL268 As SqlClient.SqlParameter
            Dim pL269 As SqlClient.SqlParameter
            Dim pL270 As SqlClient.SqlParameter
            Dim pL271 As SqlClient.SqlParameter
            Dim pL272 As SqlClient.SqlParameter
            Dim pL273 As SqlClient.SqlParameter
            Dim pL274 As SqlClient.SqlParameter
            Dim pL275 As SqlClient.SqlParameter
            Dim pL276 As SqlClient.SqlParameter
            Dim pL277 As SqlClient.SqlParameter
            Dim pL278 As SqlClient.SqlParameter
            Dim pL279 As SqlClient.SqlParameter
            Dim pL280 As SqlClient.SqlParameter
            Dim pL281 As SqlClient.SqlParameter
            Dim pL282 As SqlClient.SqlParameter
            Dim pL283 As SqlClient.SqlParameter
            Dim pL284 As SqlClient.SqlParameter
            Dim pL285 As SqlClient.SqlParameter
            Dim pL286 As SqlClient.SqlParameter
            Dim pL287 As SqlClient.SqlParameter
            Dim pL288 As SqlClient.SqlParameter
            Dim pL289 As SqlClient.SqlParameter
            Dim pL290 As SqlClient.SqlParameter
            Dim pL301 As SqlClient.SqlParameter
            Dim pL302 As SqlClient.SqlParameter
            Dim pL303 As SqlClient.SqlParameter
            Dim pL304 As SqlClient.SqlParameter
            Dim pL305 As SqlClient.SqlParameter
            Dim pL306 As SqlClient.SqlParameter
            Dim pL307 As SqlClient.SqlParameter
            Dim pL308 As SqlClient.SqlParameter
            Dim pL309 As SqlClient.SqlParameter
            Dim pL310 As SqlClient.SqlParameter
            Dim pL311 As SqlClient.SqlParameter
            Dim pL312 As SqlClient.SqlParameter
            Dim pL313 As SqlClient.SqlParameter
            Dim pL314 As SqlClient.SqlParameter
            Dim pL315 As SqlClient.SqlParameter
            Dim pL316 As SqlClient.SqlParameter
            Dim pL317 As SqlClient.SqlParameter
            Dim pL318 As SqlClient.SqlParameter
            Dim pL319 As SqlClient.SqlParameter
            Dim pL320 As SqlClient.SqlParameter
            Dim pL321 As SqlClient.SqlParameter
            Dim pL322 As SqlClient.SqlParameter
            Dim pL323 As SqlClient.SqlParameter
            Dim pL324 As SqlClient.SqlParameter
            Dim pL325 As SqlClient.SqlParameter
            Dim pL326 As SqlClient.SqlParameter
            Dim pL327 As SqlClient.SqlParameter
            Dim pL328 As SqlClient.SqlParameter
            Dim pL329 As SqlClient.SqlParameter
            Dim pL330 As SqlClient.SqlParameter
            Dim pL331 As SqlClient.SqlParameter
            Dim pL332 As SqlClient.SqlParameter
            Dim pL333 As SqlClient.SqlParameter
            Dim pL334 As SqlClient.SqlParameter
            Dim pL401 As SqlClient.SqlParameter
            Dim pL402 As SqlClient.SqlParameter
            Dim pL403 As SqlClient.SqlParameter
            Dim pL404 As SqlClient.SqlParameter
            Dim pL405 As SqlClient.SqlParameter
            Dim pL406 As SqlClient.SqlParameter
            Dim pL407 As SqlClient.SqlParameter
            Dim pL408 As SqlClient.SqlParameter
            Dim pL409 As SqlClient.SqlParameter
            Dim pL410 As SqlClient.SqlParameter
            Dim pL411 As SqlClient.SqlParameter
            Dim pL412 As SqlClient.SqlParameter
            Dim pL413 As SqlClient.SqlParameter
            Dim pL414 As SqlClient.SqlParameter
            Dim pL415 As SqlClient.SqlParameter
            Dim pL416 As SqlClient.SqlParameter
            Dim pL417 As SqlClient.SqlParameter
            Dim pL418 As SqlClient.SqlParameter
            Dim pL419 As SqlClient.SqlParameter
            Dim pL420 As SqlClient.SqlParameter
            Dim pL421 As SqlClient.SqlParameter
            Dim pL422 As SqlClient.SqlParameter
            Dim pL423 As SqlClient.SqlParameter
            Dim pL424 As SqlClient.SqlParameter
            Dim pL425 As SqlClient.SqlParameter
            Dim pL426 As SqlClient.SqlParameter
            Dim pL427 As SqlClient.SqlParameter
            Dim pL428 As SqlClient.SqlParameter
            Dim pL429 As SqlClient.SqlParameter
            Dim pL430 As SqlClient.SqlParameter
            Dim pL431 As SqlClient.SqlParameter
            Dim pL432 As SqlClient.SqlParameter
            Dim pL433 As SqlClient.SqlParameter
            Dim pL434 As SqlClient.SqlParameter
            Dim pL435 As SqlClient.SqlParameter
            Dim pL436 As SqlClient.SqlParameter
            Dim pL437 As SqlClient.SqlParameter
            Dim pL438 As SqlClient.SqlParameter
            Dim pL439 As SqlClient.SqlParameter
            Dim pL440 As SqlClient.SqlParameter
            Dim pL441 As SqlClient.SqlParameter
            Dim pL442 As SqlClient.SqlParameter
            Dim pL443 As SqlClient.SqlParameter
            Dim pL444 As SqlClient.SqlParameter
            Dim pL445 As SqlClient.SqlParameter
            Dim pL446 As SqlClient.SqlParameter
            Dim pL447 As SqlClient.SqlParameter
            Dim pL448 As SqlClient.SqlParameter
            Dim pL449 As SqlClient.SqlParameter
            Dim pL450 As SqlClient.SqlParameter
            Dim pL451 As SqlClient.SqlParameter
            Dim pL452 As SqlClient.SqlParameter
            Dim pL453 As SqlClient.SqlParameter
            Dim pL454 As SqlClient.SqlParameter
            Dim pL455 As SqlClient.SqlParameter
            Dim pL456 As SqlClient.SqlParameter
            Dim pL457 As SqlClient.SqlParameter
            Dim pL458 As SqlClient.SqlParameter
            Dim pL459 As SqlClient.SqlParameter
            Dim pL460 As SqlClient.SqlParameter
            Dim pL461 As SqlClient.SqlParameter
            Dim pL462 As SqlClient.SqlParameter
            Dim pL463 As SqlClient.SqlParameter
            Dim pL464 As SqlClient.SqlParameter
            Dim pL465 As SqlClient.SqlParameter
            Dim pL466 As SqlClient.SqlParameter
            Dim pL467 As SqlClient.SqlParameter
            Dim pL468 As SqlClient.SqlParameter
            Dim pL469 As SqlClient.SqlParameter
            Dim pL470 As SqlClient.SqlParameter
            Dim pL471 As SqlClient.SqlParameter
            Dim pL472 As SqlClient.SqlParameter
            Dim pL473 As SqlClient.SqlParameter
            Dim pL474 As SqlClient.SqlParameter
            Dim pL475 As SqlClient.SqlParameter
            Dim pL476 As SqlClient.SqlParameter
            Dim pL477 As SqlClient.SqlParameter
            Dim pL478 As SqlClient.SqlParameter
            Dim pL479 As SqlClient.SqlParameter
            Dim pL480 As SqlClient.SqlParameter
            Dim pL481 As SqlClient.SqlParameter
            Dim pL482 As SqlClient.SqlParameter
            Dim pL483 As SqlClient.SqlParameter
            Dim pL484 As SqlClient.SqlParameter
            Dim pL485 As SqlClient.SqlParameter
            Dim pL486 As SqlClient.SqlParameter
            Dim pL487 As SqlClient.SqlParameter
            Dim pL488 As SqlClient.SqlParameter
            Dim pL489 As SqlClient.SqlParameter
            Dim pL490 As SqlClient.SqlParameter
            Dim pL491 As SqlClient.SqlParameter
            Dim pL492 As SqlClient.SqlParameter
            Dim pL493 As SqlClient.SqlParameter
            Dim pL494 As SqlClient.SqlParameter
            Dim pL495 As SqlClient.SqlParameter
            Dim pL496 As SqlClient.SqlParameter
            Dim pL497 As SqlClient.SqlParameter
            Dim pL498 As SqlClient.SqlParameter
            Dim pL499 As SqlClient.SqlParameter
            Dim pL499A As SqlClient.SqlParameter
            Dim pL499B As SqlClient.SqlParameter
            Dim pL499C As SqlClient.SqlParameter
            Dim pL499D As SqlClient.SqlParameter
            Dim pL501 As SqlClient.SqlParameter
            Dim pL502 As SqlClient.SqlParameter
            Dim pL503 As SqlClient.SqlParameter
            Dim pL504 As SqlClient.SqlParameter
            Dim pL505 As SqlClient.SqlParameter
            Dim pL506 As SqlClient.SqlParameter
            Dim pL507 As SqlClient.SqlParameter
            Dim pL508 As SqlClient.SqlParameter
            Dim pL509 As SqlClient.SqlParameter
            Dim pL510 As SqlClient.SqlParameter
            Dim pL511 As SqlClient.SqlParameter
            Dim pL512 As SqlClient.SqlParameter
            Dim pL513 As SqlClient.SqlParameter
            Dim pL514 As SqlClient.SqlParameter
            Dim pL515 As SqlClient.SqlParameter
            Dim pL516 As SqlClient.SqlParameter
            Dim pL517 As SqlClient.SqlParameter
            Dim pL518 As SqlClient.SqlParameter
            Dim pL519 As SqlClient.SqlParameter
            Dim pL520 As SqlClient.SqlParameter
            Dim pL521 As SqlClient.SqlParameter
            Dim pL522 As SqlClient.SqlParameter
            Dim pL523 As SqlClient.SqlParameter
            Dim pL524 As SqlClient.SqlParameter
            Dim pL525 As SqlClient.SqlParameter
            Dim pL526 As SqlClient.SqlParameter
            Dim pL527 As SqlClient.SqlParameter
            Dim pL528 As SqlClient.SqlParameter
            Dim pL529 As SqlClient.SqlParameter
            Dim pL530 As SqlClient.SqlParameter
            Dim pL531 As SqlClient.SqlParameter
            Dim pL532 As SqlClient.SqlParameter
            Dim pL533 As SqlClient.SqlParameter
            Dim pL534 As SqlClient.SqlParameter
            Dim pL535 As SqlClient.SqlParameter
            Dim pL536 As SqlClient.SqlParameter
            Dim pL537 As SqlClient.SqlParameter
            Dim pL540 As SqlClient.SqlParameter
            Dim pL541 As SqlClient.SqlParameter
            Dim pL542 As SqlClient.SqlParameter
            Dim pL543 As SqlClient.SqlParameter
            Dim pL544 As SqlClient.SqlParameter
            Dim pL545 As SqlClient.SqlParameter
            Dim pL546 As SqlClient.SqlParameter
            Dim pL547 As SqlClient.SqlParameter
            Dim pL548 As SqlClient.SqlParameter
            Dim pL549 As SqlClient.SqlParameter
            Dim pL550 As SqlClient.SqlParameter
            Dim pL551 As SqlClient.SqlParameter
            Dim pL552 As SqlClient.SqlParameter
            Dim pL553 As SqlClient.SqlParameter
            Dim pL554 As SqlClient.SqlParameter
            Dim pL555 As SqlClient.SqlParameter
            Dim pL556 As SqlClient.SqlParameter
            Dim pL557 As SqlClient.SqlParameter
            Dim pL558 As SqlClient.SqlParameter
            Dim pL559 As SqlClient.SqlParameter
            Dim pL560 As SqlClient.SqlParameter
            Dim pL561 As SqlClient.SqlParameter
            Dim pL562 As SqlClient.SqlParameter
            Dim pL563 As SqlClient.SqlParameter
            Dim pL564 As SqlClient.SqlParameter
            Dim pL565 As SqlClient.SqlParameter
            Dim pL566 As SqlClient.SqlParameter
            Dim pL570 As SqlClient.SqlParameter
            Dim pL571 As SqlClient.SqlParameter
            Dim pL572 As SqlClient.SqlParameter
            Dim pL573 As SqlClient.SqlParameter
            Dim pL574 As SqlClient.SqlParameter
            Dim pL575 As SqlClient.SqlParameter
            Dim pL576 As SqlClient.SqlParameter
            Dim pL577 As SqlClient.SqlParameter
            Dim pL578 As SqlClient.SqlParameter
            Dim pL579 As SqlClient.SqlParameter
            Dim pL580 As SqlClient.SqlParameter
            Dim pL581 As SqlClient.SqlParameter
            Dim pL582 As SqlClient.SqlParameter
            Dim pL583 As SqlClient.SqlParameter
            Dim pL584 As SqlClient.SqlParameter
            Dim pL585 As SqlClient.SqlParameter
            Dim pL586 As SqlClient.SqlParameter
            Dim pL587 As SqlClient.SqlParameter
            Dim pL601 As SqlClient.SqlParameter
            Dim pL602 As SqlClient.SqlParameter
            Dim pL603 As SqlClient.SqlParameter
            Dim pL604 As SqlClient.SqlParameter
            Dim pL605 As SqlClient.SqlParameter
            Dim pL606 As SqlClient.SqlParameter
            Dim pL607 As SqlClient.SqlParameter
            Dim pL608 As SqlClient.SqlParameter
            Dim pL609 As SqlClient.SqlParameter
            Dim pL610 As SqlClient.SqlParameter
            Dim pL611 As SqlClient.SqlParameter
            Dim pL612 As SqlClient.SqlParameter
            Dim pL613 As SqlClient.SqlParameter
            Dim pL614 As SqlClient.SqlParameter
            Dim pL615 As SqlClient.SqlParameter
            Dim pL616 As SqlClient.SqlParameter
            Dim pL617 As SqlClient.SqlParameter
            Dim pL618 As SqlClient.SqlParameter
            Dim pL619 As SqlClient.SqlParameter
            Dim pL620 As SqlClient.SqlParameter
            Dim pL621 As SqlClient.SqlParameter
            Dim pL622 As SqlClient.SqlParameter
            Dim pL623 As SqlClient.SqlParameter
            Dim pL624 As SqlClient.SqlParameter
            Dim pL625 As SqlClient.SqlParameter
            Dim pL626 As SqlClient.SqlParameter
            Dim pL627 As SqlClient.SqlParameter
            Dim pL628 As SqlClient.SqlParameter
            Dim pL629 As SqlClient.SqlParameter
            Dim pL630 As SqlClient.SqlParameter
            Dim pL631 As SqlClient.SqlParameter
            Dim pL632 As SqlClient.SqlParameter
            Dim pL633 As SqlClient.SqlParameter
            Dim pL634 As SqlClient.SqlParameter
            Dim pL635 As SqlClient.SqlParameter
            Dim pL636 As SqlClient.SqlParameter
            Dim pL637 As SqlClient.SqlParameter
            Dim pL638 As SqlClient.SqlParameter
            Dim pL639 As SqlClient.SqlParameter
            Dim pL640 As SqlClient.SqlParameter
            Dim pL641 As SqlClient.SqlParameter
            Dim pL642 As SqlClient.SqlParameter
            Dim pL643 As SqlClient.SqlParameter
            Dim pL644 As SqlClient.SqlParameter
            Dim pL645 As SqlClient.SqlParameter
            Dim pL646 As SqlClient.SqlParameter
            Dim pL647 As SqlClient.SqlParameter
            Dim pL648 As SqlClient.SqlParameter
            Dim pL649 As SqlClient.SqlParameter
            Dim pL650 As SqlClient.SqlParameter
            Dim pL651 As SqlClient.SqlParameter
            Dim pL652 As SqlClient.SqlParameter
            Dim pL653 As SqlClient.SqlParameter
            Dim pL654 As SqlClient.SqlParameter
            Dim pL655 As SqlClient.SqlParameter
            Dim pL656 As SqlClient.SqlParameter
            Dim pL657 As SqlClient.SqlParameter
            Dim pL658 As SqlClient.SqlParameter
            Dim pL659 As SqlClient.SqlParameter
            Dim pL660 As SqlClient.SqlParameter
            Dim pL661 As SqlClient.SqlParameter
            Dim pL662 As SqlClient.SqlParameter
            Dim pL663 As SqlClient.SqlParameter
            Dim pL664 As SqlClient.SqlParameter
            Dim pL665 As SqlClient.SqlParameter
            Dim pL666 As SqlClient.SqlParameter
            Dim pL667 As SqlClient.SqlParameter
            Dim pL668 As SqlClient.SqlParameter
            Dim pL669 As SqlClient.SqlParameter
            Dim pL670 As SqlClient.SqlParameter
            Dim pL671 As SqlClient.SqlParameter
            Dim pL672 As SqlClient.SqlParameter
            Dim pL673 As SqlClient.SqlParameter
            Dim pL674 As SqlClient.SqlParameter
            Dim pL675 As SqlClient.SqlParameter
            Dim pL676 As SqlClient.SqlParameter
            Dim pL677 As SqlClient.SqlParameter
            Dim pL678 As SqlClient.SqlParameter
            Dim pL679 As SqlClient.SqlParameter
            Dim pL680 As SqlClient.SqlParameter
            Dim pL681 As SqlClient.SqlParameter
            Dim pL682 As SqlClient.SqlParameter
            Dim pL683 As SqlClient.SqlParameter
            Dim pL684 As SqlClient.SqlParameter
            Dim pL685 As SqlClient.SqlParameter
            Dim pL686 As SqlClient.SqlParameter
            Dim pL687 As SqlClient.SqlParameter
            Dim pL688 As SqlClient.SqlParameter
            Dim pL689 As SqlClient.SqlParameter
            Dim pL690 As SqlClient.SqlParameter
            Dim pL691 As SqlClient.SqlParameter
            Dim pL692 As SqlClient.SqlParameter
            Dim pL693 As SqlClient.SqlParameter
            Dim pL694 As SqlClient.SqlParameter
            Dim pL695 As SqlClient.SqlParameter
            Dim pL696 As SqlClient.SqlParameter
            Dim pL697 As SqlClient.SqlParameter
            Dim pL698 As SqlClient.SqlParameter
            Dim pL699 As SqlClient.SqlParameter
            Dim pL700 As SqlClient.SqlParameter


            pLoopSegment = New SqlClient.SqlParameter
            pSerialNum = New SqlClient.SqlParameter
            pSegmentNumber = New SqlClient.SqlParameter
            pShipmentSize = New SqlClient.SqlParameter
            pSegmentType = New SqlClient.SqlParameter
            pCarType = New SqlClient.SqlParameter
            pOwnership = New SqlClient.SqlParameter
            pRR_ID = New SqlClient.SqlParameter
            pRR_Region = New SqlClient.SqlParameter
            pNum_Cars = New SqlClient.SqlParameter
            pNum_Cars_Expanded = New SqlClient.SqlParameter

            Try

                OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "EVALUES"))

                cmdWriteCommand = New SqlClient.SqlCommand
                cmdWriteCommand.CommandType = CommandType.StoredProcedure
                If bLeg Then
                    cmdWriteCommand.CommandText = "usp_WriteCRPSEG_Legacy" ' Procedure Name from SQL
                Else
                    cmdWriteCommand.CommandText = "usp_WriteCRPSEG" ' Procedure Name from SQL
                End If
                cmdWriteCommand.Connection = Global_Variables.gbl_SQLConnection

                'iLoopSegment
                pLoopSegment = New SqlClient.SqlParameter
                pLoopSegment.ParameterName = "@loopSegment"
                pLoopSegment.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pLoopSegment)
                cmdWriteCommand.Parameters("@loopSegment").Value = Integer.Parse(loopSeg)

                'iSerialNum
                pSerialNum = New SqlClient.SqlParameter
                pSerialNum.ParameterName = "@SerialNum"
                pSerialNum.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pSerialNum)
                cmdWriteCommand.Parameters("@SerialNum").Value = Integer.Parse(iSerialNum)

                'iSegmentNumber
                pSegmentNumber = New SqlClient.SqlParameter
                pSegmentNumber.ParameterName = "@SegmentNumber"
                pSegmentNumber.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pSegmentNumber)
                cmdWriteCommand.Parameters("@SegmentNumber").Value = Integer.Parse(iSegmentNumber)

                'sShipmentSize
                pShipmentSize = New SqlClient.SqlParameter
                pShipmentSize.ParameterName = "@ShipmentSize"
                pShipmentSize.DbType = DbType.String

                cmdWriteCommand.Parameters.Add(pShipmentSize)
                cmdWriteCommand.Parameters("@ShipmentSize").Value = sShipmentSize.ToString()

                'sSegmentType
                pSegmentType = New SqlClient.SqlParameter
                pSegmentType.ParameterName = "@SegmentType"
                pSegmentType.DbType = DbType.String

                cmdWriteCommand.Parameters.Add(pSegmentType)
                cmdWriteCommand.Parameters("@SegmentType").Value = sSegmentType.ToString()

                'pCarType
                pCarType = New SqlClient.SqlParameter
                pCarType.ParameterName = "@CarType"
                pCarType.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pCarType)
                cmdWriteCommand.Parameters("@CarType").Value = Integer.Parse(iCarType)

                'pOwnership
                pOwnership = New SqlClient.SqlParameter
                pOwnership.ParameterName = "@Ownership"
                pOwnership.DbType = DbType.String

                cmdWriteCommand.Parameters.Add(pOwnership)
                cmdWriteCommand.Parameters("@Ownership").Value = sOwnership.ToString()

                'pRR_ID
                pRR_ID = New SqlClient.SqlParameter
                pRR_ID.ParameterName = "@RR_ID"
                pRR_ID.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pRR_ID)
                cmdWriteCommand.Parameters("@RR_ID").Value = Integer.Parse(iRailroadNumber)

                'pRR_Region
                pRR_Region = New SqlClient.SqlParameter
                pRR_Region.ParameterName = "@RR_Region"
                pRR_Region.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pRR_Region)
                cmdWriteCommand.Parameters("@RR_Region").Value = Integer.Parse(getRailroadRegionID(iRailroadNumber))

                'pNum_Cars
                pNum_Cars = New SqlClient.SqlParameter
                pNum_Cars.ParameterName = "@Num_Cars"
                pNum_Cars.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pNum_Cars)
                cmdWriteCommand.Parameters("@Num_Cars").Value = Integer.Parse(iNumCars)

                'pNum_Cars_Expanded
                pNum_Cars_Expanded = New SqlClient.SqlParameter
                pNum_Cars_Expanded.ParameterName = "@Num_Cars_Expanded"
                pNum_Cars_Expanded.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pNum_Cars_Expanded)
                cmdWriteCommand.Parameters("@Num_Cars_Expanded").Value = Integer.Parse(iNumCarsExpanded)

                'iL101
                pL101 = New SqlClient.SqlParameter
                pL101.ParameterName = "@L101"
                pL101.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pL101)
                cmdWriteCommand.Parameters("@L101").Value = Integer.Parse(iL101)

                'iL102
                pL102 = New SqlClient.SqlParameter
                pL102.ParameterName = "@L102"
                pL102.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pL102)
                cmdWriteCommand.Parameters("@L102").Value = Integer.Parse(iL102)

                'iL103
                pL103 = New SqlClient.SqlParameter
                pL103.ParameterName = "@L103"
                pL103.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pL103)
                cmdWriteCommand.Parameters("@L103").Value = Integer.Parse(iL103)

                'iL104
                pL104 = New SqlClient.SqlParameter
                pL104.ParameterName = "@L104"
                pL104.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pL104)
                cmdWriteCommand.Parameters("@L104").Value = Integer.Parse(iL104)

                'dL105
                pL105 = New SqlClient.SqlParameter
                pL105.ParameterName = "@L105"
                pL105.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL105)
                cmdWriteCommand.Parameters("@L105").Value = Double.Parse(dL105)

                'dL106
                pL106 = New SqlClient.SqlParameter
                pL106.ParameterName = "@L106"
                pL106.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL106)
                cmdWriteCommand.Parameters("@L106").Value = Double.Parse(dL106)

                'dL107
                pL107 = New SqlClient.SqlParameter
                pL107.ParameterName = "@L107"
                pL107.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL107)
                cmdWriteCommand.Parameters("@L107").Value = Double.Parse(dL107)

                'dL108
                pL108 = New SqlClient.SqlParameter
                pL108.ParameterName = "@L108"
                pL108.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL108)
                cmdWriteCommand.Parameters("@L108").Value = Double.Parse(dL108)

                'dL109
                pL109 = New SqlClient.SqlParameter
                pL109.ParameterName = "@L109"
                pL109.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL109)
                cmdWriteCommand.Parameters("@L109").Value = Double.Parse(dL109)

                'dL110
                pL110 = New SqlClient.SqlParameter
                pL110.ParameterName = "@L110"
                pL110.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL110)
                cmdWriteCommand.Parameters("@L110").Value = Double.Parse(dL110)

                'dL111
                pL111 = New SqlClient.SqlParameter
                pL111.ParameterName = "@L111"
                pL111.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL111)
                cmdWriteCommand.Parameters("@L111").Value = Double.Parse(dL111)

                'iL201
                pL201 = New SqlClient.SqlParameter
                pL201.ParameterName = "@L201"
                pL201.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL201)
                cmdWriteCommand.Parameters("@L201").Value = Double.Parse(iL201)

                'dL202
                pL202 = New SqlClient.SqlParameter
                pL202.ParameterName = "@L202"
                pL202.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL202)
                cmdWriteCommand.Parameters("@L202").Value = Double.Parse(dL202)

                'dL203
                pL203 = New SqlClient.SqlParameter
                pL203.ParameterName = "@L203"
                pL203.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL203)
                cmdWriteCommand.Parameters("@L203").Value = Double.Parse(dL203)

                'dL204
                pL204 = New SqlClient.SqlParameter
                pL204.ParameterName = "@L204"
                pL204.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL204)
                cmdWriteCommand.Parameters("@L204").Value = Double.Parse(dL204)

                'dL205
                pL205 = New SqlClient.SqlParameter
                pL205.ParameterName = "@L205"
                pL205.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL205)
                cmdWriteCommand.Parameters("@L205").Value = Double.Parse(dL205)

                'dL206
                pL206 = New SqlClient.SqlParameter
                pL206.ParameterName = "@L206"
                pL206.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL206)
                cmdWriteCommand.Parameters("@L206").Value = Double.Parse(dL206)

                'dL207
                pL207 = New SqlClient.SqlParameter
                pL207.ParameterName = "@L207"
                pL207.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL207)
                cmdWriteCommand.Parameters("@L207").Value = Double.Parse(dL207)

                'dL208
                pL208 = New SqlClient.SqlParameter
                pL208.ParameterName = "@L208"
                pL208.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL208)
                cmdWriteCommand.Parameters("@L208").Value = Double.Parse(dL208)

                'dL209
                pL209 = New SqlClient.SqlParameter
                pL209.ParameterName = "@L209"
                pL209.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL209)
                cmdWriteCommand.Parameters("@L209").Value = Double.Parse(dL209)

                'dL210
                pL210 = New SqlClient.SqlParameter
                pL210.ParameterName = "@L210"
                pL210.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL210)
                cmdWriteCommand.Parameters("@L210").Value = Double.Parse(dL210)

                'dL211
                pL211 = New SqlClient.SqlParameter
                pL211.ParameterName = "@L211"
                pL211.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL211)
                cmdWriteCommand.Parameters("@L211").Value = Double.Parse(dL211)

                'dL212
                pL212 = New SqlClient.SqlParameter
                pL212.ParameterName = "@L212"
                pL212.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL212)
                cmdWriteCommand.Parameters("@L212").Value = Double.Parse(dL212)

                'dL213
                pL213 = New SqlClient.SqlParameter
                pL213.ParameterName = "@L213"
                pL213.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL213)
                cmdWriteCommand.Parameters("@L213").Value = Double.Parse(dL213)

                'dL214
                pL214 = New SqlClient.SqlParameter
                pL214.ParameterName = "@L214"
                pL214.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL214)
                cmdWriteCommand.Parameters("@L214").Value = Double.Parse(dL214)

                'dL215
                pL215 = New SqlClient.SqlParameter
                pL215.ParameterName = "@L215"
                pL215.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL215)
                cmdWriteCommand.Parameters("@L215").Value = Double.Parse(dL215)

                'dL216
                pL216 = New SqlClient.SqlParameter
                pL216.ParameterName = "@L216"
                pL216.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL216)
                cmdWriteCommand.Parameters("@L216").Value = Double.Parse(dL216)

                'iL217
                pL217 = New SqlClient.SqlParameter
                pL217.ParameterName = "@L217"
                pL217.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL217)
                cmdWriteCommand.Parameters("@L217").Value = Double.Parse(iL217)

                'iL218
                pL218 = New SqlClient.SqlParameter
                pL218.ParameterName = "@L218"
                pL218.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL218)
                cmdWriteCommand.Parameters("@L218").Value = Double.Parse(iL218)

                'dL219
                pL219 = New SqlClient.SqlParameter
                pL219.ParameterName = "@L219"
                pL219.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL219)
                cmdWriteCommand.Parameters("@L219").Value = Double.Parse(dL219)

                'dL220
                pL220 = New SqlClient.SqlParameter
                pL220.ParameterName = "@L220"
                pL220.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL220)
                cmdWriteCommand.Parameters("@L220").Value = Double.Parse(dL220)

                'dL221
                pL221 = New SqlClient.SqlParameter
                pL221.ParameterName = "@L221"
                pL221.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL221)
                cmdWriteCommand.Parameters("@L221").Value = Double.Parse(dL221)

                'dL222
                pL222 = New SqlClient.SqlParameter
                pL222.ParameterName = "@L222"
                pL222.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL222)
                cmdWriteCommand.Parameters("@L222").Value = Double.Parse(dL222)

                'dL223
                pL223 = New SqlClient.SqlParameter
                pL223.ParameterName = "@L223"
                pL223.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL223)
                cmdWriteCommand.Parameters("@L223").Value = Double.Parse(dL223)

                'dL224
                pL224 = New SqlClient.SqlParameter
                pL224.ParameterName = "@L224"
                pL224.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL224)
                cmdWriteCommand.Parameters("@L224").Value = Double.Parse(dL224)

                'dL225
                pL225 = New SqlClient.SqlParameter
                pL225.ParameterName = "@L225"
                pL225.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL225)
                cmdWriteCommand.Parameters("@L225").Value = Double.Parse(dL225)

                'dL226
                pL226 = New SqlClient.SqlParameter
                pL226.ParameterName = "@L226"
                pL226.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL226)
                cmdWriteCommand.Parameters("@L226").Value = Double.Parse(dL226)

                'dL227
                pL227 = New SqlClient.SqlParameter
                pL227.ParameterName = "@L227"
                pL227.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL227)
                cmdWriteCommand.Parameters("@L227").Value = Double.Parse(dL227)

                'dL228
                pL228 = New SqlClient.SqlParameter
                pL228.ParameterName = "@L228"
                pL228.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL228)
                cmdWriteCommand.Parameters("@L228").Value = Double.Parse(dL228)

                'dL229
                pL229 = New SqlClient.SqlParameter
                pL229.ParameterName = "@L229"
                pL229.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL229)
                cmdWriteCommand.Parameters("@L229").Value = Double.Parse(dL229)

                'dL230
                pL230 = New SqlClient.SqlParameter
                pL230.ParameterName = "@L230"
                pL230.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL230)
                cmdWriteCommand.Parameters("@L230").Value = Double.Parse(dL230)

                'dL231
                pL231 = New SqlClient.SqlParameter
                pL231.ParameterName = "@L231"
                pL231.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL231)
                cmdWriteCommand.Parameters("@L231").Value = Double.Parse(dL231)

                'dL232
                pL232 = New SqlClient.SqlParameter
                pL232.ParameterName = "@L232"
                pL232.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL232)
                cmdWriteCommand.Parameters("@L232").Value = Double.Parse(dL232)

                'dL233
                pL233 = New SqlClient.SqlParameter
                pL233.ParameterName = "@L233"
                pL233.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL233)
                cmdWriteCommand.Parameters("@L233").Value = Double.Parse(dL233)

                'dL234
                pL234 = New SqlClient.SqlParameter
                pL234.ParameterName = "@L234"
                pL234.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL234)
                cmdWriteCommand.Parameters("@L234").Value = Double.Parse(dL234)

                'dL235
                pL235 = New SqlClient.SqlParameter
                pL235.ParameterName = "@L235"
                pL235.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL235)
                cmdWriteCommand.Parameters("@L235").Value = Double.Parse(dL235)

                'dL236
                pL236 = New SqlClient.SqlParameter
                pL236.ParameterName = "@L236"
                pL236.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL236)
                cmdWriteCommand.Parameters("@L236").Value = Double.Parse(dL236)

                'dL237
                pL237 = New SqlClient.SqlParameter
                pL237.ParameterName = "@L237"
                pL237.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL237)
                cmdWriteCommand.Parameters("@L237").Value = Double.Parse(dL237)

                'dL238
                pL238 = New SqlClient.SqlParameter
                pL238.ParameterName = "@L238"
                pL238.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL238)
                cmdWriteCommand.Parameters("@L238").Value = Double.Parse(dL238)

                'dL239
                pL239 = New SqlClient.SqlParameter
                pL239.ParameterName = "@L239"
                pL239.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL239)
                cmdWriteCommand.Parameters("@L239").Value = Double.Parse(dL239)

                'dL240
                pL240 = New SqlClient.SqlParameter
                pL240.ParameterName = "@L240"
                pL240.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL240)
                cmdWriteCommand.Parameters("@L240").Value = Double.Parse(dL240)

                'dL241
                pL241 = New SqlClient.SqlParameter
                pL241.ParameterName = "@L241"
                pL241.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL241)
                cmdWriteCommand.Parameters("@L241").Value = Double.Parse(dL241)

                'dL242
                pL242 = New SqlClient.SqlParameter
                pL242.ParameterName = "@L242"
                pL242.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL242)
                cmdWriteCommand.Parameters("@L242").Value = Double.Parse(dL242)

                'dL243
                pL243 = New SqlClient.SqlParameter
                pL243.ParameterName = "@L243"
                pL243.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL243)
                cmdWriteCommand.Parameters("@L243").Value = Double.Parse(dL243)

                'dL244
                pL244 = New SqlClient.SqlParameter
                pL244.ParameterName = "@L244"
                pL244.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL244)
                cmdWriteCommand.Parameters("@L244").Value = Double.Parse(dL244)

                'dL245
                pL245 = New SqlClient.SqlParameter
                pL245.ParameterName = "@L245"
                pL245.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL245)
                cmdWriteCommand.Parameters("@L245").Value = Double.Parse(dL245)

                'dL246
                pL246 = New SqlClient.SqlParameter
                pL246.ParameterName = "@L246"
                pL246.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL246)
                cmdWriteCommand.Parameters("@L246").Value = Double.Parse(dL246)

                'dL247
                pL247 = New SqlClient.SqlParameter
                pL247.ParameterName = "@L247"
                pL247.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL247)
                cmdWriteCommand.Parameters("@L247").Value = Double.Parse(dL247)

                'dL248
                pL248 = New SqlClient.SqlParameter
                pL248.ParameterName = "@L248"
                pL248.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL248)
                cmdWriteCommand.Parameters("@L248").Value = Double.Parse(dL248)

                'iL250
                pL250 = New SqlClient.SqlParameter
                pL250.ParameterName = "@L250"
                pL250.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pL250)
                cmdWriteCommand.Parameters("@L250").Value = Integer.Parse(iL250)

                'dL251
                pL251 = New SqlClient.SqlParameter
                pL251.ParameterName = "@L251"
                pL251.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL251)
                cmdWriteCommand.Parameters("@L251").Value = Double.Parse(dL251)

                'dL252
                pL252 = New SqlClient.SqlParameter
                pL252.ParameterName = "@L252"
                pL252.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL252)
                cmdWriteCommand.Parameters("@L252").Value = Double.Parse(dL252)

                'dL253
                pL253 = New SqlClient.SqlParameter
                pL253.ParameterName = "@L253"
                pL253.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL253)
                cmdWriteCommand.Parameters("@L253").Value = Double.Parse(dL253)

                'dL254
                pL254 = New SqlClient.SqlParameter
                pL254.ParameterName = "@L254"
                pL254.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL254)
                cmdWriteCommand.Parameters("@L254").Value = Double.Parse(dL254)

                'dL255
                pL255 = New SqlClient.SqlParameter
                pL255.ParameterName = "@L255"
                pL255.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL255)
                cmdWriteCommand.Parameters("@L255").Value = Double.Parse(dL255)

                'dL256
                pL256 = New SqlClient.SqlParameter
                pL256.ParameterName = "@L256"
                pL256.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL256)
                cmdWriteCommand.Parameters("@L256").Value = Double.Parse(dL256)

                'dL257
                pL257 = New SqlClient.SqlParameter
                pL257.ParameterName = "@L257"
                pL257.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL257)
                cmdWriteCommand.Parameters("@L257").Value = Double.Parse(dL257)

                'dL258
                pL258 = New SqlClient.SqlParameter
                pL258.ParameterName = "@L258"
                pL258.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL258)
                cmdWriteCommand.Parameters("@L258").Value = Double.Parse(dL258)

                'dL259
                pL259 = New SqlClient.SqlParameter
                pL259.ParameterName = "@L259"
                pL259.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL259)
                cmdWriteCommand.Parameters("@L259").Value = Double.Parse(dL259)

                'dL260
                pL260 = New SqlClient.SqlParameter
                pL260.ParameterName = "@L260"
                pL260.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL260)
                cmdWriteCommand.Parameters("@L260").Value = Double.Parse(dL260)

                'dL261
                pL261 = New SqlClient.SqlParameter
                pL261.ParameterName = "@L261"
                pL261.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL261)
                cmdWriteCommand.Parameters("@L261").Value = Double.Parse(dL261)

                'dL262
                pL262 = New SqlClient.SqlParameter
                pL262.ParameterName = "@L262"
                pL262.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL262)
                cmdWriteCommand.Parameters("@L262").Value = Double.Parse(dL262)

                'dL263
                pL263 = New SqlClient.SqlParameter
                pL263.ParameterName = "@L263"
                pL263.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL263)
                cmdWriteCommand.Parameters("@L263").Value = Double.Parse(dL263)

                'dL264
                pL264 = New SqlClient.SqlParameter
                pL264.ParameterName = "@L264"
                pL264.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL264)
                cmdWriteCommand.Parameters("@L264").Value = Double.Parse(dL264)

                'dL265
                pL265 = New SqlClient.SqlParameter
                pL265.ParameterName = "@L265"
                pL265.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL265)
                cmdWriteCommand.Parameters("@L265").Value = Double.Parse(dL265)

                'dL266
                pL266 = New SqlClient.SqlParameter
                pL266.ParameterName = "@L266"
                pL266.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL266)
                cmdWriteCommand.Parameters("@L266").Value = Double.Parse(dL266)

                'dL267
                pL267 = New SqlClient.SqlParameter
                pL267.ParameterName = "@L267"
                pL267.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL267)
                cmdWriteCommand.Parameters("@L267").Value = Double.Parse(dL267)

                'dL268
                pL268 = New SqlClient.SqlParameter
                pL268.ParameterName = "@L268"
                pL268.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL268)
                cmdWriteCommand.Parameters("@L268").Value = Double.Parse(dL268)

                'dL269
                pL269 = New SqlClient.SqlParameter
                pL269.ParameterName = "@L269"
                pL269.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL269)
                cmdWriteCommand.Parameters("@L269").Value = Double.Parse(dL269)

                'dL270
                pL270 = New SqlClient.SqlParameter
                pL270.ParameterName = "@L270"
                pL270.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL270)
                cmdWriteCommand.Parameters("@L270").Value = Double.Parse(dL270)

                'dL271
                pL271 = New SqlClient.SqlParameter
                pL271.ParameterName = "@L271"
                pL271.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL271)
                cmdWriteCommand.Parameters("@L271").Value = Double.Parse(dL271)

                'dL272
                pL272 = New SqlClient.SqlParameter
                pL272.ParameterName = "@L272"
                pL272.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL272)
                cmdWriteCommand.Parameters("@L272").Value = Double.Parse(dL272)

                'dL273
                pL273 = New SqlClient.SqlParameter
                pL273.ParameterName = "@L273"
                pL273.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL273)
                cmdWriteCommand.Parameters("@L273").Value = Double.Parse(dL273)

                'dL274
                pL274 = New SqlClient.SqlParameter
                pL274.ParameterName = "@L274"
                pL274.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL274)
                cmdWriteCommand.Parameters("@L274").Value = Double.Parse(dL274)

                'dL275
                pL275 = New SqlClient.SqlParameter
                pL275.ParameterName = "@L275"
                pL275.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL275)
                cmdWriteCommand.Parameters("@L275").Value = Double.Parse(dL275)

                'dL276
                pL276 = New SqlClient.SqlParameter
                pL276.ParameterName = "@L276"
                pL276.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL276)
                cmdWriteCommand.Parameters("@L276").Value = Double.Parse(dL276)

                'dL277
                pL277 = New SqlClient.SqlParameter
                pL277.ParameterName = "@L277"
                pL277.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL277)
                cmdWriteCommand.Parameters("@L277").Value = Double.Parse(dL277)

                'dL278
                pL278 = New SqlClient.SqlParameter
                pL278.ParameterName = "@L278"
                pL278.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL278)
                cmdWriteCommand.Parameters("@L278").Value = Double.Parse(dL278)

                'dL279
                pL279 = New SqlClient.SqlParameter
                pL279.ParameterName = "@L279"
                pL279.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL279)
                cmdWriteCommand.Parameters("@L279").Value = Double.Parse(dL279)

                'dL280
                pL280 = New SqlClient.SqlParameter
                pL280.ParameterName = "@L280"
                pL280.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL280)
                cmdWriteCommand.Parameters("@L280").Value = Double.Parse(dL280)

                'dL281
                pL281 = New SqlClient.SqlParameter
                pL281.ParameterName = "@L281"
                pL281.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL281)
                cmdWriteCommand.Parameters("@L281").Value = Double.Parse(dL281)

                'dL282
                pL282 = New SqlClient.SqlParameter
                pL282.ParameterName = "@L282"
                pL282.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL282)
                cmdWriteCommand.Parameters("@L282").Value = Double.Parse(dL282)

                'dL283
                pL283 = New SqlClient.SqlParameter
                pL283.ParameterName = "@L283"
                pL283.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL283)
                cmdWriteCommand.Parameters("@L283").Value = Double.Parse(dL283)

                'dL284
                pL284 = New SqlClient.SqlParameter
                pL284.ParameterName = "@L284"
                pL284.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL284)
                cmdWriteCommand.Parameters("@L284").Value = Double.Parse(dL284)

                'dL285
                pL285 = New SqlClient.SqlParameter
                pL285.ParameterName = "@L285"
                pL285.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL285)
                cmdWriteCommand.Parameters("@L285").Value = Double.Parse(dL285)

                'dL286
                pL286 = New SqlClient.SqlParameter
                pL286.ParameterName = "@L286"
                pL286.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL286)
                cmdWriteCommand.Parameters("@L286").Value = Double.Parse(dL286)

                'dL287
                pL287 = New SqlClient.SqlParameter
                pL287.ParameterName = "@L287"
                pL287.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL287)
                cmdWriteCommand.Parameters("@L287").Value = Double.Parse(dL287)

                'dL288
                pL288 = New SqlClient.SqlParameter
                pL288.ParameterName = "@L288"
                pL288.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL288)
                cmdWriteCommand.Parameters("@L288").Value = Double.Parse(dL288)

                'dL289
                pL289 = New SqlClient.SqlParameter
                pL289.ParameterName = "@L289"
                pL289.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL289)
                cmdWriteCommand.Parameters("@L289").Value = Double.Parse(dL289)

                'dL290
                pL290 = New SqlClient.SqlParameter
                pL290.ParameterName = "@L290"
                pL290.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL290)
                cmdWriteCommand.Parameters("@L290").Value = Double.Parse(dL290)

                'dL301
                pL301 = New SqlClient.SqlParameter
                pL301.ParameterName = "@L301"
                pL301.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL301)
                cmdWriteCommand.Parameters("@L301").Value = Double.Parse(dL301)

                'dL302
                pL302 = New SqlClient.SqlParameter
                pL302.ParameterName = "@L302"
                pL302.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL302)
                cmdWriteCommand.Parameters("@L302").Value = Double.Parse(dL302)

                'dL303
                pL303 = New SqlClient.SqlParameter
                pL303.ParameterName = "@L303"
                pL303.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL303)
                cmdWriteCommand.Parameters("@L303").Value = Double.Parse(dL303)

                'dL304
                pL304 = New SqlClient.SqlParameter
                pL304.ParameterName = "@L304"
                pL304.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL304)
                cmdWriteCommand.Parameters("@L304").Value = Double.Parse(dL304)

                'dL305
                pL305 = New SqlClient.SqlParameter
                pL305.ParameterName = "@L305"
                pL305.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL305)
                cmdWriteCommand.Parameters("@L305").Value = Double.Parse(dL305)

                'dL306
                pL306 = New SqlClient.SqlParameter
                pL306.ParameterName = "@L306"
                pL306.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL306)
                cmdWriteCommand.Parameters("@L306").Value = Double.Parse(dL306)

                'dL307
                pL307 = New SqlClient.SqlParameter
                pL307.ParameterName = "@L307"
                pL307.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL307)
                cmdWriteCommand.Parameters("@L307").Value = Double.Parse(dL307)

                'dL308
                pL308 = New SqlClient.SqlParameter
                pL308.ParameterName = "@L308"
                pL308.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL308)
                cmdWriteCommand.Parameters("@L308").Value = Double.Parse(dL308)

                'dL309
                pL309 = New SqlClient.SqlParameter
                pL309.ParameterName = "@L309"
                pL309.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL309)
                cmdWriteCommand.Parameters("@L309").Value = Double.Parse(dL309)

                'dL310
                pL310 = New SqlClient.SqlParameter
                pL310.ParameterName = "@L310"
                pL310.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL310)
                cmdWriteCommand.Parameters("@L310").Value = Double.Parse(dL310)

                'dL311
                pL311 = New SqlClient.SqlParameter
                pL311.ParameterName = "@L311"
                pL311.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL311)
                cmdWriteCommand.Parameters("@L311").Value = Double.Parse(dL311)

                'dL312
                pL312 = New SqlClient.SqlParameter
                pL312.ParameterName = "@L312"
                pL312.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL312)
                cmdWriteCommand.Parameters("@L312").Value = Double.Parse(dL312)

                'dL313
                pL313 = New SqlClient.SqlParameter
                pL313.ParameterName = "@L313"
                pL313.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL313)
                cmdWriteCommand.Parameters("@L313").Value = Double.Parse(dL313)

                'dL314
                pL314 = New SqlClient.SqlParameter
                pL314.ParameterName = "@L314"
                pL314.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL314)
                cmdWriteCommand.Parameters("@L314").Value = Double.Parse(dL314)

                'dL315
                pL315 = New SqlClient.SqlParameter
                pL315.ParameterName = "@L315"
                pL315.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL315)
                cmdWriteCommand.Parameters("@L315").Value = Double.Parse(dL315)

                'dL316
                pL316 = New SqlClient.SqlParameter
                pL316.ParameterName = "@L316"
                pL316.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL316)
                cmdWriteCommand.Parameters("@L316").Value = Double.Parse(dL316)

                'dL317
                pL317 = New SqlClient.SqlParameter
                pL317.ParameterName = "@L317"
                pL317.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL317)
                cmdWriteCommand.Parameters("@L317").Value = Double.Parse(dL317)

                'dL318
                pL318 = New SqlClient.SqlParameter
                pL318.ParameterName = "@L318"
                pL318.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL318)
                cmdWriteCommand.Parameters("@L318").Value = Double.Parse(dL318)

                'dL319
                pL319 = New SqlClient.SqlParameter
                pL319.ParameterName = "@L319"
                pL319.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL319)
                cmdWriteCommand.Parameters("@L319").Value = Double.Parse(dL319)

                'dL320
                pL320 = New SqlClient.SqlParameter
                pL320.ParameterName = "@L320"
                pL320.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL320)
                cmdWriteCommand.Parameters("@L320").Value = Double.Parse(dL320)

                'dL321
                pL321 = New SqlClient.SqlParameter
                pL321.ParameterName = "@L321"
                pL321.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL321)
                cmdWriteCommand.Parameters("@L321").Value = Double.Parse(dL321)

                'dL322
                pL322 = New SqlClient.SqlParameter
                pL322.ParameterName = "@L322"
                pL322.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL322)
                cmdWriteCommand.Parameters("@L322").Value = Double.Parse(dL322)

                'dL323
                pL323 = New SqlClient.SqlParameter
                pL323.ParameterName = "@L323"
                pL323.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL323)
                cmdWriteCommand.Parameters("@L323").Value = Double.Parse(dL323)

                'dL324
                pL324 = New SqlClient.SqlParameter
                pL324.ParameterName = "@L324"
                pL324.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL324)
                cmdWriteCommand.Parameters("@L324").Value = Double.Parse(dL324)

                'dL325
                pL325 = New SqlClient.SqlParameter
                pL325.ParameterName = "@L325"
                pL325.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL325)
                cmdWriteCommand.Parameters("@L325").Value = Double.Parse(dL325)

                'dL326
                pL326 = New SqlClient.SqlParameter
                pL326.ParameterName = "@L326"
                pL326.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL326)
                cmdWriteCommand.Parameters("@L326").Value = Double.Parse(dL326)

                'dL327
                pL327 = New SqlClient.SqlParameter
                pL327.ParameterName = "@L327"
                pL327.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL327)
                cmdWriteCommand.Parameters("@L327").Value = Double.Parse(dL327)

                'dL328
                pL328 = New SqlClient.SqlParameter
                pL328.ParameterName = "@L328"
                pL328.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL328)
                cmdWriteCommand.Parameters("@L328").Value = Double.Parse(dL328)

                'dL329
                pL329 = New SqlClient.SqlParameter
                pL329.ParameterName = "@L329"
                pL329.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL329)
                cmdWriteCommand.Parameters("@L329").Value = Double.Parse(dL329)

                'dL330
                pL330 = New SqlClient.SqlParameter
                pL330.ParameterName = "@L330"
                pL330.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL330)
                cmdWriteCommand.Parameters("@L330").Value = Double.Parse(dL330)

                'dL331
                pL331 = New SqlClient.SqlParameter
                pL331.ParameterName = "@L331"
                pL331.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL331)
                cmdWriteCommand.Parameters("@L331").Value = Double.Parse(dL331)

                'dL332
                pL332 = New SqlClient.SqlParameter
                pL332.ParameterName = "@L332"
                pL332.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL332)
                cmdWriteCommand.Parameters("@L332").Value = Double.Parse(dL332)

                'dL333
                pL333 = New SqlClient.SqlParameter
                pL333.ParameterName = "@L333"
                pL333.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL333)
                cmdWriteCommand.Parameters("@L333").Value = Double.Parse(dL333)

                'dL334
                pL334 = New SqlClient.SqlParameter
                pL334.ParameterName = "@L334"
                pL334.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL334)
                cmdWriteCommand.Parameters("@L334").Value = Double.Parse(dL334)

                'dL401
                pL401 = New SqlClient.SqlParameter
                pL401.ParameterName = "@L401"
                pL401.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL401)
                cmdWriteCommand.Parameters("@L401").Value = Double.Parse(dL401)

                'dL402
                pL402 = New SqlClient.SqlParameter
                pL402.ParameterName = "@L402"
                pL402.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL402)
                cmdWriteCommand.Parameters("@L402").Value = Double.Parse(dL402)

                'dL403
                pL403 = New SqlClient.SqlParameter
                pL403.ParameterName = "@L403"
                pL403.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL403)
                cmdWriteCommand.Parameters("@L403").Value = Double.Parse(dL403)

                'dL404
                pL404 = New SqlClient.SqlParameter
                pL404.ParameterName = "@L404"
                pL404.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL404)
                cmdWriteCommand.Parameters("@L404").Value = Double.Parse(dL404)

                'dL405
                pL405 = New SqlClient.SqlParameter
                pL405.ParameterName = "@L405"
                pL405.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL405)
                cmdWriteCommand.Parameters("@L405").Value = Double.Parse(dL405)

                'dL406
                pL406 = New SqlClient.SqlParameter
                pL406.ParameterName = "@L406"
                pL406.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL406)
                cmdWriteCommand.Parameters("@L406").Value = Double.Parse(dL406)

                'dL407
                pL407 = New SqlClient.SqlParameter
                pL407.ParameterName = "@L407"
                pL407.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL407)
                cmdWriteCommand.Parameters("@L407").Value = Double.Parse(dL407)

                'dL408
                pL408 = New SqlClient.SqlParameter
                pL408.ParameterName = "@L408"
                pL408.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL408)
                cmdWriteCommand.Parameters("@L408").Value = Double.Parse(dL408)

                'dL409
                pL409 = New SqlClient.SqlParameter
                pL409.ParameterName = "@L409"
                pL409.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL409)
                cmdWriteCommand.Parameters("@L409").Value = Double.Parse(dL409)

                'dL410
                pL410 = New SqlClient.SqlParameter
                pL410.ParameterName = "@L410"
                pL410.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL410)
                cmdWriteCommand.Parameters("@L410").Value = Double.Parse(dL410)

                'dL411
                pL411 = New SqlClient.SqlParameter
                pL411.ParameterName = "@L411"
                pL411.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL411)
                cmdWriteCommand.Parameters("@L411").Value = Double.Parse(dL411)

                'dL412
                pL412 = New SqlClient.SqlParameter
                pL412.ParameterName = "@L412"
                pL412.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL412)
                cmdWriteCommand.Parameters("@L412").Value = Double.Parse(dL412)

                'dL413
                pL413 = New SqlClient.SqlParameter
                pL413.ParameterName = "@L413"
                pL413.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL413)
                cmdWriteCommand.Parameters("@L413").Value = Double.Parse(dL413)

                'dL414
                pL414 = New SqlClient.SqlParameter
                pL414.ParameterName = "@L414"
                pL414.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL414)
                cmdWriteCommand.Parameters("@L414").Value = Double.Parse(dL414)

                'dL415
                pL415 = New SqlClient.SqlParameter
                pL415.ParameterName = "@L415"
                pL415.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL415)
                cmdWriteCommand.Parameters("@L415").Value = Double.Parse(dL415)

                'dL416
                pL416 = New SqlClient.SqlParameter
                pL416.ParameterName = "@L416"
                pL416.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL416)
                cmdWriteCommand.Parameters("@L416").Value = Double.Parse(dL416)

                'dL417
                pL417 = New SqlClient.SqlParameter
                pL417.ParameterName = "@L417"
                pL417.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL417)
                cmdWriteCommand.Parameters("@L417").Value = Double.Parse(dL417)

                'dL418
                pL418 = New SqlClient.SqlParameter
                pL418.ParameterName = "@L418"
                pL418.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL418)
                cmdWriteCommand.Parameters("@L418").Value = Double.Parse(dL418)

                'dL419
                pL419 = New SqlClient.SqlParameter
                pL419.ParameterName = "@L419"
                pL419.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL419)
                cmdWriteCommand.Parameters("@L419").Value = Double.Parse(dL419)

                'dL420
                pL420 = New SqlClient.SqlParameter
                pL420.ParameterName = "@L420"
                pL420.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL420)
                cmdWriteCommand.Parameters("@L420").Value = Double.Parse(dL420)

                'dL421
                pL421 = New SqlClient.SqlParameter
                pL421.ParameterName = "@L421"
                pL421.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL421)
                cmdWriteCommand.Parameters("@L421").Value = Double.Parse(dL421)

                'dL422
                pL422 = New SqlClient.SqlParameter
                pL422.ParameterName = "@L422"
                pL422.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL422)
                cmdWriteCommand.Parameters("@L422").Value = Double.Parse(dL422)

                'dL423
                pL423 = New SqlClient.SqlParameter
                pL423.ParameterName = "@L423"
                pL423.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL423)
                cmdWriteCommand.Parameters("@L423").Value = Double.Parse(dL423)

                'dL424
                pL424 = New SqlClient.SqlParameter
                pL424.ParameterName = "@L424"
                pL424.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL424)
                cmdWriteCommand.Parameters("@L424").Value = Double.Parse(dL424)

                'dL425
                pL425 = New SqlClient.SqlParameter
                pL425.ParameterName = "@L425"
                pL425.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL425)
                cmdWriteCommand.Parameters("@L425").Value = Double.Parse(dL425)

                'dL426
                pL426 = New SqlClient.SqlParameter
                pL426.ParameterName = "@L426"
                pL426.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL426)
                cmdWriteCommand.Parameters("@L426").Value = Double.Parse(dL426)

                'dL427
                pL427 = New SqlClient.SqlParameter
                pL427.ParameterName = "@L427"
                pL427.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL427)
                cmdWriteCommand.Parameters("@L427").Value = Double.Parse(dL427)

                'dL428
                pL428 = New SqlClient.SqlParameter
                pL428.ParameterName = "@L428"
                pL428.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL428)
                cmdWriteCommand.Parameters("@L428").Value = Double.Parse(dL428)

                'dL429
                pL429 = New SqlClient.SqlParameter
                pL429.ParameterName = "@L429"
                pL429.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL429)
                cmdWriteCommand.Parameters("@L429").Value = Double.Parse(dL429)

                'dL430
                pL430 = New SqlClient.SqlParameter
                pL430.ParameterName = "@L430"
                pL430.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL430)
                cmdWriteCommand.Parameters("@L430").Value = Double.Parse(dL430)

                'dL431
                pL431 = New SqlClient.SqlParameter
                pL431.ParameterName = "@L431"
                pL431.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL431)
                cmdWriteCommand.Parameters("@L431").Value = Double.Parse(dL431)

                'dL432
                pL432 = New SqlClient.SqlParameter
                pL432.ParameterName = "@L432"
                pL432.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL432)
                cmdWriteCommand.Parameters("@L432").Value = Double.Parse(dL432)

                'dL433
                pL433 = New SqlClient.SqlParameter
                pL433.ParameterName = "@L433"
                pL433.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL433)
                cmdWriteCommand.Parameters("@L433").Value = Double.Parse(dL433)

                'dL434
                pL434 = New SqlClient.SqlParameter
                pL434.ParameterName = "@L434"
                pL434.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL434)
                cmdWriteCommand.Parameters("@L434").Value = Double.Parse(dL434)

                'dL435
                pL435 = New SqlClient.SqlParameter
                pL435.ParameterName = "@L435"
                pL435.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL435)
                cmdWriteCommand.Parameters("@L435").Value = Double.Parse(dL435)

                'dL436
                pL436 = New SqlClient.SqlParameter
                pL436.ParameterName = "@L436"
                pL436.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL436)
                cmdWriteCommand.Parameters("@L436").Value = Double.Parse(dL436)

                'dL437
                pL437 = New SqlClient.SqlParameter
                pL437.ParameterName = "@L437"
                pL437.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL437)
                cmdWriteCommand.Parameters("@L437").Value = Double.Parse(dL437)

                'dL438
                pL438 = New SqlClient.SqlParameter
                pL438.ParameterName = "@L438"
                pL438.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL438)
                cmdWriteCommand.Parameters("@L438").Value = Double.Parse(dL438)

                'dL439
                pL439 = New SqlClient.SqlParameter
                pL439.ParameterName = "@L439"
                pL439.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL439)
                cmdWriteCommand.Parameters("@L439").Value = Double.Parse(dL439)

                'dL440
                pL440 = New SqlClient.SqlParameter
                pL440.ParameterName = "@L440"
                pL440.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL440)
                cmdWriteCommand.Parameters("@L440").Value = Double.Parse(dL440)

                'dL441
                pL441 = New SqlClient.SqlParameter
                pL441.ParameterName = "@L441"
                pL441.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL441)
                cmdWriteCommand.Parameters("@L441").Value = Double.Parse(dL441)

                'dL442
                pL442 = New SqlClient.SqlParameter
                pL442.ParameterName = "@L442"
                pL442.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL442)
                cmdWriteCommand.Parameters("@L442").Value = Double.Parse(dL442)

                'dL443
                pL443 = New SqlClient.SqlParameter
                pL443.ParameterName = "@L443"
                pL443.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL443)
                cmdWriteCommand.Parameters("@L443").Value = Double.Parse(dL443)

                'dL444
                pL444 = New SqlClient.SqlParameter
                pL444.ParameterName = "@L444"
                pL444.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL444)
                cmdWriteCommand.Parameters("@L444").Value = Double.Parse(dL444)

                'dL445
                pL445 = New SqlClient.SqlParameter
                pL445.ParameterName = "@L445"
                pL445.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL445)
                cmdWriteCommand.Parameters("@L445").Value = Double.Parse(dL445)

                'dL446
                pL446 = New SqlClient.SqlParameter
                pL446.ParameterName = "@L446"
                pL446.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL446)
                cmdWriteCommand.Parameters("@L446").Value = Double.Parse(dL446)

                'dL447
                pL447 = New SqlClient.SqlParameter
                pL447.ParameterName = "@L447"
                pL447.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL447)
                cmdWriteCommand.Parameters("@L447").Value = Double.Parse(dL447)

                'dL448
                pL448 = New SqlClient.SqlParameter
                pL448.ParameterName = "@L448"
                pL448.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL448)
                cmdWriteCommand.Parameters("@L448").Value = Double.Parse(dL448)

                'dL449
                pL449 = New SqlClient.SqlParameter
                pL449.ParameterName = "@L449"
                pL449.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL449)
                cmdWriteCommand.Parameters("@L449").Value = Double.Parse(dL449)

                'dL450
                pL450 = New SqlClient.SqlParameter
                pL450.ParameterName = "@L450"
                pL450.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL450)
                cmdWriteCommand.Parameters("@L450").Value = Double.Parse(dL450)

                'dL451
                pL451 = New SqlClient.SqlParameter
                pL451.ParameterName = "@L451"
                pL451.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL451)
                cmdWriteCommand.Parameters("@L451").Value = Double.Parse(dL451)

                'dL452
                pL452 = New SqlClient.SqlParameter
                pL452.ParameterName = "@L452"
                pL452.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL452)
                cmdWriteCommand.Parameters("@L452").Value = Double.Parse(dL452)

                'dL453
                pL453 = New SqlClient.SqlParameter
                pL453.ParameterName = "@L453"
                pL453.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL453)
                cmdWriteCommand.Parameters("@L453").Value = Double.Parse(dL453)

                'dL454
                pL454 = New SqlClient.SqlParameter
                pL454.ParameterName = "@L454"
                pL454.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL454)
                cmdWriteCommand.Parameters("@L454").Value = Double.Parse(dL454)

                'dL455
                pL455 = New SqlClient.SqlParameter
                pL455.ParameterName = "@L455"
                pL455.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL455)
                cmdWriteCommand.Parameters("@L455").Value = Double.Parse(dL455)

                'dL456
                pL456 = New SqlClient.SqlParameter
                pL456.ParameterName = "@L456"
                pL456.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL456)
                cmdWriteCommand.Parameters("@L456").Value = Double.Parse(dL456)

                'dL457
                pL457 = New SqlClient.SqlParameter
                pL457.ParameterName = "@L457"
                pL457.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL457)
                cmdWriteCommand.Parameters("@L457").Value = Double.Parse(dL457)

                'dL458
                pL458 = New SqlClient.SqlParameter
                pL458.ParameterName = "@L458"
                pL458.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL458)
                cmdWriteCommand.Parameters("@L458").Value = Double.Parse(dL458)

                'dL459
                pL459 = New SqlClient.SqlParameter
                pL459.ParameterName = "@L459"
                pL459.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL459)
                cmdWriteCommand.Parameters("@L459").Value = Double.Parse(dL459)

                'dL460
                pL460 = New SqlClient.SqlParameter
                pL460.ParameterName = "@L460"
                pL460.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL460)
                cmdWriteCommand.Parameters("@L460").Value = Double.Parse(dL460)

                'dL461
                pL461 = New SqlClient.SqlParameter
                pL461.ParameterName = "@L461"
                pL461.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL461)
                cmdWriteCommand.Parameters("@L461").Value = Double.Parse(dL461)

                'dL462
                pL462 = New SqlClient.SqlParameter
                pL462.ParameterName = "@L462"
                pL462.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL462)
                cmdWriteCommand.Parameters("@L462").Value = Double.Parse(dL462)

                'dL463
                pL463 = New SqlClient.SqlParameter
                pL463.ParameterName = "@L463"
                pL463.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL463)
                cmdWriteCommand.Parameters("@L463").Value = Double.Parse(dL463)

                'dL464
                pL464 = New SqlClient.SqlParameter
                pL464.ParameterName = "@L464"
                pL464.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL464)
                cmdWriteCommand.Parameters("@L464").Value = Double.Parse(dL464)

                'dL465
                pL465 = New SqlClient.SqlParameter
                pL465.ParameterName = "@L465"
                pL465.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL465)
                cmdWriteCommand.Parameters("@L465").Value = Double.Parse(dL465)

                'dL466
                pL466 = New SqlClient.SqlParameter
                pL466.ParameterName = "@L466"
                pL466.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL466)
                cmdWriteCommand.Parameters("@L466").Value = Double.Parse(dL466)

                'dL467
                pL467 = New SqlClient.SqlParameter
                pL467.ParameterName = "@L467"
                pL467.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL467)
                cmdWriteCommand.Parameters("@L467").Value = Double.Parse(dL467)

                'dL468
                pL468 = New SqlClient.SqlParameter
                pL468.ParameterName = "@L468"
                pL468.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL468)
                cmdWriteCommand.Parameters("@L468").Value = Double.Parse(dL468)

                'dL469
                pL469 = New SqlClient.SqlParameter
                pL469.ParameterName = "@L469"
                pL469.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL469)
                cmdWriteCommand.Parameters("@L469").Value = Double.Parse(dL469)

                'dL470
                pL470 = New SqlClient.SqlParameter
                pL470.ParameterName = "@L470"
                pL470.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL470)
                cmdWriteCommand.Parameters("@L470").Value = Double.Parse(dL470)

                'dL471
                pL471 = New SqlClient.SqlParameter
                pL471.ParameterName = "@L471"
                pL471.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL471)
                cmdWriteCommand.Parameters("@L471").Value = Double.Parse(dL471)

                'dL472
                pL472 = New SqlClient.SqlParameter
                pL472.ParameterName = "@L472"
                pL472.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL472)
                cmdWriteCommand.Parameters("@L472").Value = Double.Parse(dL472)

                'dL473
                pL473 = New SqlClient.SqlParameter
                pL473.ParameterName = "@L473"
                pL473.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL473)
                cmdWriteCommand.Parameters("@L473").Value = Double.Parse(dL473)

                'dL474
                pL474 = New SqlClient.SqlParameter
                pL474.ParameterName = "@L474"
                pL474.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL474)
                cmdWriteCommand.Parameters("@L474").Value = Double.Parse(dL474)

                'dL475
                pL475 = New SqlClient.SqlParameter
                pL475.ParameterName = "@L475"
                pL475.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL475)
                cmdWriteCommand.Parameters("@L475").Value = Double.Parse(dL475)

                'dL476
                pL476 = New SqlClient.SqlParameter
                pL476.ParameterName = "@L476"
                pL476.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL476)
                cmdWriteCommand.Parameters("@L476").Value = Double.Parse(dL476)

                'dL477
                pL477 = New SqlClient.SqlParameter
                pL477.ParameterName = "@L477"
                pL477.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL477)
                cmdWriteCommand.Parameters("@L477").Value = Double.Parse(dL477)

                'dL478
                pL478 = New SqlClient.SqlParameter
                pL478.ParameterName = "@L478"
                pL478.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL478)
                cmdWriteCommand.Parameters("@L478").Value = Double.Parse(dL478)

                'dL479
                pL479 = New SqlClient.SqlParameter
                pL479.ParameterName = "@L479"
                pL479.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL479)
                cmdWriteCommand.Parameters("@L479").Value = Double.Parse(dL479)

                'dL480
                pL480 = New SqlClient.SqlParameter
                pL480.ParameterName = "@L480"
                pL480.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL480)
                cmdWriteCommand.Parameters("@L480").Value = Double.Parse(dL480)

                'dL481
                pL481 = New SqlClient.SqlParameter
                pL481.ParameterName = "@L481"
                pL481.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL481)
                cmdWriteCommand.Parameters("@L481").Value = Double.Parse(dL481)

                'dL482
                pL482 = New SqlClient.SqlParameter
                pL482.ParameterName = "@L482"
                pL482.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL482)
                cmdWriteCommand.Parameters("@L482").Value = Double.Parse(dL482)

                'dL483
                pL483 = New SqlClient.SqlParameter
                pL483.ParameterName = "@L483"
                pL483.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL483)
                cmdWriteCommand.Parameters("@L483").Value = Double.Parse(dL483)

                'dL484
                pL484 = New SqlClient.SqlParameter
                pL484.ParameterName = "@L484"
                pL484.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL484)
                cmdWriteCommand.Parameters("@L484").Value = Double.Parse(dL484)

                'dL485
                pL485 = New SqlClient.SqlParameter
                pL485.ParameterName = "@L485"
                pL485.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL485)
                cmdWriteCommand.Parameters("@L485").Value = Double.Parse(dL485)

                'dL486
                pL486 = New SqlClient.SqlParameter
                pL486.ParameterName = "@L486"
                pL486.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL486)
                cmdWriteCommand.Parameters("@L486").Value = Double.Parse(dL486)

                'dL487
                pL487 = New SqlClient.SqlParameter
                pL487.ParameterName = "@L487"
                pL487.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL487)
                cmdWriteCommand.Parameters("@L487").Value = Double.Parse(dL487)

                'dL488
                pL488 = New SqlClient.SqlParameter
                pL488.ParameterName = "@L488"
                pL488.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL488)
                cmdWriteCommand.Parameters("@L488").Value = Double.Parse(dL488)

                'dL489
                pL489 = New SqlClient.SqlParameter
                pL489.ParameterName = "@L489"
                pL489.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL489)
                cmdWriteCommand.Parameters("@L489").Value = Double.Parse(dL489)

                'dL490
                pL490 = New SqlClient.SqlParameter
                pL490.ParameterName = "@L490"
                pL490.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL490)
                cmdWriteCommand.Parameters("@L490").Value = Double.Parse(dL490)

                'dL491
                pL491 = New SqlClient.SqlParameter
                pL491.ParameterName = "@L491"
                pL491.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL491)
                cmdWriteCommand.Parameters("@L491").Value = Double.Parse(dL491)

                'dL492
                pL492 = New SqlClient.SqlParameter
                pL492.ParameterName = "@L492"
                pL492.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL492)
                cmdWriteCommand.Parameters("@L492").Value = Double.Parse(dL492)

                'dL493
                pL493 = New SqlClient.SqlParameter
                pL493.ParameterName = "@L493"
                pL493.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL493)
                cmdWriteCommand.Parameters("@L493").Value = Double.Parse(dL493)

                'dL494
                pL494 = New SqlClient.SqlParameter
                pL494.ParameterName = "@L494"
                pL494.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL494)
                cmdWriteCommand.Parameters("@L494").Value = Double.Parse(dL494)

                'dL495
                pL495 = New SqlClient.SqlParameter
                pL495.ParameterName = "@L495"
                pL495.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL495)
                cmdWriteCommand.Parameters("@L495").Value = Double.Parse(dL495)

                'dL496
                pL496 = New SqlClient.SqlParameter
                pL496.ParameterName = "@L496"
                pL496.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL496)
                cmdWriteCommand.Parameters("@L496").Value = Double.Parse(dL496)

                'dL497
                pL497 = New SqlClient.SqlParameter
                pL497.ParameterName = "@L497"
                pL497.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL497)
                cmdWriteCommand.Parameters("@L497").Value = Double.Parse(dL497)

                'dL498
                pL498 = New SqlClient.SqlParameter
                pL498.ParameterName = "@L498"
                pL498.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL498)
                cmdWriteCommand.Parameters("@L498").Value = Double.Parse(dL498)

                'dL499
                pL499 = New SqlClient.SqlParameter
                pL499.ParameterName = "@L499"
                pL499.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL499)
                cmdWriteCommand.Parameters("@L499").Value = Double.Parse(dL499)

                'dL499A
                pL499A = New SqlClient.SqlParameter
                pL499A.ParameterName = "@L499A"
                pL499A.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL499A)
                cmdWriteCommand.Parameters("@L499A").Value = Double.Parse(dL499A)

                'dL499B
                pL499B = New SqlClient.SqlParameter
                pL499B.ParameterName = "@L499B"
                pL499B.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL499B)
                cmdWriteCommand.Parameters("@L499B").Value = Double.Parse(dL499B)

                'dL499C
                pL499C = New SqlClient.SqlParameter
                pL499C.ParameterName = "@L499C"
                pL499C.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL499C)
                cmdWriteCommand.Parameters("@L499C").Value = Double.Parse(dL499C)

                'dL499D
                pL499D = New SqlClient.SqlParameter
                pL499D.ParameterName = "@L499D"
                pL499D.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL499D)
                cmdWriteCommand.Parameters("@L499D").Value = Double.Parse(dL499D)

                'dL501
                pL501 = New SqlClient.SqlParameter
                pL501.ParameterName = "@L501"
                pL501.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL501)
                cmdWriteCommand.Parameters("@L501").Value = Double.Parse(dL501)

                'dL502
                pL502 = New SqlClient.SqlParameter
                pL502.ParameterName = "@L502"
                pL502.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL502)
                cmdWriteCommand.Parameters("@L502").Value = Double.Parse(dL502)

                'dL503
                pL503 = New SqlClient.SqlParameter
                pL503.ParameterName = "@L503"
                pL503.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL503)
                cmdWriteCommand.Parameters("@L503").Value = Double.Parse(dL503)

                'dL504
                pL504 = New SqlClient.SqlParameter
                pL504.ParameterName = "@L504"
                pL504.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL504)
                cmdWriteCommand.Parameters("@L504").Value = Double.Parse(dL504)

                'dL505
                pL505 = New SqlClient.SqlParameter
                pL505.ParameterName = "@L505"
                pL505.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL505)
                cmdWriteCommand.Parameters("@L505").Value = Double.Parse(dL505)

                'dL506
                pL506 = New SqlClient.SqlParameter
                pL506.ParameterName = "@L506"
                pL506.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL506)
                cmdWriteCommand.Parameters("@L506").Value = Double.Parse(dL506)

                'dL507
                pL507 = New SqlClient.SqlParameter
                pL507.ParameterName = "@L507"
                pL507.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL507)
                cmdWriteCommand.Parameters("@L507").Value = Double.Parse(dL507)

                'dL508
                pL508 = New SqlClient.SqlParameter
                pL508.ParameterName = "@L508"
                pL508.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL508)
                cmdWriteCommand.Parameters("@L508").Value = Double.Parse(dL508)

                'dL509
                pL509 = New SqlClient.SqlParameter
                pL509.ParameterName = "@L509"
                pL509.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL509)
                cmdWriteCommand.Parameters("@L509").Value = Double.Parse(dL509)

                'dL510
                pL510 = New SqlClient.SqlParameter
                pL510.ParameterName = "@L510"
                pL510.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL510)
                cmdWriteCommand.Parameters("@L510").Value = Double.Parse(dL510)

                'dL511
                pL511 = New SqlClient.SqlParameter
                pL511.ParameterName = "@L511"
                pL511.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL511)
                cmdWriteCommand.Parameters("@L511").Value = Double.Parse(dL511)

                'dL512
                pL512 = New SqlClient.SqlParameter
                pL512.ParameterName = "@L512"
                pL512.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL512)
                cmdWriteCommand.Parameters("@L512").Value = Double.Parse(dL512)

                'dL513
                pL513 = New SqlClient.SqlParameter
                pL513.ParameterName = "@L513"
                pL513.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL513)
                cmdWriteCommand.Parameters("@L513").Value = Double.Parse(dL513)

                'dL514
                pL514 = New SqlClient.SqlParameter
                pL514.ParameterName = "@L514"
                pL514.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL514)
                cmdWriteCommand.Parameters("@L514").Value = Double.Parse(dL514)

                'dL515
                pL515 = New SqlClient.SqlParameter
                pL515.ParameterName = "@L515"
                pL515.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL515)
                cmdWriteCommand.Parameters("@L515").Value = Double.Parse(dL515)

                'dL516
                pL516 = New SqlClient.SqlParameter
                pL516.ParameterName = "@L516"
                pL516.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL516)
                cmdWriteCommand.Parameters("@L516").Value = Double.Parse(dL516)

                'dL517
                pL517 = New SqlClient.SqlParameter
                pL517.ParameterName = "@L517"
                pL517.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL517)
                cmdWriteCommand.Parameters("@L517").Value = Double.Parse(dL517)

                'dL518
                pL518 = New SqlClient.SqlParameter
                pL518.ParameterName = "@L518"
                pL518.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL518)
                cmdWriteCommand.Parameters("@L518").Value = Double.Parse(dL518)

                'dL519
                pL519 = New SqlClient.SqlParameter
                pL519.ParameterName = "@L519"
                pL519.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL519)
                cmdWriteCommand.Parameters("@L519").Value = Double.Parse(dL519)

                'dL520
                pL520 = New SqlClient.SqlParameter
                pL520.ParameterName = "@L520"
                pL520.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL520)
                cmdWriteCommand.Parameters("@L520").Value = Double.Parse(dL520)

                'dL521
                pL521 = New SqlClient.SqlParameter
                pL521.ParameterName = "@L521"
                pL521.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL521)
                cmdWriteCommand.Parameters("@L521").Value = Double.Parse(dL521)

                'dL522
                pL522 = New SqlClient.SqlParameter
                pL522.ParameterName = "@L522"
                pL522.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL522)
                cmdWriteCommand.Parameters("@L522").Value = Double.Parse(dL522)

                'dL523
                pL523 = New SqlClient.SqlParameter
                pL523.ParameterName = "@L523"
                pL523.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL523)
                cmdWriteCommand.Parameters("@L523").Value = Double.Parse(dL523)

                'dL524
                pL524 = New SqlClient.SqlParameter
                pL524.ParameterName = "@L524"
                pL524.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL524)
                cmdWriteCommand.Parameters("@L524").Value = Double.Parse(dL524)

                'dL525
                pL525 = New SqlClient.SqlParameter
                pL525.ParameterName = "@L525"
                pL525.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL525)
                cmdWriteCommand.Parameters("@L525").Value = Double.Parse(dL525)

                'dL526
                pL526 = New SqlClient.SqlParameter
                pL526.ParameterName = "@L526"
                pL526.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL526)
                cmdWriteCommand.Parameters("@L526").Value = Double.Parse(dL526)

                'dL527
                pL527 = New SqlClient.SqlParameter
                pL527.ParameterName = "@L527"
                pL527.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL527)
                cmdWriteCommand.Parameters("@L527").Value = Double.Parse(dL527)

                'dL528
                pL528 = New SqlClient.SqlParameter
                pL528.ParameterName = "@L528"
                pL528.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL528)
                cmdWriteCommand.Parameters("@L528").Value = Double.Parse(dL528)

                'dL529
                pL529 = New SqlClient.SqlParameter
                pL529.ParameterName = "@L529"
                pL529.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL529)
                cmdWriteCommand.Parameters("@L529").Value = Double.Parse(dL529)

                'dL530
                pL530 = New SqlClient.SqlParameter
                pL530.ParameterName = "@L530"
                pL530.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL530)
                cmdWriteCommand.Parameters("@L530").Value = Double.Parse(dL530)

                'dL531
                pL531 = New SqlClient.SqlParameter
                pL531.ParameterName = "@L531"
                pL531.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL531)
                cmdWriteCommand.Parameters("@L531").Value = Double.Parse(dL531)

                'dL532
                pL532 = New SqlClient.SqlParameter
                pL532.ParameterName = "@L532"
                pL532.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL532)
                cmdWriteCommand.Parameters("@L532").Value = Double.Parse(dL532)

                'dL533
                pL533 = New SqlClient.SqlParameter
                pL533.ParameterName = "@L533"
                pL533.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL533)
                cmdWriteCommand.Parameters("@L533").Value = Double.Parse(dL533)

                'dL534
                pL534 = New SqlClient.SqlParameter
                pL534.ParameterName = "@L534"
                pL534.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL534)
                cmdWriteCommand.Parameters("@L534").Value = Double.Parse(dL534)

                'dL535
                pL535 = New SqlClient.SqlParameter
                pL535.ParameterName = "@L535"
                pL535.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL535)
                cmdWriteCommand.Parameters("@L535").Value = Double.Parse(dL535)

                'dL536
                pL536 = New SqlClient.SqlParameter
                pL536.ParameterName = "@L536"
                pL536.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL536)
                cmdWriteCommand.Parameters("@L536").Value = Double.Parse(dL536)

                'dL537
                pL537 = New SqlClient.SqlParameter
                pL537.ParameterName = "@L537"
                pL537.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL537)
                cmdWriteCommand.Parameters("@L537").Value = Double.Parse(dL537)

                'dL540
                pL540 = New SqlClient.SqlParameter
                pL540.ParameterName = "@L540"
                pL540.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL540)
                cmdWriteCommand.Parameters("@L540").Value = Double.Parse(dL540)

                'dL541
                pL541 = New SqlClient.SqlParameter
                pL541.ParameterName = "@L541"
                pL541.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL541)
                cmdWriteCommand.Parameters("@L541").Value = Double.Parse(dL541)

                'dL542
                pL542 = New SqlClient.SqlParameter
                pL542.ParameterName = "@L542"
                pL542.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL542)
                cmdWriteCommand.Parameters("@L542").Value = Double.Parse(dL542)

                'dL543
                pL543 = New SqlClient.SqlParameter
                pL543.ParameterName = "@L543"
                pL543.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL543)
                cmdWriteCommand.Parameters("@L543").Value = Double.Parse(dL543)

                'dL544
                pL544 = New SqlClient.SqlParameter
                pL544.ParameterName = "@L544"
                pL544.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL544)
                cmdWriteCommand.Parameters("@L544").Value = Double.Parse(dL544)

                'dL545
                pL545 = New SqlClient.SqlParameter
                pL545.ParameterName = "@L545"
                pL545.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL545)
                cmdWriteCommand.Parameters("@L545").Value = Double.Parse(dL545)

                'dL546
                pL546 = New SqlClient.SqlParameter
                pL546.ParameterName = "@L546"
                pL546.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL546)
                cmdWriteCommand.Parameters("@L546").Value = Double.Parse(dL546)

                'dL547
                pL547 = New SqlClient.SqlParameter
                pL547.ParameterName = "@L547"
                pL547.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL547)
                cmdWriteCommand.Parameters("@L547").Value = Double.Parse(dL547)

                'dL548
                pL548 = New SqlClient.SqlParameter
                pL548.ParameterName = "@L548"
                pL548.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL548)
                cmdWriteCommand.Parameters("@L548").Value = Double.Parse(dL548)

                'dL549
                pL549 = New SqlClient.SqlParameter
                pL549.ParameterName = "@L549"
                pL549.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL549)
                cmdWriteCommand.Parameters("@L549").Value = Double.Parse(dL549)

                'dL550
                pL550 = New SqlClient.SqlParameter
                pL550.ParameterName = "@L550"
                pL550.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL550)
                cmdWriteCommand.Parameters("@L550").Value = Double.Parse(dL550)

                'dL551
                pL551 = New SqlClient.SqlParameter
                pL551.ParameterName = "@L551"
                pL551.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL551)
                cmdWriteCommand.Parameters("@L551").Value = Double.Parse(dL551)

                'dL552
                pL552 = New SqlClient.SqlParameter
                pL552.ParameterName = "@L552"
                pL552.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL552)
                cmdWriteCommand.Parameters("@L552").Value = Double.Parse(dL552)

                'dL553
                pL553 = New SqlClient.SqlParameter
                pL553.ParameterName = "@L553"
                pL553.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL553)
                cmdWriteCommand.Parameters("@L553").Value = Double.Parse(dL553)

                'dL554
                pL554 = New SqlClient.SqlParameter
                pL554.ParameterName = "@L554"
                pL554.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL554)
                cmdWriteCommand.Parameters("@L554").Value = Double.Parse(dL554)

                'dL555
                pL555 = New SqlClient.SqlParameter
                pL555.ParameterName = "@L555"
                pL555.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL555)
                cmdWriteCommand.Parameters("@L555").Value = Double.Parse(dL555)

                'dL556
                pL556 = New SqlClient.SqlParameter
                pL556.ParameterName = "@L556"
                pL556.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL556)
                cmdWriteCommand.Parameters("@L556").Value = Double.Parse(dL556)

                'dL557
                pL557 = New SqlClient.SqlParameter
                pL557.ParameterName = "@L557"
                pL557.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL557)
                cmdWriteCommand.Parameters("@L557").Value = Double.Parse(dL557)

                'dL558
                pL558 = New SqlClient.SqlParameter
                pL558.ParameterName = "@L558"
                pL558.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL558)
                cmdWriteCommand.Parameters("@L558").Value = Double.Parse(dL558)

                'dL559
                pL559 = New SqlClient.SqlParameter
                pL559.ParameterName = "@L559"
                pL559.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL559)
                cmdWriteCommand.Parameters("@L559").Value = Double.Parse(dL559)

                'dL560
                pL560 = New SqlClient.SqlParameter
                pL560.ParameterName = "@L560"
                pL560.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL560)
                cmdWriteCommand.Parameters("@L560").Value = Double.Parse(dL560)

                'dL561
                pL561 = New SqlClient.SqlParameter
                pL561.ParameterName = "@L561"
                pL561.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL561)
                cmdWriteCommand.Parameters("@L561").Value = Double.Parse(dL561)

                'dL562
                pL562 = New SqlClient.SqlParameter
                pL562.ParameterName = "@L562"
                pL562.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL562)
                cmdWriteCommand.Parameters("@L562").Value = Double.Parse(dL562)

                'dL563
                pL563 = New SqlClient.SqlParameter
                pL563.ParameterName = "@L563"
                pL563.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL563)
                cmdWriteCommand.Parameters("@L563").Value = Double.Parse(dL563)

                'dL564
                pL564 = New SqlClient.SqlParameter
                pL564.ParameterName = "@L564"
                pL564.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL564)
                cmdWriteCommand.Parameters("@L564").Value = Double.Parse(dL564)

                'dL565
                pL565 = New SqlClient.SqlParameter
                pL565.ParameterName = "@L565"
                pL565.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL565)
                cmdWriteCommand.Parameters("@L565").Value = Double.Parse(dL565)

                'dL566
                pL566 = New SqlClient.SqlParameter
                pL566.ParameterName = "@L566"
                pL566.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL566)
                cmdWriteCommand.Parameters("@L566").Value = Double.Parse(dL566)

                'dL570
                pL570 = New SqlClient.SqlParameter
                pL570.ParameterName = "@L570"
                pL570.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL570)
                cmdWriteCommand.Parameters("@L570").Value = Double.Parse(dL570)

                'dL571
                pL571 = New SqlClient.SqlParameter
                pL571.ParameterName = "@L571"
                pL571.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL571)
                cmdWriteCommand.Parameters("@L571").Value = Double.Parse(dL571)

                'dL572
                pL572 = New SqlClient.SqlParameter
                pL572.ParameterName = "@L572"
                pL572.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL572)
                cmdWriteCommand.Parameters("@L572").Value = Double.Parse(dL572)

                'dL573
                pL573 = New SqlClient.SqlParameter
                pL573.ParameterName = "@L573"
                pL573.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL573)
                cmdWriteCommand.Parameters("@L573").Value = Double.Parse(dL573)

                'dL574
                pL574 = New SqlClient.SqlParameter
                pL574.ParameterName = "@L574"
                pL574.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL574)
                cmdWriteCommand.Parameters("@L574").Value = Double.Parse(dL574)

                'dL575
                pL575 = New SqlClient.SqlParameter
                pL575.ParameterName = "@L575"
                pL575.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL575)
                cmdWriteCommand.Parameters("@L575").Value = Double.Parse(dL575)

                'dL576
                pL576 = New SqlClient.SqlParameter
                pL576.ParameterName = "@L576"
                pL576.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL576)
                cmdWriteCommand.Parameters("@L576").Value = Double.Parse(dL576)

                'dL577
                pL577 = New SqlClient.SqlParameter
                pL577.ParameterName = "@L577"
                pL577.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL577)
                cmdWriteCommand.Parameters("@L577").Value = Double.Parse(dL577)

                'dL578
                pL578 = New SqlClient.SqlParameter
                pL578.ParameterName = "@L578"
                pL578.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL578)
                cmdWriteCommand.Parameters("@L578").Value = Double.Parse(dL578)

                'dL579
                pL579 = New SqlClient.SqlParameter
                pL579.ParameterName = "@L579"
                pL579.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL579)
                cmdWriteCommand.Parameters("@L579").Value = Double.Parse(dL579)

                'dL580
                pL580 = New SqlClient.SqlParameter
                pL580.ParameterName = "@L580"
                pL580.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL580)
                cmdWriteCommand.Parameters("@L580").Value = Double.Parse(dL580)

                'dL581
                pL581 = New SqlClient.SqlParameter
                pL581.ParameterName = "@L581"
                pL581.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL581)
                cmdWriteCommand.Parameters("@L581").Value = Double.Parse(dL581)

                'dL582
                pL582 = New SqlClient.SqlParameter
                pL582.ParameterName = "@L582"
                pL582.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL582)
                cmdWriteCommand.Parameters("@L582").Value = Double.Parse(dL582)

                'dL583
                pL583 = New SqlClient.SqlParameter
                pL583.ParameterName = "@L583"
                pL583.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL583)
                cmdWriteCommand.Parameters("@L583").Value = Double.Parse(dL583)

                'dL584
                pL584 = New SqlClient.SqlParameter
                pL584.ParameterName = "@L584"
                pL584.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL584)
                cmdWriteCommand.Parameters("@L584").Value = Double.Parse(dL584)

                'dL585
                pL585 = New SqlClient.SqlParameter
                pL585.ParameterName = "@L585"
                pL585.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL585)
                cmdWriteCommand.Parameters("@L585").Value = Double.Parse(dL585)

                'dL586
                pL586 = New SqlClient.SqlParameter
                pL586.ParameterName = "@L586"
                pL586.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL586)
                cmdWriteCommand.Parameters("@L586").Value = Double.Parse(dL586)

                'dL587
                pL587 = New SqlClient.SqlParameter
                pL587.ParameterName = "@L587"
                pL587.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL587)
                cmdWriteCommand.Parameters("@L587").Value = Double.Parse(dL587)

                'dL601
                pL601 = New SqlClient.SqlParameter
                pL601.ParameterName = "@L601"
                pL601.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL601)
                cmdWriteCommand.Parameters("@L601").Value = Double.Parse(dL601)

                'dL602
                pL602 = New SqlClient.SqlParameter
                pL602.ParameterName = "@L602"
                pL602.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL602)
                cmdWriteCommand.Parameters("@L602").Value = Double.Parse(dL602)

                'dL603
                pL603 = New SqlClient.SqlParameter
                pL603.ParameterName = "@L603"
                pL603.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL603)
                cmdWriteCommand.Parameters("@L603").Value = Double.Parse(dL603)

                'dL604
                pL604 = New SqlClient.SqlParameter
                pL604.ParameterName = "@L604"
                pL604.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL604)
                cmdWriteCommand.Parameters("@L604").Value = Double.Parse(dL604)

                'dL605
                pL605 = New SqlClient.SqlParameter
                pL605.ParameterName = "@L605"
                pL605.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL605)
                cmdWriteCommand.Parameters("@L605").Value = Double.Parse(dL605)

                'dL606
                pL606 = New SqlClient.SqlParameter
                pL606.ParameterName = "@L606"
                pL606.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL606)
                cmdWriteCommand.Parameters("@L606").Value = Double.Parse(dL606)

                'dL607
                pL607 = New SqlClient.SqlParameter
                pL607.ParameterName = "@L607"
                pL607.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL607)
                cmdWriteCommand.Parameters("@L607").Value = Double.Parse(dL607)

                'dL608
                pL608 = New SqlClient.SqlParameter
                pL608.ParameterName = "@L608"
                pL608.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL608)
                cmdWriteCommand.Parameters("@L608").Value = Double.Parse(dL608)

                'dL609
                pL609 = New SqlClient.SqlParameter
                pL609.ParameterName = "@L609"
                pL609.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL609)
                cmdWriteCommand.Parameters("@L609").Value = Double.Parse(dL609)

                'dL610
                pL610 = New SqlClient.SqlParameter
                pL610.ParameterName = "@L610"
                pL610.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL610)
                cmdWriteCommand.Parameters("@L610").Value = Double.Parse(dL610)

                'dL611
                pL611 = New SqlClient.SqlParameter
                pL611.ParameterName = "@L611"
                pL611.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL611)
                cmdWriteCommand.Parameters("@L611").Value = Double.Parse(dL611)

                'dL612
                pL612 = New SqlClient.SqlParameter
                pL612.ParameterName = "@L612"
                pL612.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL612)
                cmdWriteCommand.Parameters("@L612").Value = Double.Parse(dL612)

                'dL613
                pL613 = New SqlClient.SqlParameter
                pL613.ParameterName = "@L613"
                pL613.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL613)
                cmdWriteCommand.Parameters("@L613").Value = Double.Parse(dL613)

                'dL614
                pL614 = New SqlClient.SqlParameter
                pL614.ParameterName = "@L614"
                pL614.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL614)
                cmdWriteCommand.Parameters("@L614").Value = Double.Parse(dL614)

                'dL615
                pL615 = New SqlClient.SqlParameter
                pL615.ParameterName = "@L615"
                pL615.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL615)
                cmdWriteCommand.Parameters("@L615").Value = Double.Parse(dL615)

                'dL616
                pL616 = New SqlClient.SqlParameter
                pL616.ParameterName = "@L616"
                pL616.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL616)
                cmdWriteCommand.Parameters("@L616").Value = Double.Parse(dL616)

                'dL617
                pL617 = New SqlClient.SqlParameter
                pL617.ParameterName = "@L617"
                pL617.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL617)
                cmdWriteCommand.Parameters("@L617").Value = Double.Parse(dL617)

                'dL618
                pL618 = New SqlClient.SqlParameter
                pL618.ParameterName = "@L618"
                pL618.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL618)
                cmdWriteCommand.Parameters("@L618").Value = Double.Parse(dL618)

                'dL619
                pL619 = New SqlClient.SqlParameter
                pL619.ParameterName = "@L619"
                pL619.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL619)
                cmdWriteCommand.Parameters("@L619").Value = Double.Parse(dL619)

                'dL620
                pL620 = New SqlClient.SqlParameter
                pL620.ParameterName = "@L620"
                pL620.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL620)
                cmdWriteCommand.Parameters("@L620").Value = Double.Parse(dL620)

                'dL621
                pL621 = New SqlClient.SqlParameter
                pL621.ParameterName = "@L621"
                pL621.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL621)
                cmdWriteCommand.Parameters("@L621").Value = Double.Parse(dL621)

                'dL622
                pL622 = New SqlClient.SqlParameter
                pL622.ParameterName = "@L622"
                pL622.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL622)
                cmdWriteCommand.Parameters("@L622").Value = Double.Parse(dL622)

                'dL623
                pL623 = New SqlClient.SqlParameter
                pL623.ParameterName = "@L623"
                pL623.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL623)
                cmdWriteCommand.Parameters("@L623").Value = Double.Parse(dL623)

                'dL624
                pL624 = New SqlClient.SqlParameter
                pL624.ParameterName = "@L624"
                pL624.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL624)
                cmdWriteCommand.Parameters("@L624").Value = Double.Parse(dL624)

                'dL625
                pL625 = New SqlClient.SqlParameter
                pL625.ParameterName = "@L625"
                pL625.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL625)
                cmdWriteCommand.Parameters("@L625").Value = Double.Parse(dL625)

                'dL626
                pL626 = New SqlClient.SqlParameter
                pL626.ParameterName = "@L626"
                pL626.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL626)
                cmdWriteCommand.Parameters("@L626").Value = Double.Parse(dL626)

                'dL627
                pL627 = New SqlClient.SqlParameter
                pL627.ParameterName = "@L627"
                pL627.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL627)
                cmdWriteCommand.Parameters("@L627").Value = Double.Parse(dL627)

                'dL628
                pL628 = New SqlClient.SqlParameter
                pL628.ParameterName = "@L628"
                pL628.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL628)
                cmdWriteCommand.Parameters("@L628").Value = Double.Parse(dL628)

                'dL629
                pL629 = New SqlClient.SqlParameter
                pL629.ParameterName = "@L629"
                pL629.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL629)
                cmdWriteCommand.Parameters("@L629").Value = Double.Parse(dL629)

                'dL630
                pL630 = New SqlClient.SqlParameter
                pL630.ParameterName = "@L630"
                pL630.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL630)
                cmdWriteCommand.Parameters("@L630").Value = Double.Parse(dL630)

                'dL631
                pL631 = New SqlClient.SqlParameter
                pL631.ParameterName = "@L631"
                pL631.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL631)
                cmdWriteCommand.Parameters("@L631").Value = Double.Parse(dL631)

                'dL632
                pL632 = New SqlClient.SqlParameter
                pL632.ParameterName = "@L632"
                pL632.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL632)
                cmdWriteCommand.Parameters("@L632").Value = Double.Parse(dL632)

                'dL633
                pL633 = New SqlClient.SqlParameter
                pL633.ParameterName = "@L633"
                pL633.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL633)
                cmdWriteCommand.Parameters("@L633").Value = Double.Parse(dL633)

                'dL634
                pL634 = New SqlClient.SqlParameter
                pL634.ParameterName = "@L634"
                pL634.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL634)
                cmdWriteCommand.Parameters("@L634").Value = Double.Parse(dL634)

                'dL635
                pL635 = New SqlClient.SqlParameter
                pL635.ParameterName = "@L635"
                pL635.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL635)
                cmdWriteCommand.Parameters("@L635").Value = Double.Parse(dL635)

                'dL636
                pL636 = New SqlClient.SqlParameter
                pL636.ParameterName = "@L636"
                pL636.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL636)
                cmdWriteCommand.Parameters("@L636").Value = Double.Parse(dL636)

                'dL637
                pL637 = New SqlClient.SqlParameter
                pL637.ParameterName = "@L637"
                pL637.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL637)
                cmdWriteCommand.Parameters("@L637").Value = Double.Parse(dL637)

                'dL638
                pL638 = New SqlClient.SqlParameter
                pL638.ParameterName = "@L638"
                pL638.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL638)
                cmdWriteCommand.Parameters("@L638").Value = Double.Parse(dL638)

                'dL639
                pL639 = New SqlClient.SqlParameter
                pL639.ParameterName = "@L639"
                pL639.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL639)
                cmdWriteCommand.Parameters("@L639").Value = Double.Parse(dL639)

                'dL640
                pL640 = New SqlClient.SqlParameter
                pL640.ParameterName = "@L640"
                pL640.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL640)
                cmdWriteCommand.Parameters("@L640").Value = Double.Parse(dL640)

                'dL641
                pL641 = New SqlClient.SqlParameter
                pL641.ParameterName = "@L641"
                pL641.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL641)
                cmdWriteCommand.Parameters("@L641").Value = Double.Parse(dL641)

                'dL642
                pL642 = New SqlClient.SqlParameter
                pL642.ParameterName = "@L642"
                pL642.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL642)
                cmdWriteCommand.Parameters("@L642").Value = Double.Parse(dL642)

                'dL643
                pL643 = New SqlClient.SqlParameter
                pL643.ParameterName = "@L643"
                pL643.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL643)
                cmdWriteCommand.Parameters("@L643").Value = Double.Parse(dL643)

                'dL644
                pL644 = New SqlClient.SqlParameter
                pL644.ParameterName = "@L644"
                pL644.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL644)
                cmdWriteCommand.Parameters("@L644").Value = Double.Parse(dL644)

                'dL645
                pL645 = New SqlClient.SqlParameter
                pL645.ParameterName = "@L645"
                pL645.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL645)
                cmdWriteCommand.Parameters("@L645").Value = Double.Parse(dL645)

                'dL646
                pL646 = New SqlClient.SqlParameter
                pL646.ParameterName = "@L646"
                pL646.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL646)
                cmdWriteCommand.Parameters("@L646").Value = Double.Parse(dL646)

                'dL647
                pL647 = New SqlClient.SqlParameter
                pL647.ParameterName = "@L647"
                pL647.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL647)
                cmdWriteCommand.Parameters("@L647").Value = Double.Parse(dL647)

                'dL648
                pL648 = New SqlClient.SqlParameter
                pL648.ParameterName = "@L648"
                pL648.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL648)
                cmdWriteCommand.Parameters("@L648").Value = Double.Parse(dL648)

                'dL649
                pL649 = New SqlClient.SqlParameter
                pL649.ParameterName = "@L649"
                pL649.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL649)
                cmdWriteCommand.Parameters("@L649").Value = Double.Parse(dL649)

                'dL650
                pL650 = New SqlClient.SqlParameter
                pL650.ParameterName = "@L650"
                pL650.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL650)
                cmdWriteCommand.Parameters("@L650").Value = Double.Parse(dL650)

                'dL651
                pL651 = New SqlClient.SqlParameter
                pL651.ParameterName = "@L651"
                pL651.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL651)
                cmdWriteCommand.Parameters("@L651").Value = Double.Parse(dL651)

                'dL652
                pL652 = New SqlClient.SqlParameter
                pL652.ParameterName = "@L652"
                pL652.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL652)
                cmdWriteCommand.Parameters("@L652").Value = Double.Parse(dL652)

                'dL653
                pL653 = New SqlClient.SqlParameter
                pL653.ParameterName = "@L653"
                pL653.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL653)
                cmdWriteCommand.Parameters("@L653").Value = Double.Parse(dL653)

                'dL654
                pL654 = New SqlClient.SqlParameter
                pL654.ParameterName = "@L654"
                pL654.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL654)
                cmdWriteCommand.Parameters("@L654").Value = Double.Parse(dL654)

                'dL655
                pL655 = New SqlClient.SqlParameter
                pL655.ParameterName = "@L655"
                pL655.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL655)
                cmdWriteCommand.Parameters("@L655").Value = Double.Parse(dL655)

                'dL656
                pL656 = New SqlClient.SqlParameter
                pL656.ParameterName = "@L656"
                pL656.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL656)
                cmdWriteCommand.Parameters("@L656").Value = Double.Parse(dL656)

                'dL657
                pL657 = New SqlClient.SqlParameter
                pL657.ParameterName = "@L657"
                pL657.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL657)
                cmdWriteCommand.Parameters("@L657").Value = Double.Parse(dL657)

                'dL658
                pL658 = New SqlClient.SqlParameter
                pL658.ParameterName = "@L658"
                pL658.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL658)
                cmdWriteCommand.Parameters("@L658").Value = Double.Parse(dL658)

                'dL659
                pL659 = New SqlClient.SqlParameter
                pL659.ParameterName = "@L659"
                pL659.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL659)
                cmdWriteCommand.Parameters("@L659").Value = Double.Parse(dL659)

                'dL660
                pL660 = New SqlClient.SqlParameter
                pL660.ParameterName = "@L660"
                pL660.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL660)
                cmdWriteCommand.Parameters("@L660").Value = Double.Parse(dL660)

                'dL661
                pL661 = New SqlClient.SqlParameter
                pL661.ParameterName = "@L661"
                pL661.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL661)
                cmdWriteCommand.Parameters("@L661").Value = Double.Parse(dL661)

                'dL662
                pL662 = New SqlClient.SqlParameter
                pL662.ParameterName = "@L662"
                pL662.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL662)
                cmdWriteCommand.Parameters("@L662").Value = Double.Parse(dL662)

                'dL663
                pL663 = New SqlClient.SqlParameter
                pL663.ParameterName = "@L663"
                pL663.DbType = DbType.Int32

                cmdWriteCommand.Parameters.Add(pL663)
                cmdWriteCommand.Parameters("@L663").Value = Double.Parse(dL663)

                'dL664
                pL664 = New SqlClient.SqlParameter
                pL664.ParameterName = "@L664"
                pL664.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL664)
                cmdWriteCommand.Parameters("@L664").Value = Double.Parse(dL664)

                'dL665
                pL665 = New SqlClient.SqlParameter
                pL665.ParameterName = "@L665"
                pL665.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL665)
                cmdWriteCommand.Parameters("@L665").Value = Double.Parse(dL665)

                'dL666
                pL666 = New SqlClient.SqlParameter
                pL666.ParameterName = "@L666"
                pL666.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL666)
                cmdWriteCommand.Parameters("@L666").Value = Double.Parse(dL666)

                'dL667
                pL667 = New SqlClient.SqlParameter
                pL667.ParameterName = "@L667"
                pL667.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL667)
                cmdWriteCommand.Parameters("@L667").Value = Double.Parse(dL667)

                'dL668
                pL668 = New SqlClient.SqlParameter
                pL668.ParameterName = "@L668"
                pL668.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL668)
                cmdWriteCommand.Parameters("@L668").Value = Double.Parse(dL668)

                'dL669
                pL669 = New SqlClient.SqlParameter
                pL669.ParameterName = "@L669"
                pL669.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL669)
                cmdWriteCommand.Parameters("@L669").Value = Double.Parse(dL669)

                'dL670
                pL670 = New SqlClient.SqlParameter
                pL670.ParameterName = "@L670"
                pL670.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL670)
                cmdWriteCommand.Parameters("@L670").Value = Double.Parse(dL670)

                'dL671
                pL671 = New SqlClient.SqlParameter
                pL671.ParameterName = "@L671"
                pL671.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL671)
                cmdWriteCommand.Parameters("@L671").Value = Double.Parse(dL671)

                'dL672
                pL672 = New SqlClient.SqlParameter
                pL672.ParameterName = "@L672"
                pL672.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL672)
                cmdWriteCommand.Parameters("@L672").Value = Double.Parse(dL672)

                'dL673
                pL673 = New SqlClient.SqlParameter
                pL673.ParameterName = "@L673"
                pL673.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL673)
                cmdWriteCommand.Parameters("@L673").Value = Double.Parse(dL673)

                'dL674
                pL674 = New SqlClient.SqlParameter
                pL674.ParameterName = "@L674"
                pL674.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL674)
                cmdWriteCommand.Parameters("@L674").Value = Double.Parse(dL674)

                'dL675
                pL675 = New SqlClient.SqlParameter
                pL675.ParameterName = "@L675"
                pL675.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL675)
                cmdWriteCommand.Parameters("@L675").Value = Double.Parse(dL675)

                'dL676
                pL676 = New SqlClient.SqlParameter
                pL676.ParameterName = "@L676"
                pL676.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL676)
                cmdWriteCommand.Parameters("@L676").Value = Double.Parse(dL676)

                'dL677
                pL677 = New SqlClient.SqlParameter
                pL677.ParameterName = "@L677"
                pL677.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL677)
                cmdWriteCommand.Parameters("@L677").Value = Double.Parse(dL677)

                'dL678
                pL678 = New SqlClient.SqlParameter
                pL678.ParameterName = "@L678"
                pL678.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL678)
                cmdWriteCommand.Parameters("@L678").Value = Double.Parse(dL678)

                'dL679
                pL679 = New SqlClient.SqlParameter
                pL679.ParameterName = "@L679"
                pL679.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL679)
                cmdWriteCommand.Parameters("@L679").Value = Double.Parse(dL679)

                'dL680
                pL680 = New SqlClient.SqlParameter
                pL680.ParameterName = "@L680"
                pL680.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL680)
                cmdWriteCommand.Parameters("@L680").Value = Double.Parse(dL680)

                'dL681
                pL681 = New SqlClient.SqlParameter
                pL681.ParameterName = "@L681"
                pL681.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL681)
                cmdWriteCommand.Parameters("@L681").Value = Double.Parse(dL681)

                'dL682
                pL682 = New SqlClient.SqlParameter
                pL682.ParameterName = "@L682"
                pL682.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL682)
                cmdWriteCommand.Parameters("@L682").Value = Double.Parse(dL682)

                'dL683
                pL683 = New SqlClient.SqlParameter
                pL683.ParameterName = "@L683"
                pL683.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL683)
                cmdWriteCommand.Parameters("@L683").Value = Double.Parse(dL683)

                'dL684
                pL684 = New SqlClient.SqlParameter
                pL684.ParameterName = "@L684"
                pL684.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL684)
                cmdWriteCommand.Parameters("@L684").Value = Double.Parse(dL684)

                'dL685
                pL685 = New SqlClient.SqlParameter
                pL685.ParameterName = "@L685"
                pL685.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL685)
                cmdWriteCommand.Parameters("@L685").Value = Double.Parse(dL685)

                'dL686
                pL686 = New SqlClient.SqlParameter
                pL686.ParameterName = "@L686"
                pL686.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL686)
                cmdWriteCommand.Parameters("@L686").Value = Double.Parse(dL686)

                'dL687
                pL687 = New SqlClient.SqlParameter
                pL687.ParameterName = "@L687"
                pL687.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL687)
                cmdWriteCommand.Parameters("@L687").Value = Double.Parse(dL687)

                'dL688
                pL688 = New SqlClient.SqlParameter
                pL688.ParameterName = "@L688"
                pL688.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL688)
                cmdWriteCommand.Parameters("@L688").Value = Double.Parse(dL688)

                'dL689
                pL689 = New SqlClient.SqlParameter
                pL689.ParameterName = "@L689"
                pL689.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL689)
                cmdWriteCommand.Parameters("@L689").Value = Double.Parse(dL689)

                'dL690
                pL690 = New SqlClient.SqlParameter
                pL690.ParameterName = "@L690"
                pL690.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL690)
                cmdWriteCommand.Parameters("@L690").Value = Double.Parse(dL690)

                'dL691
                pL691 = New SqlClient.SqlParameter
                pL691.ParameterName = "@L691"
                pL691.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL691)
                cmdWriteCommand.Parameters("@L691").Value = Double.Parse(dL691)

                'dL692
                pL692 = New SqlClient.SqlParameter
                pL692.ParameterName = "@L692"
                pL692.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL692)
                cmdWriteCommand.Parameters("@L692").Value = Double.Parse(dL692)

                'dL693
                pL693 = New SqlClient.SqlParameter
                pL693.ParameterName = "@L693"
                pL693.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL693)
                cmdWriteCommand.Parameters("@L693").Value = Double.Parse(dL693)

                'dL694
                pL694 = New SqlClient.SqlParameter
                pL694.ParameterName = "@L694"
                pL694.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL694)
                cmdWriteCommand.Parameters("@L694").Value = Double.Parse(dL694)

                'dL695
                pL695 = New SqlClient.SqlParameter
                pL695.ParameterName = "@L695"
                pL695.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL695)
                cmdWriteCommand.Parameters("@L695").Value = Double.Parse(dL695)

                'dL696
                pL696 = New SqlClient.SqlParameter
                pL696.ParameterName = "@L696"
                pL696.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL696)
                cmdWriteCommand.Parameters("@L696").Value = Double.Parse(dL696)

                'dL697
                pL697 = New SqlClient.SqlParameter
                pL697.ParameterName = "@L697"
                pL697.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL697)
                cmdWriteCommand.Parameters("@L697").Value = Double.Parse(dL697)

                'dL698
                pL698 = New SqlClient.SqlParameter
                pL698.ParameterName = "@L698"
                pL698.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL698)
                cmdWriteCommand.Parameters("@L698").Value = Double.Parse(dL698)

                'dL699
                pL699 = New SqlClient.SqlParameter
                pL699.ParameterName = "@L699"
                pL699.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL699)
                cmdWriteCommand.Parameters("@L699").Value = Double.Parse(dL699)

                'iL700
                pL700 = New SqlClient.SqlParameter
                pL700.ParameterName = "@L700"
                pL700.DbType = DbType.Double

                cmdWriteCommand.Parameters.Add(pL700)
                cmdWriteCommand.Parameters("@L700").Value = Double.Parse(iL700)


                cmdWriteCommand.CommandTimeout = 60
                cmdWriteCommand.ExecuteNonQuery()

            Catch ex As System.Exception
                'if we get an error toss it to the web app
                MsgBox("Error encountered when executing writeOutput subroutine for LoopSegment" & pLoopSegment.ToString & ", Serial Number " & pSerialNum.ToString &
                       ", Segment Number" & pSegmentNumber.ToString, vbOKOnly, "ERROR!")

            End Try

        Catch ex As System.Exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "writeOutput")
        End Try
    End Sub

    ''' <summary>
    ''' Writes the current row back to SQL for the CRPRES File.  If we are in legacy mode, then we write to a seperate table
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub writeCRPRES(ByVal rrArray As Double(), ByVal bLeg As Boolean)

        Dim dsFillDataSet As New DataSet()

        Dim cmdCommand As SqlCommand
        Dim mSQLstr As StringBuilder
        Dim mLooper As Integer

        Try

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            If bLeg Then

                OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPRES_LEGACY"))
                Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPRES_LEGACY")

            Else

                OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPRES"))
                Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPRES")

            End If

            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            mSQLstr = New StringBuilder

            mSQLstr.Clear()
            mSQLstr.Append("INSERT INTO " & Global_Variables.gbl_Table_Name.ToString & " VALUES (")

            For mLooper = 0 To 17
                mSQLstr.Append(Double.Parse(rrArray(mLooper).ToString) & ", ")
            Next mLooper
            mSQLstr.Append(Double.Parse(rrArray(18).ToString) & ")")

            cmdCommand.CommandTimeout = 60
            cmdCommand.CommandText = mSQLstr.ToString
            cmdCommand.ExecuteNonQuery()

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        'clean up
        cmdCommand.Dispose()

    End Sub

    ''' <summary>
    ''' Refreshes all of the line number varaibles
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub RefreshLineNumbers()

        'stage or zero the line number vars
        iL101 = 0
        dL102a = 0.0
        iL102 = 0
        iL103 = 0
        iL104 = 0
        dL105 = 0.0
        dL105R = 0.0
        dL105P = 0.0
        iL250 = 0
        dL106 = 0.0
        dL107 = 0.0
        dL108 = 0.0
        dL109 = 0.0
        dL110 = 0.0
        dL111 = 0.0

        iL201 = 0
        ' dL202a = 0.0 we do not want to zero this one out because it is based on a previous value.
        dL202 = 0.0
        dL203 = 0.0
        dL204 = 0.0
        dL205 = 0.0
        dL206 = 0.0
        dL207 = 0.0
        dL208 = 0.0
        dL209 = 0.0
        dL210 = 0.0
        dL211 = 0.0
        dL212 = 0.0
        dL213 = 0.0
        dL214 = 0.0
        dL215 = 0.0
        dL216 = 0.0
        iL217 = 0
        iL218 = 0
        dL219 = 0.0
        dL220 = 0.0
        dL221 = 0.0
        dL222 = 0.0
        dL223 = 0.0
        dL224 = 0.0
        dL225 = 0.0
        dL226 = 0.0
        dL227 = 0.0
        dL228 = 0.0
        dL229 = 0.0
        dL230 = 0.0
        dL231 = 0.0
        dL232 = 0.0
        dL233 = 0.0
        dL234 = 0.0
        dL235 = 0.0
        dL236 = 0.0
        dL237 = 0.0
        dL238 = 0.0
        dL239 = 0.0
        dL240 = 0.0
        dL241 = 0.0
        dL242 = 0.0
        dL243 = 0.0
        dL244 = 0.0
        dL245 = 0.0
        dL246 = 0.0
        dL247 = 0.0
        dL248 = 0.0

        dL251 = 0.0
        dL252 = 0.0
        dL253 = 0.0
        dL254 = 0.0
        dL255 = 0.0
        dL256 = 0.0
        dL257 = 0.0
        dL258 = 0.0
        dL259 = 0.0
        dL260 = 0.0
        dL261 = 0.0
        dL262 = 0.0
        dL263 = 0.0
        dL264 = 0.0
        dL265 = 0.0
        dL266 = 0.0
        dL267 = 0.0
        dL268 = 0.0
        dL269 = 0.0
        dL270 = 0.0
        dL271 = 0.0
        dL272 = 0.0
        dL273 = 0.0
        dL274 = 0.0
        dL275 = 0.0
        dL276 = 0.0
        dL277 = 0.0
        dL278 = 0.0
        dL279 = 0.0
        dL280 = 0.0
        dL281 = 0.0
        dL282 = 0.0
        dL283 = 0.0
        dL284 = 0.0
        dL285 = 0.0
        dL286 = 0.0
        dL287 = 0.0
        dL288 = 0.0
        dL289 = 0.0
        dL290 = 0.0

        dL301 = 0.0
        dL302 = 0.0
        dL303 = 0.0
        dL304 = 0.0
        dL305 = 0.0
        dL306 = 0.0
        dL307 = 0.0
        dL308 = 0.0
        dL309 = 0.0
        dL310 = 0.0
        dL311 = 0.0
        dL312 = 0.0
        dL313 = 0.0
        dL314 = 0.0
        dL315 = 0.0
        dL316 = 0.0
        dL317 = 0.0
        dL318 = 0.0
        dL319 = 0.0
        dL320 = 0.0
        dL321 = 0.0
        dL322 = 0.0
        dL323 = 0.0
        dL324 = 0.0
        dL325 = 0.0
        dL326 = 0.0
        dL327 = 0.0
        dL328 = 0.0
        dL329 = 0.0
        dL330 = 0.0
        dL331 = 0.0
        dL332 = 0.0
        dL333 = 0.0
        dL334 = 0.0

        dL401 = 0.0
        dL402 = 0.0
        dL403 = 0.0
        dL404 = 0.0
        dL405 = 0.0
        dL406 = 0.0
        dL407 = 0.0
        dL408 = 0.0
        dL409 = 0.0
        dL410 = 0.0
        dL411 = 0.0
        dL412 = 0.0
        dL413 = 0.0
        dL414 = 0.0
        dL415 = 0.0
        dL416 = 0.0
        dL417 = 0.0
        dL418 = 0.0
        dL419 = 0.0
        dL420 = 0.0
        dL421 = 0.0
        dL422 = 0.0
        dL423 = 0.0
        dL424 = 0.0
        dL425 = 0.0
        dL426 = 0.0
        dL427 = 0.0
        dL428 = 0.0
        dL429 = 0.0
        dL430 = 0.0
        dL431 = 0.0
        dL432 = 0.0
        dL433 = 0.0
        dL434 = 0.0
        dL435 = 0.0
        dL436 = 0.0
        dL437 = 0.0
        dL438 = 0.0
        dL439 = 0.0
        dL440 = 0.0
        dL441 = 0.0
        dL442 = 0.0
        dL443 = 0.0
        dL444 = 0.0
        dL445 = 0.0
        dL446 = 0.0
        dL447 = 0.0
        dL448 = 0.0
        dL449 = 0.0
        dL450 = 0.0
        dL451 = 0.0
        dL452 = 0.0
        dL453 = 0.0
        dL454 = 0.0
        dL455 = 0.0
        dL456 = 0.0
        dL457 = 0.0
        dL458 = 0.0
        dL459 = 0.0
        dL460 = 0.0
        dL461 = 0.0
        dL462 = 0.0
        dL463 = 0.0
        dL464 = 0.0
        dL465 = 0.0
        dL466 = 0.0
        dL467 = 0.0
        dL468 = 0.0
        dL469 = 0.0
        dL470 = 0.0
        dL471 = 0.0
        dL472 = 0.0
        dL473 = 0.0
        dL474 = 0.0
        dL475 = 0.0
        dL476 = 0.0
        dL477 = 0.0
        dL478 = 0.0
        dL479 = 0.0
        dL480 = 0.0
        dL481 = 0.0
        dL482 = 0.0
        dL483 = 0.0
        dL484 = 0.0
        dL485 = 0.0
        dL486 = 0.0
        dL487 = 0.0
        dL488 = 0.0
        dL489 = 0.0
        dL490 = 0.0
        dL491 = 0.0
        dL492 = 0.0
        dL493 = 0.0
        dL494 = 0.0
        dL495 = 0.0
        dL496 = 0.0
        dL497 = 0.0
        dL498 = 0.0
        dL499 = 0.0
        dL499A = 0.0
        dL499B = 0.0
        dL499C = 0.0
        dL499D = 0.0

        dL501 = 0.0
        dL502 = 0.0
        dL503 = 0.0
        dL504 = 0.0
        dL505 = 0.0
        dL506 = 0.0
        dL507 = 0.0
        dL508 = 0.0
        dL509 = 0.0
        dL510 = 0.0
        dL511 = 0.0
        dL512 = 0.0
        dL513 = 0.0
        dL514 = 0.0
        dL515 = 0.0
        dL516 = 0.0
        dL517 = 0.0
        dL518 = 0.0
        dL519 = 0.0
        dL520 = 0.0
        dL521 = 0.0
        dL522 = 0.0
        dL523 = 0.0
        dL524 = 0.0
        dL525 = 0.0
        dL526 = 0.0
        dL527 = 0.0
        dL528 = 0.0
        dL529 = 0.0
        dL530 = 0.0
        dL531 = 0.0
        dL532 = 0.0
        dL533 = 0.0
        dL534 = 0.0
        dL535 = 0.0
        dL536 = 0.0
        dL537 = 0.0

        dL540 = 0.0
        dL541 = 0.0
        dL542 = 0.0
        dL543 = 0.0
        dL544 = 0.0
        dL545 = 0.0
        dL546 = 0.0
        dL547 = 0.0
        dL548 = 0.0
        dL549 = 0.0
        dL550 = 0.0
        dL551 = 0.0
        dL552 = 0.0
        dL553 = 0.0
        dL554 = 0.0
        dL555 = 0.0
        dL556 = 0.0
        dL557 = 0.0
        dL558 = 0.0
        dL559 = 0.0
        dL560 = 0.0
        dL561 = 0.0
        dL562 = 0.0
        dL563 = 0.0
        dL564 = 0.0
        dL565 = 0.0
        dL566 = 0.0

        dL570 = 0.0
        dL571 = 0.0
        dL572 = 0.0
        dL573 = 0.0
        dL574 = 0.0
        dL575 = 0.0
        dL576 = 0.0
        dL577 = 0.0
        dL578 = 0.0
        dL579 = 0.0
        dL580 = 0.0
        dL581 = 0.0
        dL582 = 0.0
        dL583 = 0.0
        dL584 = 0.0
        dL585 = 0.0
        dL586 = 0.0
        dL587 = 0.0

        dL601 = 0.0
        dL602 = 0.0
        dL603 = 0.0
        dL604 = 0.0
        dL605 = 0.0
        dL606 = 0.0
        dL607 = 0.0
        dL608 = 0.0
        dL609 = 0.0
        dL610 = 0.0
        dL611 = 0.0
        dL612 = 0.0
        dL613 = 0.0
        dL614 = 0.0
        dL615 = 0.0
        dL616 = 0.0
        dL617 = 0.0
        dL618 = 0.0
        dL619 = 0.0
        dL620 = 0.0
        dL621 = 0.0
        dL622 = 0.0
        dL623 = 0.0
        dL624 = 0.0
        dL625 = 0.0
        dL626 = 0.0
        dL627 = 0.0
        dL628 = 0.0
        dL629 = 0.0
        dL630 = 0.0
        dL631 = 0.0
        dL632 = 0.0
        dL633 = 0.0
        dL634 = 0.0
        dL635 = 0.0
        dL636 = 0.0
        dL637 = 0.0
        dL638 = 0.0
        dL639 = 0.0
        dL640 = 0.0
        dL641 = 0.0
        dL642 = 0.0
        dL643 = 0.0
        dL644 = 0.0
        dL645 = 0.0
        dL646 = 0.0
        dL647 = 0.0
        dL648 = 0.0
        dL649 = 0.0
        dL650 = 0.0
        dL651 = 0.0
        dL652 = 0.0
        dL653 = 0.0
        dL654 = 0.0
        dL655 = 0.0
        dL656 = 0.0
        dL657 = 0.0
        dL658 = 0.0
        dL659 = 0.0
        dL660 = 0.0
        dL661 = 0.0
        dL662 = 0.0
        dL663 = 0.0
        dL664 = 0.0
        dL665 = 0.0
        dL666 = 0.0
        dL667 = 0.0
        dL668 = 0.0
        dL669 = 0.0
        dL670 = 0.0
        dL671 = 0.0
        dL672 = 0.0
        dL673 = 0.0
        dL674 = 0.0
        dL675 = 0.0
        dL676 = 0.0
        dL677 = 0.0
        dL678 = 0.0
        dL679 = 0.0
        dL680 = 0.0
        dL681 = 0.0
        dL682 = 0.0
        dL683 = 0.0
        dL684 = 0.0
        dL685 = 0.0
        dL686 = 0.0
        dL687 = 0.0
        dL688 = 0.0
        dL689 = 0.0
        dL690 = 0.0
        dL691 = 0.0
        dL692 = 0.0
        dL693 = 0.0
        dL694 = 0.0
        dL695 = 0.0
        dL696 = 0.0
        dL697 = 0.0
        dL698 = 0.0
        dL699 = 0.0
        iL700 = 0.0

    End Sub

    ''' <summary>
    ''' Beacuse each row will be processed in a loop, we need to re-initialize our variables
    ''' This reusable function will serve as that refresh point.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub RefreshLoopVars()

        'zero out the input adjusted vars
        iSerialNum = 0
        iSegmentNumber = 0
        dTotalMiles = 0
        dMiles = 0
        iTotalSegments = 0
        iTotalSegments = 0
        sSegmentType = ""
        sShipmentSize = ""
        dInterlineCircuity = 0.0
        dLocalCircuity = 0.0
        sOwnership = ""
        iCarType = 0
        iExpantionFactor = 0
        iNumCars = 0
        iNumCarsExpanded = 0
        sTOFC_Serv_Code = ""
        dTOFC_Plan_Code = 0.0
        iRailroadNumber = 0
        lSTCC = 0
        dBill_Wght_Tons = 0.0
        iTons = 0
        iU_TC_Units = 0
        iU_cars = 0.0

        For i = 0 To aRRID.Length - 1
            aRRID(i) = 0
        Next

        'zero out all segment values in the CRPRES column arrays
        aCol2(0) = 0.0
        aCol2(1) = 0.0
        aCol2(2) = 0.0

        aCol3(0) = 0.0
        aCol3(1) = 0.0
        aCol3(2) = 0.0

        aCol4(0) = 0.0
        aCol4(1) = 0.0
        aCol4(2) = 0.0

        aCol5(0) = 0.0
        aCol5(1) = 0.0
        aCol5(2) = 0.0

        aCol6(0) = 0.0
        aCol6(1) = 0.0
        aCol6(2) = 0.0

        aCol7(0) = 0.0
        aCol7(1) = 0.0
        aCol7(2) = 0.0

        aCol8(0) = 0.0
        aCol8(1) = 0.0
        aCol8(2) = 0.0

        aCol9(0) = 0.0
        aCol9(1) = 0.0
        aCol9(2) = 0.0

        aCol10(0) = 0.0
        aCol10(1) = 0.0
        aCol10(2) = 0.0

        aCol11(0) = 0.0
        aCol11(1) = 0.0
        aCol11(2) = 0.0

        aCol12(0) = 0.0
        aCol12(1) = 0.0
        aCol12(2) = 0.0

        aCol13(0) = 0.0
        aCol13(1) = 0.0
        aCol13(2) = 0.0

        aCol14(0) = 0.0
        aCol14(1) = 0.0
        aCol14(2) = 0.0

        aCol15(0) = 0.0
        aCol15(1) = 0.0
        aCol15(2) = 0.0

        aCol16(0) = 0.0
        aCol16(1) = 0.0
        aCol16(2) = 0.0

        aCol17(0) = 0.0
        aCol17(1) = 0.0
        aCol17(2) = 0.0

        aCol18(0) = 0.0
        aCol18(1) = 0.0
        aCol18(2) = 0.0

        aCol19(0) = 0.0
        aCol19(1) = 0.0
        aCol19(2) = 0.0

    End Sub

    ''' <summary>
    ''' Gets a local table of the STCC Code Lookups
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getSTCCTable() As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try
            Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "STCC_L_AND_D")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "STCC_L_AND_D"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "SELECT * FROM " & Global_Variables.gbl_Table_Name
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "STCC"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    ''' <summary>
    ''' calls SQL DB and returns datatable of Railroad data
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function fillRailroads() As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Dim dtFinal As DataTable
        Dim bDupe As Boolean

        Try
            RaiseEvent StatusUpdated("Loading WAYRRR data to Memory...")

            OpenSQLConnection(Get_Database_Name_From_SQL("1", "WAYRRR"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "Select * from " & Get_Table_Name_From_SQL("1", "WAYRRR")
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "RailroadData"

            'deal with the duplicate entries
            dtFinal = DirectCast(dsDataSet.Tables(0).Clone(), DataTable)

            For Each drSource As DataRow In dsDataSet.Tables(0).Rows
                bDupe = False
                For Each drDestination As DataRow In dtFinal.Rows
                    If drSource("AARID") = drDestination("AARID") Then
                        bDupe = True
                        If Integer.Parse(drSource("EFFECTIVE_YEAR")) > Integer.Parse(drDestination("EFFECTIVE_YEAR")) Then
                            If Integer.Parse(drSource("EFFECTIVE_YEAR")) <= My.Settings.CurrentYear Then
                                drDestination("RR_ID") = drSource("RR_ID")
                                drDestination("REGION_ID") = drSource("REGION_ID")
                                drDestination("RR_ALPHA") = drSource("RR_ALPHA")
                                drDestination("RR_NAME") = drSource("RR_NAME")
                                drDestination("RR_REPORT_ALPHA") = drSource("RR_REPORT_ALPHA")
                                drDestination("EFFECTIVE_YEAR") = drSource("EFFECTIVE_YEAR")
                                drDestination.AcceptChanges()
                            End If
                        End If
                    End If
                Next
                If Not bDupe Then
                    If Integer.Parse(drSource("EFFECTIVE_YEAR")) <= My.Settings.CurrentYear Then
                        dtFinal.ImportRow(drSource)
                    End If
                End If
            Next

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dtFinal

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    ''' <summary>
    ''' calls SQL DB and returns datatable for any dat where entire table is desired
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function fillDataTable(ByVal mTableType As String, ByVal mReturnTableName As String) As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try
            RaiseEvent StatusUpdated("Loading " & mTableType & " data to Memory...")

            OpenSQLConnection(Get_Database_Name_From_SQL("1", mTableType.ToString))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "Select * from " & Get_Table_Name_From_SQL("1", mTableType.ToString)
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = mReturnTableName.ToString

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    ''' <summary>
    ''' calls SQL DB and returns datatable of CarType data
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function fillCarTypes() As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try
            RaiseEvent StatusUpdated("Loading Car Types to Memory...")

            Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL("1", "CAR_TYPE")

            OpenSQLConnection(Get_Database_Name_From_SQL("1", "CAR_TYPE"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandTimeout = 60
            cmdCommand.CommandText = "Select * from " & Global_Variables.gbl_Table_Name
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "CarTypeData"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    ''' <summary>
    ''' calls SQL DB and returns datatable of ecode data
    ''' not to be confused with eTable data, ecode data
    ''' is data specific to the ecode itself
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function fillEcodes() As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try
            RaiseEvent StatusUpdated("Loading ECodes data to Memory...")

            Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "ECODES")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "ECODES"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "Select * from " & Global_Variables.gbl_Table_Name
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "EcodeData"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    ''' <summary>
    ''' calls the SQL DB in a loop to get a dataset
    ''' of datatables. One each for each of the Railroads
    ''' the resulting datatables are named via the railroad ids.
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function fillEtable() As DataTable

        Dim dsFillDataSet As New DataSet()

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        'create params
        'Dim pYear As SqlClient.SqlParameter
        Try
            RaiseEvent StatusUpdated("Loading EValues data to Memory...")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "EVALUES"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "Select * from " & Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "EValues") &
                " WHERE [Year] = " & My.Settings.CurrentYear.ToString
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "ETable"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            'Throw (ex)
            MsgBox("Error retrieving EValues data - SQL failed", vbOKOnly, "ERROR!")
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    ''' <summary>
    ''' calls SQL DB and returns datatable of TOFC_Serv_Code data
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function fillTOFC_Serv_Code() As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try
            RaiseEvent StatusUpdated("Loading TOFC Serv Code data to Memory...")

            Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "TOFC_Serv_Code")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "TOFC_Serv_Code"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "Select DISTINCT * from " & Global_Variables.gbl_Table_Name
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "TOFC_Serv_Code"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    ''' <summary>
    ''' calls the usp_GetPhaseThreeMasterData SQL
    ''' procedure and returns datatable of all 
    ''' required masked and segment data needed to 
    ''' preform the costing.
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function fillMasterData() As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet
        Dim mSQLStr As New StringBuilder

        Try
            RaiseEvent StatusUpdated("Loading Masked Waybills data to Memory...")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "MASKED"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text

            mSQLStr.Append("SELECT mask.Serial_no, ")
            mSQLStr.Append("seg.Seg_no, ")
            mSQLStr.Append("seg.Total_Segs, ")
            mSQLStr.Append("mask.total_dist, ")
            mSQLStr.Append("mask.STB_Car_Typ, ")
            mSQLStr.Append("mask.TOFC_Serv_Code, ")
            mSQLStr.Append("mask.U_Cars, ")
            mSQLStr.Append("mask.car_own, ")
            mSQLStr.Append("mask.U_Car_Init, ")
            mSQLStr.Append("mask.u_tc_units, ")
            mSQLStr.Append("mask.Exp_Factor_Th, ")
            mSQLStr.Append("mask.Tons, ")
            mSQLStr.Append("mask.bill_Wght_tons, ")
            mSQLStr.Append("mask.JF, ")
            mSQLStr.Append("mask.STCC, ")
            mSQLStr.Append("mask.Transborder_Flg, ")
            mSQLStr.Append("mask.ORR_Dist, ")
            mSQLStr.Append("mask.JRR1_Dist, ")
            mSQLStr.Append("mask.JRR2_Dist, ")
            mSQLStr.Append("mask.JRR3_Dist, ")
            mSQLStr.Append("mask.JRR4_Dist, ")
            mSQLStr.Append("mask.JRR5_Dist, ")
            mSQLStr.Append("mask.JRR6_Dist, ")
            mSQLStr.Append("mask.TRR_Dist, ")
            mSQLStr.Append("mask.ORR, ")
            mSQLStr.Append("mask.JRR1, ")
            mSQLStr.Append("mask.JRR2, ")
            mSQLStr.Append("mask.JRR3,")
            mSQLStr.Append("mask.JRR4, ")
            mSQLStr.Append("mask.JRR5, ")
            mSQLStr.Append("mask.JRR6, ")
            mSQLStr.Append("mask.TRR, ")
            mSQLStr.Append("seg.seg_type, ")
            mSQLStr.Append("seg.RR_Dist, ")
            mSQLStr.Append("seg.RR_Num, ")
            mSQLStr.Append("seg.RR_Rev, ")
            mSQLStr.Append("seg.RR_Cntry ")
            mSQLStr.Append("FROM " & Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "MASKED") & " mask(NOLOCK) ")
            mSQLStr.Append("JOIN " & Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "SEGMENTS") & " seg (NOLOCK) ")
            mSQLStr.Append("ON mask.serial_no = seg.serial_no ")
            mSQLStr.Append("ORDER BY mask.Serial_No, seg.Seg_no")

            cmdCommand.CommandText = mSQLStr.ToString
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.SelectCommand.CommandTimeout = 60
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "MasterData"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    ''' <summary>
    ''' Clears all rows from the table about to be re-populated
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub truncateTable(ByVal bLeg As Boolean, ByVal loopSeg As Integer)

        Dim cmdCommand As SqlCommand

        Try

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            If bLeg Then
                Select Case loopSeg
                    Case 3
                        OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_LEGACY"))
                        Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_LEGACY")
                    Case 2
                        OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_LEGACY_2"))
                        Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_LEGACY_2")
                    Case 1
                        OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_LEGACY_1"))
                        Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_LEGACY_1")
                End Select
                cmdCommand.CommandText = "Truncate Table " & Global_Variables.gbl_Table_Name.ToString
            Else
                Select Case loopSeg
                    Case 3
                        OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG"))
                        Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG")
                    Case 2
                        OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_2"))
                        Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_2")
                    Case 1
                        OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_1"))
                        Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_1")
                End Select
                cmdCommand.CommandText = "Truncate Table " & Global_Variables.gbl_Table_Name.ToString
            End If
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection
            cmdCommand.CommandTimeout = 60
            cmdCommand.ExecuteNonQuery()

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        'clean up
        cmdCommand.Dispose()

    End Sub

    ''' <summary>
    ''' Clears all rows from the CRPRES table about to be re-populated
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub truncateCRPRESTable(ByVal bLeg As Boolean)

        Dim cmdCommand As SqlCommand

        Try

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text

            Select Case bLeg
                Case True
                    OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPRES_LEGACY"))
                    Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPRES_LEGACY")
                Case Else
                    OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPRES"))
                    Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPRES")
            End Select

            cmdCommand.CommandText = "Truncate Table " & Global_Variables.gbl_Table_Name
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection
            cmdCommand.CommandTimeout = 60
            cmdCommand.ExecuteNonQuery()

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        'clean up
        cmdCommand.Dispose()

    End Sub

    Private Sub truncateERRORSTable()

        Dim cmdCommand As SqlCommand

        Try

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "ERRORS"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "Truncate Table " & Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "ERRORS")

            cmdCommand.Connection = Global_Variables.gbl_SQLConnection
            cmdCommand.CommandTimeout = 60
            cmdCommand.ExecuteNonQuery()

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        'clean up
        cmdCommand.Dispose()

    End Sub

    ''' <summary>
    ''' Handles error traping and writes the message and stack trace back to SQL
    ''' </summary>
    ''' <param name="message"></param>
    ''' <param name="stack"></param>
    ''' <param name="location"></param>
    ''' <remarks></remarks>
    Private Sub HandleError(ByVal data As String, ByVal message As String, ByVal stack As String, ByVal location As String)

        Dim cmdCommand As SqlCommand

        'write the error to SQL
        Try

            Dim Timestamp = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fffffff tt")
            message = message.Replace("'", "").Replace("""", "")
            stack = stack.Replace("'", "").Replace("""", "")

            Global_Variables.Gbl_Errors_TableName = Get_Table_Name_From_SQL("1", "ERRORS")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "ERRORS"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandTimeout = 60

            cmdCommand.CommandText = "INSERT INTO " & Global_Variables.Gbl_Errors_TableName & _
                "  VALUES ('" & data.ToString & "','" & Timestamp.ToString & "','" & message.ToString & "','" & stack.ToString & "','" & location.ToString & "')"
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            cmdCommand.ExecuteNonQuery()

        Catch ex as system.exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

    End Sub

#End Region

End Class
