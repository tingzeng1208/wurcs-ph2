﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient

Public Class GenerateMakeWholeFactors

#Region "Declarations"

    'local conString variable
    Dim ConnString As String

    'local year variable
    Dim sYear As New String("")

    'local Legacy boolean
    Dim bLegacy As Boolean

    'eCode_ids and eCode strings for writing back to SQL
    Dim dtECode_Ids As New DataTable

    'Local CRPRES Table
    Dim dtCRPRES As New DataTable

    'iterationMarker
    Dim iRR_Marker As Integer = 0

    'local variables to hold totals
    Dim dIndustrySwitchingResidualAll As Double = 0.0
    Dim dIndustrySwitchingResidualRR As Double = 0.0
    Dim dStationClericalResidualAll As Double = 0.0
    Dim dStationClericalResidualRR As Double = 0.0
    Dim dInterchangeSwitchingResidualAll As Double = 0.0
    Dim dInterchangeSwitchingResidualRR As Double = 0.0
    Dim dIISwitchingResidualAll As Double = 0.0
    Dim dIISwitchingResidualRR As Double = 0.0
    Dim dMileageResidualAll As Double = 0.0
    Dim dMileageResidualRR As Double = 0.0

#End Region

#Region "Main functions"

    Public Sub New(ByVal Conn As String, ByVal year As String, ByVal Legacy As Boolean)

        Try

            'truncate the ERROR Table
            'truncateERRORSTable()

            'truncate the UT_MAKEWHOLE_FACTORS Table
            truncateUT_MAKEWHOLE_Table()

            'Write row to error table to announce end of processing
            HandleError("Status", "Started Generate MakeWhole Factor Process", "Started Generate MakeWhole Factor Process", "Started Generate MakeWhole Factor Process")

            'store the connstring for local use
            sYear = year

            'store legacy boolean
            bLegacy = Legacy

            'Get the ecode_ids for the factors we will update
            dtECode_Ids = getEcodeIDs()

            'Get a local copy of CRPRES
            dtCRPRES = getCRPRES(bLegacy)

            'Loop Through CRPRES
            For Each dr As DataRow In dtCRPRES.Rows

                'clear and zero out the vars
                Refresh()

                'decide what railroad we are calculating for
                iRR_Marker = Integer.Parse(dr("c1"))

                'calc the residuals
                If Double.IsNaN(Double.Parse(dr("c2")) / Double.Parse(dr("c12"))) Or Double.IsInfinity(Double.Parse(dr("c2")) / Double.Parse(dr("c12"))) Then
                    dIndustrySwitchingResidualAll = 0.0
                Else
                    dIndustrySwitchingResidualAll = Double.Parse(dr("c2")) / Double.Parse(dr("c12"))
                End If

                If Double.IsNaN(Double.Parse(dr("c7")) / Double.Parse(dr("c14"))) Or Double.IsInfinity(Double.Parse(dr("c7")) / Double.Parse(dr("c14"))) Then
                    dIndustrySwitchingResidualRR = 0.0
                Else
                    dIndustrySwitchingResidualRR = Double.Parse(dr("c7")) / Double.Parse(dr("c14"))
                End If

                If Double.IsNaN(Double.Parse(dr("c9")) / Double.Parse(dr("c13"))) Or Double.IsInfinity(Double.Parse(dr("c9")) / Double.Parse(dr("c13"))) Then
                    dStationClericalResidualAll = 0.0
                Else
                    dStationClericalResidualAll = Double.Parse(dr("c9")) / Double.Parse(dr("c13"))
                End If

                If Double.IsNaN(Double.Parse(dr("c8")) / Double.Parse(dr("c15"))) Or Double.IsInfinity(Double.Parse(dr("c8")) / Double.Parse(dr("c15"))) Then
                    dStationClericalResidualRR = 0.0
                Else
                    dStationClericalResidualRR = Double.Parse(dr("c8")) / Double.Parse(dr("c15"))
                End If

                If Double.IsNaN(Double.Parse(dr("c3")) / Double.Parse(dr("c16"))) Or Double.IsInfinity(Double.Parse(dr("c3")) / Double.Parse(dr("c16"))) Then
                    dInterchangeSwitchingResidualAll = 0.0
                Else
                    dInterchangeSwitchingResidualAll = Double.Parse(dr("c3")) / Double.Parse(dr("c16"))
                End If

                If Double.IsNaN(Double.Parse(dr("c5")) / Double.Parse(dr("c17"))) Or Double.IsInfinity(Double.Parse(dr("c5")) / Double.Parse(dr("c17"))) Then
                    dInterchangeSwitchingResidualRR = 0.0
                Else
                    dInterchangeSwitchingResidualRR = Double.Parse(dr("c5")) / Double.Parse(dr("c17"))
                End If

                If Double.IsNaN(Double.Parse(dr("c4")) / Double.Parse(dr("c18"))) Or Double.IsInfinity(Double.Parse(dr("c4")) / Double.Parse(dr("c18"))) Then
                    dIISwitchingResidualAll = 0.0
                Else
                    dIISwitchingResidualAll = Double.Parse(dr("c4")) / Double.Parse(dr("c18"))
                End If

                If Double.IsNaN(Double.Parse(dr("c6")) / Double.Parse(dr("c19"))) Or Double.IsInfinity(Double.Parse(dr("c6")) / Double.Parse(dr("c19"))) Then
                    dIISwitchingResidualRR = 0.0
                Else
                    dIISwitchingResidualRR = Double.Parse(dr("c6")) / Double.Parse(dr("c19"))
                End If

                If Double.IsNaN(Double.Parse(dr("c10")) / Double.Parse(dr("c18"))) Or Double.IsInfinity(Double.Parse(dr("c10")) / Double.Parse(dr("c18"))) Then
                    dMileageResidualAll = 0.0
                Else
                    dMileageResidualAll = Double.Parse(dr("c10")) / Double.Parse(dr("c18"))
                End If

                If Double.IsNaN(Double.Parse(dr("c11")) / Double.Parse(dr("c19"))) Or Double.IsInfinity(Double.Parse(dr("c11")) / Double.Parse(dr("c19"))) Then
                    dMileageResidualRR = 0.0
                Else
                    dMileageResidualRR = Double.Parse(dr("c11")) / Double.Parse(dr("c19"))
                End If


                'write out the etable values
                WriteOutEtableData(sYear, iRR_Marker, getEcodeID("E2L301C1"), dIndustrySwitchingResidualAll + dIndustrySwitchingResidualRR)
                WriteOutEtableData(sYear, iRR_Marker, getEcodeID("E2L301C2"), dIndustrySwitchingResidualAll)

                WriteOutEtableData(sYear, iRR_Marker, getEcodeID("E2L302C1"), dStationClericalResidualAll + dStationClericalResidualRR)
                WriteOutEtableData(sYear, iRR_Marker, getEcodeID("E2L302C2"), dStationClericalResidualAll)

                WriteOutEtableData(sYear, iRR_Marker, getEcodeID("E2L303C1"), dInterchangeSwitchingResidualAll + dInterchangeSwitchingResidualRR)
                WriteOutEtableData(sYear, iRR_Marker, getEcodeID("E2L303C2"), dInterchangeSwitchingResidualAll)

                WriteOutEtableData(sYear, iRR_Marker, getEcodeID("E2L304C1"), dIISwitchingResidualAll + dIISwitchingResidualRR)
                WriteOutEtableData(sYear, iRR_Marker, getEcodeID("E2L304C2"), dIISwitchingResidualAll)

                WriteOutEtableData(sYear, iRR_Marker, getEcodeID("E2L305C1"), dMileageResidualAll + dMileageResidualRR)
                WriteOutEtableData(sYear, iRR_Marker, getEcodeID("E2L305C2"), dMileageResidualAll)

            Next

            'Write row to error table to announce end of processing
            HandleError("Status", "Ended Generate MakeWhole Factor Process", "Ended Generate MakeWhole Factor Process", "Ended Generate MakeWhole Factor Process")

        Catch ex As system.exception
            HandleError("Error while calculating eTable values for Make Whole ", ex.Message, ex.StackTrace, "GenerateMakeWholeFactors-Constructer")
        End Try
    End Sub

#End Region

#Region "Helper functions"

    ''' <summary>
    ''' Writes the etable data back to the UT_MAKEWHOLE_FACTORS table
    ''' </summary>
    ''' <param name="currentYear"></param>
    ''' <param name="rrID"></param>
    ''' <param name="eCode_id"></param>
    ''' <param name="eCodeValue"></param>
    ''' <remarks></remarks>
    Private Sub WriteOutEtableData(ByVal currentYear As String, ByVal rrID As Integer, ByVal eCode_id As Integer, ByVal eCodeValue As Double)

        Dim mSQLStr As String
        Dim rst As ADODB.Recordset

        Global_Variables.Gbl_Makewhole_Factors_Tablename = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "MAKEWHOLE_FACTORS")

        OpenADOConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "MAKEWHOLE_FACTORS"))

        Try

            mSQLStr = "SELECT * FROM " & Global_Variables.Gbl_Makewhole_Factors_Tablename.ToString &
                " WHERE [Year] = " & currentYear.ToString & " AND RR_Id = " & rrID.ToString & " AND eCode_ID = " & eCode_id.ToString
            rst = SetRST()

            rst.Open(mSQLStr, Global_Variables.gbl_ADOConnection)

            If rst.RecordCount = 0 Then
                ' Insert a new record
                mSQLStr = "INSERT " & Global_Variables.Gbl_Makewhole_Factors_Tablename.ToString & " VALUES (" &
                    currentYear.ToString & ", " & rrID.ToString & ", " & eCode_id.ToString & ", " & eCodeValue.ToString & ")"
            Else
                ' Update the existing one
                mSQLStr = "UPDATE " & Global_Variables.Gbl_Makewhole_Factors_Tablename.ToString & " SET ECode_Value = " & eCodeValue.ToString &
                    " WHERE Year = " & currentYear.ToString & " AND RR_Id = " & rrID.ToString & " AND eCode_ID = " & eCode_id.ToString
            End If

            Global_Variables.gbl_ADOConnection.Execute(mSQLStr)

            rst.Close()
            rst = Nothing

        Catch ex As System.Exception
            HandleError("ERROR writing Makewhole factors", ex.Message, ex.StackTrace, "GenerateMakeWholeFactors-WriteOutEtableData")
        End Try

    End Sub

    ''' <summary>
    ''' Gets an integer value of ecode_ID for the supplied ecode
    ''' </summary>
    ''' <param name="code"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getEcodeID(ByVal code As String) As Integer

        Dim ecodeID As Integer = 0
        For Each drEcode As DataRow In dtECode_Ids.Rows()
            If drEcode("eCode").ToString() = code Then
                ecodeID = Integer.Parse(drEcode("ecode_id"))
            End If
        Next

        Return ecodeID

    End Function

    ''' <summary>
    ''' gets the ecodeid and ecode values from the UR_ECODE table
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getEcodeIDs() As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try

            Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "ECODES")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "ECODES"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "SELECT ecode_id, eCode from " & Global_Variables.gbl_Table_Name & " where eCOde Like 'E2L30%'" 'Simple select query for eCOde table
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "eCodes"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

    End Function

    ''' <summary>
    ''' gets a local copy of the CRPRES file
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getCRPRES(ByVal bLeg As Boolean) As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try

            If bLeg Then

                Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPRES_LEGACY")

                OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPRES_LEGACY"))

            Else
                Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPRES")

                OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPRES"))

            End If

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text

            cmdCommand.CommandText = "SELECT * FROM " & Global_Variables.gbl_Table_Name & " order by c1"
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "CRPRES"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    ''' <summary>
    ''' Zeros out all variables
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Refresh()

        dIndustrySwitchingResidualAll = 0.0
        dIndustrySwitchingResidualRR = 0.0
        dStationClericalResidualAll = 0.0
        dStationClericalResidualRR = 0.0
        dInterchangeSwitchingResidualAll = 0.0
        dInterchangeSwitchingResidualRR = 0.0
        dIISwitchingResidualAll = 0.0
        dIISwitchingResidualRR = 0.0
        dMileageResidualAll = 0.0
        dMileageResidualRR = 0.0

    End Sub


    ''' <summary>
    ''' Clears all rows from the UT_MAKEWHOLE_FACTORS table about to be re-populated
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub truncateUT_MAKEWHOLE_Table()
        Dim cmdCommand As SqlCommand

        Try
            Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "MAKEWHOLE_FACTORS")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "MAKEWHOLE_FACTORS"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "Truncate Table " & Global_Variables.gbl_Table_Name

            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            cmdCommand.CommandTimeout = 60
            cmdCommand.ExecuteNonQuery()

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        'clean up
        cmdCommand.Dispose()

    End Sub

    ''' <summary>
    ''' Handles error traping and writes the message and stack trace back to SQL
    ''' </summary>
    ''' <param name="message"></param>
    ''' <param name="stack"></param>
    ''' <param name="location"></param>
    ''' <remarks></remarks>
    Private Sub HandleError(ByVal data As String, ByVal message As String, ByVal stack As String, ByVal location As String)

        'write the error to SQL
        Dim cmdCommand As SqlCommand

        Try

            Dim Timestamp = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fffffff tt")
            message = message.Replace("'", "").Replace("""", "")
            stack = stack.Replace("'", "").Replace("""", "")

            Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "ERRORS")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "ERRORS"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandTimeout = 60
            cmdCommand.CommandText = "INSERT INTO " & Global_Variables.gbl_Table_Name & " VALUES ('" & data & "','" & Timestamp & "','" & message & "','" & stack & "','" & location & "')"
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            cmdCommand.ExecuteNonQuery()

        Catch ex As system.exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        'clean up
        cmdCommand.Dispose()

    End Sub

#End Region

End Class
