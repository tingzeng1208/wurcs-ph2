﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPhase3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ssStatus = New System.Windows.Forms.StatusStrip()
        Me.tssLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.btnLaunch = New System.Windows.Forms.Button()
        Me.txtYear = New System.Windows.Forms.TextBox()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.cbSegmentLoop1 = New System.Windows.Forms.CheckBox()
        Me.cbLog = New System.Windows.Forms.CheckBox()
        Me.cbSegmentLoop2 = New System.Windows.Forms.CheckBox()
        Me.rbCost = New System.Windows.Forms.RadioButton()
        Me.rbLegacyCost = New System.Windows.Forms.RadioButton()
        Me.grpParameters = New System.Windows.Forms.GroupBox()
        Me.grpOptions = New System.Windows.Forms.GroupBox()
        Me.cbSTCC = New System.Windows.Forms.CheckBox()
        Me.cbReduceL307 = New System.Windows.Forms.CheckBox()
        Me.cbAdjustTPW = New System.Windows.Forms.CheckBox()
        Me.cbAdjustL257 = New System.Windows.Forms.CheckBox()
        Me.cbUseCarOwnField = New System.Windows.Forms.CheckBox()
        Me.cbForceUnknownTOFC = New System.Windows.Forms.CheckBox()
        Me.cbChangeMileage = New System.Windows.Forms.CheckBox()
        Me.cbChangeTons = New System.Windows.Forms.CheckBox()
        Me.cbFilter0 = New System.Windows.Forms.CheckBox()
        Me.cbFilterTotal = New System.Windows.Forms.CheckBox()
        Me.cbRoundMiles = New System.Windows.Forms.CheckBox()
        Me.cbRoundTotalMiles = New System.Windows.Forms.CheckBox()
        Me.cbFilterNonUS = New System.Windows.Forms.CheckBox()
        Me.txtFolder = New System.Windows.Forms.TextBox()
        Me.btnFolder = New System.Windows.Forms.Button()
        Me.btn_Return_To_MainMenu = New System.Windows.Forms.Button()
        Me.ssStatus.SuspendLayout()
        Me.grpParameters.SuspendLayout()
        Me.grpOptions.SuspendLayout()
        Me.SuspendLayout()
        '
        'ssStatus
        '
        Me.ssStatus.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ssStatus.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tssLabel})
        Me.ssStatus.Location = New System.Drawing.Point(0, 436)
        Me.ssStatus.Name = "ssStatus"
        Me.ssStatus.Size = New System.Drawing.Size(611, 22)
        Me.ssStatus.TabIndex = 1
        '
        'tssLabel
        '
        Me.tssLabel.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.tssLabel.Name = "tssLabel"
        Me.tssLabel.Size = New System.Drawing.Size(0, 17)
        '
        'btnLaunch
        '
        Me.btnLaunch.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnLaunch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnLaunch.Location = New System.Drawing.Point(459, 320)
        Me.btnLaunch.Name = "btnLaunch"
        Me.btnLaunch.Size = New System.Drawing.Size(123, 23)
        Me.btnLaunch.TabIndex = 10
        Me.btnLaunch.Text = "Launch"
        Me.btnLaunch.UseVisualStyleBackColor = True
        '
        'txtYear
        '
        Me.txtYear.Location = New System.Drawing.Point(85, 18)
        Me.txtYear.MaxLength = 4
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(31, 21)
        Me.txtYear.TabIndex = 1
        '
        'lblYear
        '
        Me.lblYear.AutoSize = True
        Me.lblYear.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblYear.Location = New System.Drawing.Point(10, 22)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(69, 13)
        Me.lblYear.TabIndex = 0
        Me.lblYear.Text = "Current year"
        '
        'cbSegmentLoop1
        '
        Me.cbSegmentLoop1.AutoSize = True
        Me.cbSegmentLoop1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbSegmentLoop1.Location = New System.Drawing.Point(281, 20)
        Me.cbSegmentLoop1.Name = "cbSegmentLoop1"
        Me.cbSegmentLoop1.Size = New System.Drawing.Size(167, 17)
        Me.cbSegmentLoop1.TabIndex = 2
        Me.cbSegmentLoop1.Text = "Write Segment Loop 1 to SQL"
        Me.cbSegmentLoop1.UseVisualStyleBackColor = True
        '
        'cbLog
        '
        Me.cbLog.AutoSize = True
        Me.cbLog.Location = New System.Drawing.Point(462, 20)
        Me.cbLog.Name = "cbLog"
        Me.cbLog.Size = New System.Drawing.Size(79, 17)
        Me.cbLog.TabIndex = 4
        Me.cbLog.Text = "Create Log"
        Me.cbLog.UseVisualStyleBackColor = True
        '
        'cbSegmentLoop2
        '
        Me.cbSegmentLoop2.AutoSize = True
        Me.cbSegmentLoop2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbSegmentLoop2.Location = New System.Drawing.Point(281, 43)
        Me.cbSegmentLoop2.Name = "cbSegmentLoop2"
        Me.cbSegmentLoop2.Size = New System.Drawing.Size(167, 17)
        Me.cbSegmentLoop2.TabIndex = 3
        Me.cbSegmentLoop2.Text = "Write Segment Loop 2 to SQL"
        Me.cbSegmentLoop2.UseVisualStyleBackColor = True
        '
        'rbCost
        '
        Me.rbCost.AutoSize = True
        Me.rbCost.Location = New System.Drawing.Point(13, 116)
        Me.rbCost.Name = "rbCost"
        Me.rbCost.Size = New System.Drawing.Size(143, 17)
        Me.rbCost.TabIndex = 8
        Me.rbCost.Text = "Cost the Way Bill Sample"
        Me.rbCost.UseVisualStyleBackColor = True
        '
        'rbLegacyCost
        '
        Me.rbLegacyCost.AutoSize = True
        Me.rbLegacyCost.Checked = True
        Me.rbLegacyCost.Location = New System.Drawing.Point(13, 93)
        Me.rbLegacyCost.Name = "rbLegacyCost"
        Me.rbLegacyCost.Size = New System.Drawing.Size(194, 17)
        Me.rbLegacyCost.TabIndex = 7
        Me.rbLegacyCost.TabStop = True
        Me.rbLegacyCost.Text = "Cost the Way Bill Sample as Legacy"
        Me.rbLegacyCost.UseVisualStyleBackColor = True
        '
        'grpParameters
        '
        Me.grpParameters.Controls.Add(Me.grpOptions)
        Me.grpParameters.Controls.Add(Me.txtFolder)
        Me.grpParameters.Controls.Add(Me.btnFolder)
        Me.grpParameters.Controls.Add(Me.rbLegacyCost)
        Me.grpParameters.Controls.Add(Me.rbCost)
        Me.grpParameters.Controls.Add(Me.cbSegmentLoop2)
        Me.grpParameters.Controls.Add(Me.cbLog)
        Me.grpParameters.Controls.Add(Me.cbSegmentLoop1)
        Me.grpParameters.Controls.Add(Me.lblYear)
        Me.grpParameters.Controls.Add(Me.txtYear)
        Me.grpParameters.Controls.Add(Me.btnLaunch)
        Me.grpParameters.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.grpParameters.Location = New System.Drawing.Point(9, 8)
        Me.grpParameters.Name = "grpParameters"
        Me.grpParameters.Size = New System.Drawing.Size(588, 349)
        Me.grpParameters.TabIndex = 0
        Me.grpParameters.TabStop = False
        Me.grpParameters.Text = "Select Input Parameters"
        '
        'grpOptions
        '
        Me.grpOptions.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpOptions.Controls.Add(Me.cbSTCC)
        Me.grpOptions.Controls.Add(Me.cbReduceL307)
        Me.grpOptions.Controls.Add(Me.cbAdjustTPW)
        Me.grpOptions.Controls.Add(Me.cbAdjustL257)
        Me.grpOptions.Controls.Add(Me.cbUseCarOwnField)
        Me.grpOptions.Controls.Add(Me.cbForceUnknownTOFC)
        Me.grpOptions.Controls.Add(Me.cbChangeMileage)
        Me.grpOptions.Controls.Add(Me.cbChangeTons)
        Me.grpOptions.Controls.Add(Me.cbFilter0)
        Me.grpOptions.Controls.Add(Me.cbFilterTotal)
        Me.grpOptions.Controls.Add(Me.cbRoundMiles)
        Me.grpOptions.Controls.Add(Me.cbRoundTotalMiles)
        Me.grpOptions.Controls.Add(Me.cbFilterNonUS)
        Me.grpOptions.Enabled = False
        Me.grpOptions.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.grpOptions.Location = New System.Drawing.Point(6, 132)
        Me.grpOptions.Name = "grpOptions"
        Me.grpOptions.Size = New System.Drawing.Size(576, 181)
        Me.grpOptions.TabIndex = 9
        Me.grpOptions.TabStop = False
        '
        'cbSTCC
        '
        Me.cbSTCC.AutoSize = True
        Me.cbSTCC.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbSTCC.Location = New System.Drawing.Point(275, 135)
        Me.cbSTCC.Name = "cbSTCC"
        Me.cbSTCC.Size = New System.Drawing.Size(160, 17)
        Me.cbSTCC.TabIndex = 12
        Me.cbSTCC.Text = "Use SQL to Determine STCC"
        Me.cbSTCC.UseVisualStyleBackColor = True
        '
        'cbReduceL307
        '
        Me.cbReduceL307.AutoSize = True
        Me.cbReduceL307.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbReduceL307.Location = New System.Drawing.Point(275, 112)
        Me.cbReduceL307.Name = "cbReduceL307"
        Me.cbReduceL307.Size = New System.Drawing.Size(254, 17)
        Me.cbReduceL307.TabIndex = 11
        Me.cbReduceL307.Text = "Reduce L307 for International Border Crossings"
        Me.cbReduceL307.UseVisualStyleBackColor = True
        '
        'cbAdjustTPW
        '
        Me.cbAdjustTPW.AutoSize = True
        Me.cbAdjustTPW.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbAdjustTPW.Location = New System.Drawing.Point(275, 89)
        Me.cbAdjustTPW.Name = "cbAdjustTPW"
        Me.cbAdjustTPW.Size = New System.Drawing.Size(123, 17)
        Me.cbAdjustTPW.TabIndex = 10
        Me.cbAdjustTPW.Text = "Adjust TPW to BNSF"
        Me.cbAdjustTPW.UseVisualStyleBackColor = True
        '
        'cbAdjustL257
        '
        Me.cbAdjustL257.AutoSize = True
        Me.cbAdjustL257.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbAdjustL257.Location = New System.Drawing.Point(275, 66)
        Me.cbAdjustL257.Name = "cbAdjustL257"
        Me.cbAdjustL257.Size = New System.Drawing.Size(189, 17)
        Me.cbAdjustL257.TabIndex = 9
        Me.cbAdjustL257.Text = "Adjust L257 to Use L204 Rounded"
        Me.cbAdjustL257.UseVisualStyleBackColor = True
        '
        'cbUseCarOwnField
        '
        Me.cbUseCarOwnField.AutoSize = True
        Me.cbUseCarOwnField.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbUseCarOwnField.Location = New System.Drawing.Point(275, 43)
        Me.cbUseCarOwnField.Name = "cbUseCarOwnField"
        Me.cbUseCarOwnField.Size = New System.Drawing.Size(299, 17)
        Me.cbUseCarOwnField.TabIndex = 8
        Me.cbUseCarOwnField.Text = "Use the car_own Field from Masked Instead of u_car_init"
        Me.cbUseCarOwnField.UseVisualStyleBackColor = True
        '
        'cbForceUnknownTOFC
        '
        Me.cbForceUnknownTOFC.AutoSize = True
        Me.cbForceUnknownTOFC.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbForceUnknownTOFC.Location = New System.Drawing.Point(275, 20)
        Me.cbForceUnknownTOFC.Name = "cbForceUnknownTOFC"
        Me.cbForceUnknownTOFC.Size = New System.Drawing.Size(252, 17)
        Me.cbForceUnknownTOFC.TabIndex = 7
        Me.cbForceUnknownTOFC.Text = "Force Unknown TOFC Moves to Serv Code of X"
        Me.cbForceUnknownTOFC.UseVisualStyleBackColor = True
        '
        'cbChangeMileage
        '
        Me.cbChangeMileage.AutoSize = True
        Me.cbChangeMileage.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbChangeMileage.Location = New System.Drawing.Point(6, 158)
        Me.cbChangeMileage.Name = "cbChangeMileage"
        Me.cbChangeMileage.Size = New System.Drawing.Size(236, 17)
        Me.cbChangeMileage.TabIndex = 6
        Me.cbChangeMileage.Text = "Change Mileage Restriction from <1 to <=0"
        Me.cbChangeMileage.UseVisualStyleBackColor = True
        '
        'cbChangeTons
        '
        Me.cbChangeTons.AutoSize = True
        Me.cbChangeTons.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbChangeTons.Location = New System.Drawing.Point(6, 135)
        Me.cbChangeTons.Name = "cbChangeTons"
        Me.cbChangeTons.Size = New System.Drawing.Size(226, 17)
        Me.cbChangeTons.TabIndex = 5
        Me.cbChangeTons.Text = "Change Tons Restriction from < 1 to <=0"
        Me.cbChangeTons.UseVisualStyleBackColor = True
        '
        'cbFilter0
        '
        Me.cbFilter0.AutoSize = True
        Me.cbFilter0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbFilter0.Location = New System.Drawing.Point(6, 112)
        Me.cbFilter0.Name = "cbFilter0"
        Me.cbFilter0.Size = New System.Drawing.Size(139, 17)
        Me.cbFilter0.TabIndex = 4
        Me.cbFilter0.Text = "Filter 0 Revenue Moves"
        Me.cbFilter0.UseVisualStyleBackColor = True
        '
        'cbFilterTotal
        '
        Me.cbFilterTotal.AutoSize = True
        Me.cbFilterTotal.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbFilterTotal.Location = New System.Drawing.Point(6, 89)
        Me.cbFilterTotal.Name = "cbFilterTotal"
        Me.cbFilterTotal.Size = New System.Drawing.Size(250, 17)
        Me.cbFilterTotal.TabIndex = 3
        Me.cbFilterTotal.Text = "Filter Total < 2 Miles for Single Segment Moves"
        Me.cbFilterTotal.UseVisualStyleBackColor = True
        '
        'cbRoundMiles
        '
        Me.cbRoundMiles.AutoSize = True
        Me.cbRoundMiles.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbRoundMiles.Location = New System.Drawing.Point(6, 66)
        Me.cbRoundMiles.Name = "cbRoundMiles"
        Me.cbRoundMiles.Size = New System.Drawing.Size(83, 17)
        Me.cbRoundMiles.TabIndex = 2
        Me.cbRoundMiles.Text = "Round Miles"
        Me.cbRoundMiles.UseVisualStyleBackColor = True
        '
        'cbRoundTotalMiles
        '
        Me.cbRoundTotalMiles.AutoSize = True
        Me.cbRoundTotalMiles.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbRoundTotalMiles.Location = New System.Drawing.Point(6, 43)
        Me.cbRoundTotalMiles.Name = "cbRoundTotalMiles"
        Me.cbRoundTotalMiles.Size = New System.Drawing.Size(110, 17)
        Me.cbRoundTotalMiles.TabIndex = 1
        Me.cbRoundTotalMiles.Text = "Round Total Miles"
        Me.cbRoundTotalMiles.UseVisualStyleBackColor = True
        '
        'cbFilterNonUS
        '
        Me.cbFilterNonUS.AutoSize = True
        Me.cbFilterNonUS.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cbFilterNonUS.Location = New System.Drawing.Point(6, 20)
        Me.cbFilterNonUS.Name = "cbFilterNonUS"
        Me.cbFilterNonUS.Size = New System.Drawing.Size(146, 17)
        Me.cbFilterNonUS.TabIndex = 0
        Me.cbFilterNonUS.Text = "Filter Non US Movements"
        Me.cbFilterNonUS.UseVisualStyleBackColor = True
        '
        'txtFolder
        '
        Me.txtFolder.Location = New System.Drawing.Point(13, 66)
        Me.txtFolder.Name = "txtFolder"
        Me.txtFolder.ReadOnly = True
        Me.txtFolder.Size = New System.Drawing.Size(436, 21)
        Me.txtFolder.TabIndex = 5
        '
        'btnFolder
        '
        Me.btnFolder.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnFolder.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnFolder.Location = New System.Drawing.Point(459, 64)
        Me.btnFolder.Name = "btnFolder"
        Me.btnFolder.Size = New System.Drawing.Size(123, 23)
        Me.btnFolder.TabIndex = 6
        Me.btnFolder.Text = "Select Output Folder"
        Me.btnFolder.UseVisualStyleBackColor = True
        '
        'btn_Return_To_MainMenu
        '
        Me.btn_Return_To_MainMenu.Image = Global.URCS_And_Waybills.My.Resources.Resources.ExitDoor
        Me.btn_Return_To_MainMenu.Location = New System.Drawing.Point(546, 372)
        Me.btn_Return_To_MainMenu.Name = "btn_Return_To_MainMenu"
        Me.btn_Return_To_MainMenu.Size = New System.Drawing.Size(51, 52)
        Me.btn_Return_To_MainMenu.TabIndex = 22
        Me.btn_Return_To_MainMenu.UseVisualStyleBackColor = True
        '
        'frmPhase3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(611, 458)
        Me.Controls.Add(Me.btn_Return_To_MainMenu)
        Me.Controls.Add(Me.grpParameters)
        Me.Controls.Add(Me.ssStatus)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmPhase3"
        Me.Text = "URCS Phase III Way Bill"
        Me.ssStatus.ResumeLayout(False)
        Me.ssStatus.PerformLayout()
        Me.grpParameters.ResumeLayout(False)
        Me.grpParameters.PerformLayout()
        Me.grpOptions.ResumeLayout(False)
        Me.grpOptions.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ssStatus As System.Windows.Forms.StatusStrip
    Friend WithEvents tssLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents btnLaunch As System.Windows.Forms.Button
    Friend WithEvents txtYear As System.Windows.Forms.TextBox
    Friend WithEvents lblYear As System.Windows.Forms.Label
    Friend WithEvents cbSegmentLoop1 As System.Windows.Forms.CheckBox
    Friend WithEvents cbLog As System.Windows.Forms.CheckBox
    Friend WithEvents cbSegmentLoop2 As System.Windows.Forms.CheckBox
    Friend WithEvents rbCost As System.Windows.Forms.RadioButton
    Friend WithEvents rbLegacyCost As System.Windows.Forms.RadioButton
    Friend WithEvents grpParameters As System.Windows.Forms.GroupBox
    Friend WithEvents txtFolder As System.Windows.Forms.TextBox
    Friend WithEvents btnFolder As System.Windows.Forms.Button
    Friend WithEvents grpOptions As System.Windows.Forms.GroupBox
    Friend WithEvents cbSTCC As System.Windows.Forms.CheckBox
    Friend WithEvents cbReduceL307 As System.Windows.Forms.CheckBox
    Friend WithEvents cbAdjustTPW As System.Windows.Forms.CheckBox
    Friend WithEvents cbAdjustL257 As System.Windows.Forms.CheckBox
    Friend WithEvents cbUseCarOwnField As System.Windows.Forms.CheckBox
    Friend WithEvents cbForceUnknownTOFC As System.Windows.Forms.CheckBox
    Friend WithEvents cbChangeMileage As System.Windows.Forms.CheckBox
    Friend WithEvents cbChangeTons As System.Windows.Forms.CheckBox
    Friend WithEvents cbFilter0 As System.Windows.Forms.CheckBox
    Friend WithEvents cbFilterTotal As System.Windows.Forms.CheckBox
    Friend WithEvents cbRoundMiles As System.Windows.Forms.CheckBox
    Friend WithEvents cbRoundTotalMiles As System.Windows.Forms.CheckBox
    Friend WithEvents cbFilterNonUS As System.Windows.Forms.CheckBox
    Friend WithEvents btn_Return_To_MainMenu As System.Windows.Forms.Button

End Class
