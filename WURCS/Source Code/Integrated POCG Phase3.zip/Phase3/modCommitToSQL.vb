﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient

Public Class CommitToSQL

#Region "Declarations"

    Dim daAdapterSeg As SqlDataAdapter
    Dim dsDataSetSeg As New DataSet

    Dim daAdapterMW As SqlDataAdapter
    Dim dsDataSetMW As New DataSet

    'local Legacy boolean
    Dim bLegacy As Boolean

    'local serial and segment vars
    Dim iSerialNum As Integer
    Dim iSegmentNumber As Integer
    Dim iL700 As Integer

    'local totalVC Table
    Dim dtTotVC As New DataTable()

    'local etableFactors Table
    Dim dtEtableFactors As New DataTable()

#End Region

#Region "Main functions"

    Public Sub New(ByVal Conn As String, ByVal CurrentYear As String, ByVal Legacy As Boolean)

        'Write row to error table to announce end of processing
        HandleError("Status", "Started Commit to SQL Process", "Started Commit to SQL Process", "Started Commit to SQL Process")

        'Pre clense the SQL tables
        PreCommitMasked()
        PreCommitSegments()

        'store legacy boolean
        bLegacy = Legacy

        'fill data tables for program use
        '========================================================================
        dtTotVC = getTotVC(bLegacy)

        dtEtableFactors = getFactorsTable()

        'loop through and write the TotalVC back to the Masked and Segments tables
        '========================================================================
        For Each dr As DataRow In dtTotVC.Rows()

            Try

                iSerialNum = Integer.Parse(dr("SerialNum"))
                iSegmentNumber = Integer.Parse(dr("SegmentNumber"))
                iL700 = Math.Round(Double.Parse(dr("L700")))

                'update the segments table
                writeSegmentsUpdate()

                'update the Maksed table
                writeMaskedUpdate()

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "CommitToSQL-Loop")
            End Try

        Next

        'loop through and write the eTable Values back to the U_ETABLES table
        '========================================================================
        For Each dr As DataRow In dtEtableFactors.Rows()

            Try
                CommitEtableDataForMakeWhole(dr("year").ToString(), Integer.Parse(dr("RR_ID")), Integer.Parse(dr("eCode_ID")), Double.Parse(dr("eCode_Value")))
            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "CommitToSQL-Loop")
            End Try
        Next


        'Write row to error table to announce end of processing
        HandleError("Status", "Ended Commit to SQL Process", "Ended Commit to SQL Process", "Ended Commit to SQL Process")

    End Sub

#End Region

#Region "Helper Functions"

    ''' <summary>
    ''' zeros out all masked table data
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PreCommitMasked()

        Dim cmdCommand As SqlCommand

        Try
            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "MASKED"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text

            cmdCommand.CommandText = "UPDATE " & Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "MASKED") & " SET Total_VC = 0, " &
                "RR1_VC = 0, RR2_VC = 0, RR3_VC = 0, RR4_VC = 0, RR5_VC = 0, RR6_VC = 0, RR7_VC = 0, RR8_VC = 0"
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection
            cmdCommand.CommandTimeout = 60
            cmdCommand.ExecuteNonQuery()

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        'clean up
        cmdCommand.Dispose()

    End Sub

    ''' <summary>
    ''' zeros out all Segments table data
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PreCommitSegments()

        Dim cmdCommand As SqlCommand

        Try
            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "SEGMENTS"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text

            cmdCommand.CommandText = "UPDATE " & Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "SEGMENTS") & " SET RR_VC = 0"
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection
            cmdCommand.ExecuteNonQuery()

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        'clean up
        cmdCommand.Dispose()

    End Sub

    ''' <summary>
    ''' Writes data back to the Masked Table
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub writeMaskedUpdate()

        Dim cmdCommand As SqlCommand

        Try
            Global_Variables.Gbl_Masked_TableName = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "MASKED")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "MASKED"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandTimeout = 60

            cmdCommand.CommandText = "UPDATE " & Global_Variables.Gbl_Masked_TableName & " SET "
            Select Case iSegmentNumber
                Case 1
                    cmdCommand.CommandText += "Total_VC = " & iL700.ToString() & ", RR1_VC = " & iL700.ToString()
                Case 2
                    cmdCommand.CommandText += "Total_VC = (Total_VC + " & iL700.ToString() & "), RR2_VC = " & iL700.ToString()
                Case 3
                    cmdCommand.CommandText += "Total_VC = (Total_VC + " & iL700.ToString() & "), RR3_VC = " & iL700.ToString()
                Case 4
                    cmdCommand.CommandText += "Total_VC = (Total_VC + " & iL700.ToString() & "), RR4_VC = " & iL700.ToString()
                Case 5
                    cmdCommand.CommandText += "Total_VC = (Total_VC + " & iL700.ToString() & "), RR5_VC = " & iL700.ToString()
                Case 5
                    cmdCommand.CommandText += "Total_VC = (Total_VC + " & iL700.ToString() & "), RR6_VC = " & iL700.ToString()
                Case 7
                    cmdCommand.CommandText += "Total_VC = (Total_VC + " & iL700.ToString() & "), RR7_VC = " & iL700.ToString()
                Case 8
                    cmdCommand.CommandText += "Total_VC = (Total_VC + " & iL700.ToString() & "), RR8_VC = " & iL700.ToString()
            End Select
            cmdCommand.CommandText += " WHERE Serial_No = " & iSerialNum.ToString()
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection
            cmdCommand.CommandTimeout = 60

            cmdCommand.ExecuteNonQuery()

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

    End Sub

    ''' <summary>
    ''' writes data back to the segments table
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub writeSegmentsUpdate()

        Dim cmdCommand As SqlCommand

        Try
            Global_Variables.Gbl_Segments_TableName = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "SEGMENTS")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "SEGMENTS"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandTimeout = 60
            cmdCommand.CommandText = "UPDATE " & Global_Variables.Gbl_Segments_TableName & " SET RR_VC = " & iL700.ToString() & " WHERE Serial_no = " & iSerialNum.ToString() & " and Seg_no = " & iSegmentNumber.ToString()
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            cmdCommand.ExecuteNonQuery()

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

    End Sub

    ''' <summary>
    ''' Commits the temp Make Whole Factors back out to the U_ETABLES table
    ''' </summary>
    ''' <param name="currentYear"></param>
    ''' <param name="rrID"></param>
    ''' <param name="eCode_id"></param>
    ''' <param name="eCodeValue"></param>
    ''' <remarks></remarks>
    Private Sub CommitEtableDataForMakeWhole(ByVal currentYear As String, ByVal rrID As Integer, ByVal eCode_id As Integer, ByVal eCodeValue As Double)

        Dim cmdCommand As SqlCommand

        Try
            Global_Variables.Gbl_EValues_TableName = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "EVALUES")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "EVALUES"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "UPDATE " & Global_Variables.Gbl_EValues_TableName &
                " SET Value = " & eCodeValue.ToString & " WHERE eCode_id = " & eCode_id.ToString & " and Year = " & currentYear.ToString & " and RR_Id = " & Integer.Parse(rrID)
            cmdCommand.CommandTimeout = 60
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            cmdCommand.ExecuteNonQuery()

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

    End Sub

    ''' <summary>
    ''' Gets the serialNum, SegmentNumber, and TotVC(L700) from the CRPSEG table
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getTotVC(ByVal bLeg As Boolean) As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try

            If bLeg Then
                Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_LEGACY")
                Global_Variables.gbl_Database_Name = Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_LEGACY")
            Else
                Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG")
                Global_Variables.gbl_Database_Name = Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG")
            End If

            OpenSQLConnection(Global_Variables.gbl_Database_Name)

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "SELECT SerialNum, SegmentNumber, L700 FROM " & Global_Variables.gbl_Table_Name
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "TotVC"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    ''' <summary>
    ''' gets the temp makeWhole factors to loop through and commit
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getFactorsTable() As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try
            Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "MAKEWHOLE_FACTORS")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "MAKEWHOLE_FACTORS"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "SELECT * FROM " & Global_Variables.gbl_Table_Name
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "Factors"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    ''' <summary>
    ''' Handles error traping and writes the message and stack trace back to SQL
    ''' </summary>
    ''' <param name="message"></param>
    ''' <param name="stack"></param>
    ''' <param name="location"></param>
    ''' <remarks></remarks>
    Private Sub HandleError(ByVal data As String, ByVal message As String, ByVal stack As String, ByVal location As String)

        'write the error to SQL
        Dim cmdCommand As SqlCommand

        Try

            Dim Timestamp = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fffffff tt")
            message = message.Replace("'", "").Replace("""", "")
            stack = stack.Replace("'", "").Replace("""", "")

            Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "ERRORS")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "ERRORS"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandTimeout = 60
            cmdCommand.CommandText = "INSERT INTO " & Global_Variables.gbl_Table_Name & " VALUES ('" & data & "','" & Timestamp & "','" & message & "','" & stack & "','" & location & "')"
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            cmdCommand.ExecuteNonQuery()

        Catch ex As system.exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        'clean up
        cmdCommand.Dispose()

    End Sub

#End Region

End Class
