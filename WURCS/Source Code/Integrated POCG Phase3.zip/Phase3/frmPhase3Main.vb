﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Threading
Imports System.Xml

Public Class frmPhase3Main

#Region "Declarations"

    Dim sLogFileName As String

    Private Delegate Sub DelegateUpdateStatus(ByVal StatusText As String)
    Private Delegate Sub DelegateThreadDone()
    Private Event ThreadDone()

#End Region

#Region "Form events"

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim rst As ADODB.Recordset

        'Set the form so it centers on the user's screen
        Me.CenterToScreen()

        ' Load the Year combobox from the SQL database
        rst = SetRST()
        rst = Get_URCS_Years(rst)

        Do While Not rst.EOF
            cmb_URCS_Year.Items.Add(rst.Fields(0).Value)
            rst.MoveNext()
        Loop

        rst.Close()

        txtFolder.Text = My.Settings.OutputDirectory
        cbLog.Checked = My.Settings.CreateLog

        Me.CenterToScreen()

        sLogFileName = txtFolder.Text & "\Log\CostWayBill.log"

        AddHandler ThreadDone, AddressOf ThreadIsDone

        EnableControls()

    End Sub

    Private Sub rbLegacyCost_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbLegacyCost.CheckedChanged

        grpOptions.Enabled = rbCost.Checked

    End Sub

    Private Sub btnFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFolder.Click

        Dim oFolderBrowserDialog As FolderBrowserDialog

        oFolderBrowserDialog = New FolderBrowserDialog
        oFolderBrowserDialog.ShowDialog()

        If oFolderBrowserDialog.SelectedPath.Length > 0 Then
            txtFolder.Text = oFolderBrowserDialog.SelectedPath
        End If

    End Sub

    Private Sub btnLaunch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLaunch.Click

        If ValidateFormData() Then

            With My.Settings
                .CurrentYear = cmb_URCS_Year.Text
                .OutputDirectory = txtFolder.Text
                .CreateLog = cbLog.Checked
                .Save()
            End With

            Dim oWorkerThread As Thread

            oWorkerThread = New Thread(New ThreadStart(AddressOf LaunchProcess))
            oWorkerThread.Start()

            EnableControls(False)

        End If
    End Sub

    Private Sub btn_Return_To_MainMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Return_To_MainMenu.Click
        ' Open the Main Menu Form
        Dim frmNew As New frm_MainMenu()
        frmNew.Show()
        ' Close this Menu
        Me.Close()
    End Sub

#End Region

#Region "Delegate handlers"

    Private Sub CostWayBillStatusUpdated(ByVal StatusText As String)

        Me.Invoke(New DelegateUpdateStatus(AddressOf UpdateStatus), StatusText)

    End Sub

    Private Sub ThreadIsDone()

        Me.Invoke(New DelegateThreadDone(AddressOf EnableControls))

    End Sub

#End Region

#Region "Helper functions"

    Private Sub LaunchProcess()

        Dim oWayBill As CostWayBill

        UpdateStatus("Started Cost WayBill for " + My.Settings.CurrentYear.ToString)

        'Cost WayBill
        If rbLegacyCost.Checked Then

            oWayBill = New CostWayBill(My.Settings.CurrentYear.ToString, _
                                       True, _
                                       False, _
                                       True, _
                                       True, _
                                       cbSegmentLoop1.Checked, _
                                       cbSegmentLoop2.Checked, _
                                       True, _
                                       True, _
                                       False, _
                                       False, _
                                       False, _
                                       False, _
                                       False, _
                                       True, _
                                       False, _
                                       False)
        Else
            oWayBill = New CostWayBill(My.Settings.CurrentYear.ToString, _
                                      False, _
                                      cbFilterNonUS.Checked, _
                                      cbRoundTotalMiles.Checked, _
                                      cbRoundMiles.Checked, _
                                      cbSegmentLoop1.Checked, _
                                      cbSegmentLoop2.Checked, _
                                      cbFilterTotal.Checked, _
                                      cbFilter0.Checked, _
                                      cbChangeTons.Checked, _
                                      cbChangeMileage.Checked, _
                                      cbForceUnknownTOFC.Checked, _
                                      cbUseCarOwnField.Checked, _
                                      cbAdjustL257.Checked, _
                                      cbAdjustTPW.Checked, _
                                      cbReduceL307.Checked, _
                                      cbSTCC.Checked)
        End If

        AddHandler oWayBill.StatusUpdated, AddressOf CostWayBillStatusUpdated
        oWayBill.Process()

        'Generate the make whole factors
        UpdateStatus("Generating Make Whole Factors")
        Dim clsGenMakeWhole As New GenerateMakeWholeFactors(My.Settings.ConnectionString, My.Settings.CurrentYear.ToString, rbLegacyCost.Checked)

        'Apply the make whole factors
        UpdateStatus("Applying Make Whole Factors")
        Dim clsApplyMW As New ApplyMakeWholeToCRPSEG(My.Settings.ConnectionString, My.Settings.CurrentYear.ToString, rbLegacyCost.Checked)

        'Commit to SQL
        UpdateStatus("Writing Updates to SQL")
        Dim clsCommit As New CommitToSQL(My.Settings.ConnectionString, My.Settings.CurrentYear.ToString, rbLegacyCost.Checked)

        'Create XML file
        UpdateStatus("Writing XML File")
        CreateXML(My.Settings.CurrentYear.ToString)

        UpdateStatus("Finished")

        RaiseEvent ThreadDone()

    End Sub

    Private Function ValidateFormData() As Boolean

        Try
            Integer.Parse(cmb_URCS_Year.Text)
        Catch
            MessageBox.Show("The year entered does not appear to be a valid value.")
            Return False
        End Try

        If Integer.Parse(cmb_URCS_Year.Text) < 1990 Then
            MessageBox.Show("Please enter a valid 4 digit year greater than 1990")
            Return False
        End If

        If Integer.Parse(cmb_URCS_Year.Text) > Now.Year Then
            MessageBox.Show("The year entered is invalid as it is in the future")
            Return False
        End If

        'Check if output folder exists
        If Not Directory.Exists(txtFolder.Text) Then
            MessageBox.Show("The output folder does not exist. Please, choose a valid folder.")
            Return False
        End If

        'Check if files from previous run exist
        If Directory.GetFiles(txtFolder.Text, "*.xml").Count > 0 Then
            If MessageBox.Show("The output folder contains files which will be overriden during the run. Would you like to continue?", "Warning", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.No Then
                Return False
            End If
        End If

        'Create log folder
        If cbLog.Checked And Not Directory.Exists(txtFolder.Text & "\Log") Then
            Directory.CreateDirectory(txtFolder.Text & "\Log")
        End If

        Return True

    End Function

    Private Sub SaveSettings()

        With My.Settings
            .CurrentYear = cmb_URCS_Year.Text
            .OutputDirectory = txtFolder.Text
            .CreateLog = cbLog.Checked
            .Save()
        End With

    End Sub

    Private Sub CreateXML(ByVal Year As String)

        Dim cmdCommand As SqlCommand
        Dim oWriter As System.IO.StreamWriter
        Dim oDirectory As DirectoryInfo
        Dim oFiles As FileInfo()
        Dim sFileName As String, mWorkString As String

        OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "EVALUES"))

        cmdCommand = New SqlClient.SqlCommand
        cmdCommand.CommandType = CommandType.StoredProcedure
        cmdCommand.CommandText = "usp_GenerateEValuesXML"
        cmdCommand.Connection = Global_Variables.gbl_SQLConnection

        Dim inputValue As SqlParameter = New SqlParameter("@Year", SqlDbType.Char, 4)
        inputValue.Value = Year
        inputValue.Direction = ParameterDirection.Input
        cmdCommand.Parameters.Add(inputValue)

        Dim returnValue As SqlParameter = New SqlParameter("@Output", SqlDbType.Xml)
        returnValue.Direction = ParameterDirection.Output
        cmdCommand.Parameters.Add(returnValue)

        cmdCommand.ExecuteReader()
        cmdCommand.CommandTimeout = 60

        'If file already exists, delete the existing
        sFileName = My.Settings.FileName.Replace("%year%", Year.ToString)

        oDirectory = New IO.DirectoryInfo(txtFolder.Text)
        oFiles = oDirectory.GetFiles("*.xml")
        If oFiles.Count > 0 Then
            For Each oFile As FileInfo In oFiles
                If oFile.Name = sFileName Then
                    oFile.Delete()
                End If
            Next
        End If

        'Create XML file
        oWriter = New System.IO.StreamWriter(txtFolder.Text + "\" + sFileName, True, System.Text.Encoding.Unicode)
        mWorkString = "<?xml version=""1.0"" encoding=""utf-16"" standalone=""yes""?>"
        oWriter.WriteLine(mWorkString)
        mWorkString = returnValue.Value
        mWorkString = Replace(mWorkString, "<R", "  <R")
        mWorkString = Replace(mWorkString, "</R", "  </R")
        mWorkString = Replace(mWorkString, "<E", "    <E")
        mWorkString = Replace(mWorkString, "a>", "a>" & vbCrLf)
        mWorkString = Replace(mWorkString, "d>", "d>" & vbCrLf)
        mWorkString = Replace(mWorkString, """>", """>" & vbCrLf)
        mWorkString = Replace(mWorkString, "-->", "-->" & vbCrLf)
        mWorkString = Replace(mWorkString, "/>", "/>" & vbCrLf)

        oWriter.WriteLine(mWorkString)
        oWriter.Close()


    End Sub

    Private Function GetMaskedTablesLocation(ByVal DataType As String) As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try
            ' Connection String replaced 11/25 MRS
            'cnConnection.ConnectionString = My.Settings.ConnectionString
            OpenSQLConnection(Get_Database_Name_From_SQL("1", "TABLE_LOCATOR"))

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "SELECT TOP 1 Database_Name, Table_Name FROM U_TABLE_LOCATOR WHERE Year = " +
                                        My.Settings.CurrentYear.ToString + " AND Data_Type = '" + DataType + "'"

            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = DataType + "Location"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    Private Sub UpdateStatus(ByVal StatusText As String)

        'write the error to SQL
        Dim cmdCommand As New SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet
        Dim Timestamp As String
        Dim Message As String

        Try

            Timestamp = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.ffff tt")
            Message = StatusText.Replace("'", "").Replace("""", "")

            ' Locate the Error table - It should always be in the Controls database
            Global_Variables.Gbl_Errors_TableName = Get_Table_Name_From_SQL("1", "ERRORS")

            ' Open the SQL connection
            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "ERRORS"))
            dsDataSet.Clear()

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "INSERT INTO " & Global_Variables.Gbl_Errors_TableName & " VALUES ('Status','" & Timestamp & "','" & Message & "','','')"
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

        Catch SqlEx As SqlException
            Throw New System.Exception("SQL error when writing U_ERRORS record.  SQL statement: " & cmdCommand.CommandText, SqlEx)
        End Try

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()


        ' Update the user screen with the message
        tssLabel.Text = StatusText

    End Sub

    Private Sub EnableControls(Optional ByVal Status As Boolean = True)

        grpParameters.Enabled = Status

    End Sub

#End Region

End Class