﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient

Public Class ApplyMakeWholeToCRPSEG

#Region "Declarations"

    'local SQL variable
    Dim ConnString As String
    Dim cnInsertConnection As New SqlConnection
    Dim cmdInsertCommand As SqlCommand
    Dim daInsertAdapter As SqlDataAdapter
    Dim dsInsertDataSet As New DataSet

    'current year variable
    Dim sCurrentYear As String

    'local Legacy boolean
    Dim bLegacy As Boolean

    'calculation variables
    Dim iSerialNum As Integer
    Dim iSegmentNumber As Integer
    Dim sShipmentSize As String
    Dim sSegmentType As String
    Dim iCarTYpe As Integer
    Dim sOwnership As String

    Dim iRR_ID As Integer
    Dim iRR_Region As Integer
    Dim iNumCars As Integer

    'line number vars needed for calc
    Dim dL205 As Double

    Dim dL251 As Double
    Dim dL252 As Double

    Dim dL304 As Double
    Dim dL305 As Double
    Dim dL308 As Double
    Dim dL323 As Double
    Dim dL324 As Double

    Dim dL573 As Double
    Dim dL574 As Double
    Dim dL575 As Double
    Dim dL576 As Double
    Dim dL577 As Double
    Dim dL578 As Double
    Dim dL579 As Double
    Dim dL580 As Double
    Dim dL581 As Double
    Dim dL582 As Double
    Dim dL583 As Double
    Dim dL584 As Double
    Dim dL585 As Double
    Dim dL586 As Double
    Dim dL587 As Double

    Dim dL696 As Double
    Dim dL699 As Double
    Dim dL700 As Double

    'local refference tables
    Dim dtRailroads As DataTable
    Dim dtEcodes As DataTable
    Dim dtEtable As DataTable

    'local copy of CRPSEG
    Dim dtCRPSEG As New DataTable

#End Region

#Region "Main functions"

    Public Sub New(ByVal Conn As String, ByVal CurrentYear As String, ByVal Legacy As Boolean)

        'truncate the ERROR Table
        'truncateERRORSTable()

        'Write row to error table to announce end of processing
        HandleError("Status", "Started Apply MakeWhole to CRPSEG Process", "Started Apply MakeWhole to CRPSEG Process", "Started Apply MakeWhole to CRPSEG Process")

        'store current year
        sCurrentYear = CurrentYear.ToString()

        'store legacy boolean
        bLegacy = Legacy

        'fill data tables for program use
        '========================================================================

        'Railroad data
        dtRailroads = fillRailroads()

        'Ecode Data (specific to the ecode itself)
        dtEcodes = fillEcodes()

        'The actual etable data by railroad.
        'each table is named with a rr_id
        dtEtable = fillEtable_WithMakeTempMakeWhole()

        'get the CRPSEG values we need
        dtCRPSEG = getCRPSEG(bLegacy)

        'Loop CRPSEG and re-calc Jurisdictional AddOn Costs & L700
        '========================================================================
        For Each dr As DataRow In dtCRPSEG.Rows()

            Try

                iSerialNum = Integer.Parse(dr("SerialNum"))
                iSegmentNumber = Integer.Parse(dr("SegmentNumber"))
                sShipmentSize = dr("ShipmentSize").ToString()
                sSegmentType = dr("SegmentType").ToString()
                iCarTYpe = Integer.Parse(dr("CarTYpe"))
                sOwnership = dr("Ownership").ToString()

                iRR_ID = Integer.Parse(dr("RR_ID"))
                iRR_Region = Integer.Parse(dr("RR_Region"))
                iNumCars = Integer.Parse(dr("Num_Cars"))

                dL205 = Double.Parse(dr("L205"))

                dL251 = Double.Parse(dr("L251"))
                dL252 = Double.Parse(dr("L252"))

                dL304 = Double.Parse(dr("L304"))
                dL305 = Double.Parse(dr("L305"))
                dL308 = Double.Parse(dr("L308"))
                dL323 = Double.Parse(dr("L323"))
                dL324 = Double.Parse(dr("L324"))

                dL696 = Double.Parse(dr("l696"))
                dL699 = Double.Parse(dr("l699"))

                ReApplyJurisdictionalAddOnCosts(iCarTYpe, iRR_ID)

                If bLegacy Then
                    Dim rUP As System.MidpointRounding = MidpointRounding.AwayFromZero
                    dL700 = Math.Round(dL696 + dL699, rUP)
                    If sShipmentSize = "SC" Then
                        dL700 += Math.Round(dL575, rUP)
                        dL700 += Math.Round(dL578, rUP)
                    End If
                    If sShipmentSize = "SC" Or sShipmentSize = "MC" Then
                        dL700 += Math.Round(dL581, rUP)
                        dL700 += Math.Round(dL584, rUP)
                        dL700 += Math.Round(dL586, rUP)
                    End If
                Else
                    dL700 = dL696 + dL699
                    If sShipmentSize = "SC" Then
                        dL700 += dL575
                        dL700 += dL578
                    End If
                    If sShipmentSize = "SC" Or sShipmentSize = "MC" Then
                        dL700 += dL581
                        dL700 += dL584
                        dL700 += dL586
                    End If
                End If


                'Legacy = dL700 = Round(dL696 + dL69) + Round(each part or 587)

                WriteOutCRPSEG_Row(bLegacy)

                dr.Delete()

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ApplyMakeWholeToCRPSEG-Loop")
            End Try
        Next

        'Write row to error table to announce end of processing
        HandleError("Status", "Ended Apply MakeWhole to CRPSEG Process", "Ended Apply MakeWhole to CRPSEG Process", "Ended Apply MakeWhole to CRPSEG Process")

    End Sub

    ''' <summary>
    ''' ReApplys Jurisdictional Add-On Costs (lines 573 – 587)
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ReApplyJurisdictionalAddOnCosts(ByVal car_type As Integer, ByVal railroad As Integer)

        Try

            'L573
            '============================================================
            Try

                'If sSegmentType = "IR" or If sSegmentType = "IA" Then dL573 = 0
                If sSegmentType = "IA" Then
                    dL573 = dL323 / iNumCars
                ElseIf sSegmentType = "IR" Then
                    dL573 = dL324 / iNumCars
                Else
                    dL573 = dL305
                End If

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-573")
            End Try

            'L574
            '============================================================
            Try

                If sOwnership = "R" Then
                    dL574 = getEcodeValue("E2", "C1", railroad, "301")
                Else
                    dL574 = getEcodeValue("E2", "C2", railroad, "301")
                End If

                'IA IR adjustment
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL574 = getEcodeValue("E2", "C2", railroad, "301")
                End If

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-574")
            End Try

            'L575
            '============================================================
            Try
                dL575 = dL573 * dL574
                If sShipmentSize <> "SC" Then dL575 = 0

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-575")
            End Try

            'L576
            '============================================================
            Try
                'If sSegmentType = "IA" Then
                '    dL576 = dL323
                'ElseIf sSegmentType = "IR" Then
                '    dL576 = dL324
                'Else
                '    dL576 = dL251 + dL252
                'End If

                dL576 = dL305 / dL304

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-576")
            End Try

            'L577
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL577 = getEcodeValue("E2", "C1", railroad, "302")
                Else
                    dL577 = getEcodeValue("E2", "C2", railroad, "302")
                End If

                'IA IR adjustment
                If sSegmentType = "IA" Or sSegmentType = "IR" Then
                    dL577 = getEcodeValue("E2", "C2", railroad, "302")
                End If

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-577")
            End Try

            'L578
            '============================================================
            Try
                dL578 = dL576 * dL577
                If sShipmentSize <> "SC" Then dL578 = 0

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-578")
            End Try

            'L579
            '============================================================
            Try
                dL579 = dL308

                If sSegmentType = "IA" Then dL579 = dL323
                If sSegmentType = "IR" Then dL579 = dL324

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-579")
            End Try

            'L580
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL580 = getEcodeValue("E2", "C1", railroad, "303")
                Else
                    dL580 = getEcodeValue("E2", "C2", railroad, "303")
                End If

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-580")
            End Try

            'L581
            '============================================================
            Try
                dL581 = dL579 * dL580

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-581")
            End Try

            'L582
            '============================================================
            Try
                dL582 = dL205

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-582")
            End Try

            'L583
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL583 = getEcodeValue("E2", "C1", railroad, "304")
                Else
                    dL583 = getEcodeValue("E2", "C2", railroad, "304")
                End If

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-583")
            End Try

            'L584
            '============================================================
            Try
                dL584 = (dL582) * dL583

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-584")
            End Try

            'L585
            '============================================================
            Try
                If sOwnership = "R" Then
                    dL585 = getEcodeValue("E2", "C1", railroad, "305")
                Else
                    dL585 = getEcodeValue("E2", "C2", railroad, "305")
                End If

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-585")
            End Try

            'L586
            '============================================================
            Try
                dL586 = (dL582) * dL585

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-586")
            End Try

            'L587
            '============================================================
            Try
                dL587 = dL575 + dL578 + dL581 + dL584 + dL586

                'If (sSegmentType = "IA" Or sSegmentType = "IR") And sShipmentSize = "OT" Then
                If sSegmentType = "OR" And sShipmentSize = "SC" Then
                    dL587 = dL578 + dL581
                End If
                If sShipmentSize = "TL" Or sShipmentSize = "IM" Then
                    dL587 = 0
                End If

            Catch ex As system.exception
                'write the error out to the sql error table
                HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts-587")
            End Try

        Catch ex As system.exception
            'write the error out to the sql error table
            HandleError(iSerialNum.ToString() & ":" & iSegmentNumber.ToString(), ex.Message.ToString(), ex.StackTrace, "ReApplyJurisdictionalAddOnCosts")
        End Try
    End Sub

    ''' <summary>
    ''' Writes the CRPSEG data back out to SQL
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <remarks></remarks>
    Private Sub WriteOutCRPSEG_Row(ByVal bLeg As Boolean)

        Dim mSQLStr As String

        Try
            If bLeg Then
                Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_LEGACY")
                Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_LEGACY")
            Else
                Global_Variables.gbl_Table_Name = Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG")
                Global_Variables.gbl_Database_Name = Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG")
            End If

            mSQLStr = "UPDATE " & Global_Variables.gbl_Table_Name &
                " SET L573 = " & dL573.ToString & ", " &
                "L574 = " & dL574.ToString & ", " &
                "L575 = " & dL575.ToString & ", " &
                "L576 = " & dL576.ToString & ", " &
                "L577 = " & dL577.ToString & ", " &
                "L578 = " & dL578.ToString & ", " &
                "L579 = " & dL579.ToString & ", " &
                "L580 = " & dL580.ToString & ", " &
                "L581 = " & dL581.ToString & ", " &
                "L582 = " & dL582.ToString & ", " &
                "L583 = " & dL583.ToString & ", " &
                "L584 = " & dL584.ToString & ", " &
                "L585 = " & dL585.ToString & ", " &
                "L586 = " & dL586.ToString & ", " &
                "L587 = " & dL587.ToString & ", " &
                "L700 = " & dL700.ToString & " WHERE " &
                "SerialNum = " & iSerialNum.ToString & " and SegmentNumber = " & iSegmentNumber

            OpenADOConnection(Global_Variables.gbl_Database_Name)

            Global_Variables.gbl_ADOConnection.Execute(mSQLStr)

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

    End Sub

#End Region

#Region "SQL data gathering"

    ''' <summary>
    ''' Clears all rows from the ERROR table about to be re-populated
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub truncateERRORSTable()

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "ERRORS"))
            dsDataSet.Clear()

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "Truncate Table " & Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "ERRORS")

            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)

        End Try

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Sub

    ''' <summary>
    ''' Gets the CRPSEG data from SQL
    ''' </summary>
    ''' <param name="bLeg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getCRPSEG(ByVal bLeg As Boolean) As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try

            dsDataSet.Clear()

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "SELECT SerialNum, SegmentNumber, ShipmentSize, SegmentType, CarType," &
                "[Ownership], RR_ID, RR_Region, Num_Cars, L205, L251, L252, L304, L305, L308, L323, L324, L696, L699 " &
                "FROM "
            If bLeg Then
                OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_LEGACY"))
                cmdCommand.CommandText = cmdCommand.CommandText & Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG_LEGACY")
            Else
                OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG"))
                cmdCommand.CommandText = cmdCommand.CommandText & Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "CRPSEG")
            End If

            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "CRPSEG"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    ''' <summary>
    ''' calls SQL DB and returns datatable of Railroad data
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function fillRailroads() As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try

            OpenSQLConnection(Get_Database_Name_From_SQL("1", "WAYRRR"))
            dsDataSet.Clear()

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "Select DISTINCT * from " & Get_Table_Name_From_SQL("1", "WAYRRR") 'Simple select query for Railroad table
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "RailroadData"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

    ''' <summary>
    ''' calls SQL DB and returns datatable of ecode data
    ''' not to be confused with eTable data, ecode data
    ''' is data specific to the ecode itself
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function fillEcodes() As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "ECODES"))
            dsDataSet.Clear()

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "Select * from " & Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "ECODES") ' simple select query for ecode data
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "EcodeData"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function


    Private Function fillEtable_WithMakeTempMakeWhole() As DataTable

        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "MAKEWHOLE_FACTORS"))
            dsDataSet.Clear()

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "Select * from " & Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "MAKEWHOLE_FACTORS") ' simple select query for ecode data
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

            'Name the dataset Tables
            dsDataSet.Tables(0).TableName = "EcodeData"

        Catch ex As System.Exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        Return dsDataSet.Tables(0)

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Function

#End Region

#Region "Helper functions"

    ''' <summary>
    ''' Uses supplied data to retrive the correct eTable value
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getEcodeValue(ByVal Epart As String, ByVal Code As String,
                                          ByVal Railroad As Integer, ByVal lineA As String) As Double

        'First get the STB RR_ID and Region_ID from the railroad table
        '======================================================================
        Dim rr() = dtRailroads.Select("AARID = " & Railroad.ToString())
        Dim RR_ID As Integer = rr(0)("RR_ID")
        Dim RR_Region As Integer = rr(0)("REGION_ID")

        'If railroad id is 0 then decide if it is east or west.
        'Take the resulting and get the ecode 
        '======================================================================
        Dim ecode As Integer
        Dim ecodeRows As DataRow()
        Dim eTableRows As DataRow()

        ecodeRows = dtEcodes.Select("EPart = '" & Epart & "' AND Code = '" & Code & "' AND LineA = 'L" & lineA & "'")
        ecode = Integer.Parse(ecodeRows(0)("eCode_id"))

        If RR_ID = 0 Then
            If RR_Region = 4 Then
                'call the eastern railroad
                eTableRows = dtEtable.Select("eCode_id = " & ecode & " AND RR_id = 8")
            Else
                'call the western railroad
                eTableRows = dtEtable.Select("eCode_id = " & ecode & " AND RR_id = 9")
            End If

        Else
            eTableRows = dtEtable.Select("eCode_id = " & ecode & " AND RR_id = " & RR_ID.ToString())
        End If

        Return eTableRows(0)("eCode_Value")

    End Function

    ''' <summary>
    ''' Uses supplied data to retrive the correct eTable value
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function getEcodeValue_CarType(ByVal Epart As String, ByVal Code As String,
                                          ByVal Railroad As Integer, ByVal carType As Integer) As Double

        'First get the STB RR_ID and Region_ID from the railroad table
        '======================================================================
        Dim rr() = dtRailroads.Select("AARID = " & Railroad.ToString())
        Dim RR_ID As Integer = rr(0)("RR_ID")
        Dim RR_Region As Integer = rr(0)("REGION_ID")

        'If railroad id is 0 then decide if it is east or west.
        'Take the resulting and get the ecode 
        '======================================================================
        Dim ecode As Integer
        Dim ecodeRows As DataRow()
        Dim eTableRows As DataRow()

        ecodeRows = dtEcodes.Select("EPart = '" & Epart & "' AND Code = '" & Code & "' AND carType_ID = '" & carType & "'")
        ecode = Integer.Parse(ecodeRows(0)("eCode_id"))

        If RR_ID = 0 Then
            If RR_Region = 4 Then
                'call the eastern railroad
                eTableRows = dtEtable.Select("eCode_id = " & ecode & " AND RR_id = 8")
            Else
                'call the western railroad
                eTableRows = dtEtable.Select("eCode_id = " & ecode & " AND RR_id = 9")
            End If

        Else
            eTableRows = dtEtable.Select("eCode_id = " & ecode & " AND RR_id = " & RR_ID.ToString())
        End If

        Return eTableRows(0)("Value")

    End Function

    ''' <summary>
    ''' Handles error traping and writes the message and stack trace back to SQL
    ''' </summary>
    ''' <param name="message"></param>
    ''' <param name="stack"></param>
    ''' <param name="location"></param>
    ''' <remarks></remarks>
    Private Sub HandleError(ByVal data As String, ByVal message As String, ByVal stack As String, ByVal location As String)

        'write the error to SQL
        Dim cmdCommand As SqlCommand
        Dim daAdapter As SqlDataAdapter
        Dim dsDataSet As New DataSet

        Try

            Dim Timestamp = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt")
            message = message.Replace("'", "").Replace("""", "")
            stack = stack.Replace("'", "").Replace("""", "")

            OpenSQLConnection(Get_Database_Name_From_SQL(My.Settings.CurrentYear.ToString, "Errors"))
            dsDataSet.Clear()

            cmdCommand = New SqlClient.SqlCommand
            cmdCommand.CommandType = CommandType.Text
            cmdCommand.CommandText = "INSERT INTO " & Get_Table_Name_From_SQL(My.Settings.CurrentYear.ToString, "ERRORS") &
                " VALUES ('" & data & "','" & Timestamp & "','" & message & "','" & stack & "','" & location & "')"
            cmdCommand.Connection = Global_Variables.gbl_SQLConnection

            'Call the proc and fill the dataset
            daAdapter = New SqlClient.SqlDataAdapter
            daAdapter.SelectCommand = cmdCommand
            daAdapter.Fill(dsDataSet)

        Catch ex As system.exception
            'if we get an error toss it to the web app
            Throw (ex)
        End Try

        'clean up
        cmdCommand.Dispose()
        daAdapter.Dispose()
        dsDataSet.Dispose()

    End Sub

#End Region

End Class
