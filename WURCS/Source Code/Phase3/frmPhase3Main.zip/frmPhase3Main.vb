﻿'**********************************************************************
' Title:        Phase 3 Costing
' Author:       Michael Sanders and Michael Boyles
' Purpose:      Produces the Balance Report to make data integrity checking easier for URCS.
' Revisions:    Initial Creation - Spring 2017
'               Added logic to utilize data choices for either legacy or EP 431 Sub 4 - Jun 14 2017 
' 
' This program is US Government Property - For Official Use Only
'**********************************************************************

Imports SpreadsheetGear
Imports System.Text
Public Class frmPhase3Main

#Region "Form events"

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim mDataTable As DataTable

        'Set the form so it centers on the user's screen
        Me.CenterToScreen()

        ' Load the Year combobox from the SQL database
        mDataTable = Get_URCS_Years_Table()

        For mLooper = 1 To mDataTable.Rows.Count
            cmb_URCS_Year.Items.Add(mDataTable.Rows(mLooper)("urcs_year").ToString)
        Next

        mDataTable = Nothing

        Me.CenterToScreen()

    End Sub


#End Region

    Private Sub btnExecute_Click(sender As Object, e As EventArgs) Handles btnExecute.Click

        Dim rst As ADODB.Recordset
        Dim mStrSQL As String
        Dim mLooper As Integer
        Dim mCounter As Integer
        Dim mTimeStart As Date
        Dim mTimeStops As Date
        Dim mUnitTrainDef As Integer = 0
        Dim mTOFCMove As Boolean = False
        Dim mVal As Object
        Dim m600Procd As Boolean = False

        'Used for testing purposes
        Dim mThreesOnly As Boolean = False
        Dim mTestOne As Boolean = False

        ' Used by SpreadsheetGear
        Dim mWorkbookSet As IWorkbookSet
        Dim mWorkbook As IWorkbook
        Dim mRailroadCostProgramSheet As IWorksheet
        Dim mBatchCostProgramSheet As IWorksheet
        Dim mBatchOutputSheet As IWorksheet
        Dim mDetailedParametersSheet As IWorksheet
        Dim mCellRange As IRange

        ' Local Memvars for the waybill to Spreadsheet data
        Dim mSerial_No As Integer
        Dim mSeg_No As Integer

        ' Variables for Stringbuilders
        Dim sb100Series As StreamWriter
        Dim sb200Series As StreamWriter
        Dim sb300Series As StreamWriter
        Dim sb400Series As StreamWriter
        Dim sb500Series As StreamWriter
        Dim sb600Series As StreamWriter
        Dim sbResults As StreamWriter
        Dim mOutString As StringBuilder

        'Check to make sure that the form has all of the info we need.
        If txtExcelFilePath.Text = "" Then
            MsgBox("No Excel file chosen!", vbOKOnly, "ERROR!")
            GoTo EndIt
        End If

        If txtFolder.Text = "" Then
            MsgBox("No output folder chosen!", vbOKOnly, "ERROR!")
            GoTo EndIt
        End If

        If File.Exists(txtFolder.Text & "\" & cmb_URCS_Year.Text & "*.CSV") Then
            If MsgBox("This will overwrite CSV files in your output directory!  Proceed?", vbYesNo, "WARNING") = vbNo Then
                GoTo EndIt
            End If
        End If

        If (Not rdo_Legacy.Checked) And (Not rdo_EP431Sub4.Checked) Then
            MsgBox("No Costing Method chosen!", vbOKOnly, "ERROR!")
            GoTo EndIt
        End If

        btn_Return_To_MainMenu.Enabled = False
        btnExecute.Enabled = False

        'We need to load the recordset with the Segments table data for the year selected.
        gbl_Database_Name = Get_Database_Name_From_SQL(cmb_URCS_Year.Text, "SEGMENTS")
        Gbl_Segments_TableName = Get_Table_Name_From_SQL(cmb_URCS_Year.Text, "SEGMENTS")
        Gbl_Masked_TableName = Get_Table_Name_From_SQL(cmb_URCS_Year.Text, "MASKED")
        OpenADOConnection(gbl_Database_Name)

        txtStatus.Text = "Getting Segments Data from SQL..."
        Refresh()

        rst = SetRST()
        mStrSQL = "SELECT " & Gbl_Segments_TableName & ".Serial_No, " &
            Gbl_Segments_TableName & ".Seg_no, " &
            Gbl_Segments_TableName & ".RR_Num, " &
            Gbl_Segments_TableName & ".rr_Alpha, " &
            Gbl_Segments_TableName & ".RR_Dist, " &
            Gbl_Segments_TableName & ".Seg_Type, " &
            Gbl_Masked_TableName & ".TOFC_Serv_Code, " &
            Gbl_Masked_TableName & ".STB_Car_Typ, " &
            Gbl_Masked_TableName & ".U_Cars, " &
            Gbl_Masked_TableName & ".U_TC_Units, " &
            Gbl_Masked_TableName & ".Car_Own, " &
            Gbl_Masked_TableName & ".U_Car_Init, " &
            Gbl_Masked_TableName & ".Bill_Wght_Tons, " &
            Gbl_Masked_TableName & ".STCC, " &
            Gbl_Masked_TableName & ".Int_Eq_Flg, " &
            Gbl_Masked_TableName & ".ORR, " &
            Gbl_Masked_TableName & ".Total_Dist FROM " & Gbl_Segments_TableName &
            " INNER JOIN " & Gbl_Masked_TableName & " ON " &
            Gbl_Segments_TableName & ".Serial_No = " & Gbl_Masked_TableName & ".Serial_No "

        If mThreesOnly = True Then
            'mStrSQL = mStrSQL & " where (right(" & Gbl_Masked_TableName & ".serial_no,1) = 3) AND " & Gbl_Masked_TableName & ".serial_no < 250000)"
            mStrSQL = mStrSQL & " where right(" & Gbl_Masked_TableName & ".serial_no,1) = 3"
        End If

        rst.Open(mStrSQL, gbl_ADOConnection)

        If rst.RecordCount = 0 Then
            MsgBox("No records found in Segments table!", vbOKOnly, "ERROR!")
            GoTo EndIt
        End If

        txtStatus.Text = "Initializing Spreadsheet..."
        Refresh()
        Application.DoEvents()

        'Now that we have the segment data, open the workbook.
        mWorkbookSet = Factory.GetWorkbookSet(System.Globalization.CultureInfo.CurrentCulture)
        mWorkbookSet.Calculation = Calculation.Manual
        mWorkbook = mWorkbookSet.Workbooks.Open(txtExcelFilePath.Text)

        'Set up the worksheets for use
        mRailroadCostProgramSheet = mWorkbook.Worksheets("RailroadCostProgram")
        mBatchCostProgramSheet = mWorkbook.Worksheets("BatchCostProgram")
        mBatchOutputSheet = mWorkbook.Worksheets("BatchOutput")
        mDetailedParametersSheet = mWorkbook.Worksheets("DetailedParameters")

        ' Clear out the BatchInput sheet rows that we don't need or use
        mCellRange = mBatchCostProgramSheet.Cells(4, 0, mBatchCostProgramSheet.UsedRange.RowCount, mBatchCostProgramSheet.UsedRange.ColumnCount)
        mCellRange.Clear()

        ' Do the same for the BatchOutput sheet
        mCellRange = mBatchOutputSheet.Cells(4, 0, mBatchOutputSheet.UsedRange.RowCount, mBatchOutputSheet.UsedRange.ColumnCount)
        mCellRange.Clear()

        If InStr(mRailroadCostProgramSheet.Cells("D77").Formula, "AdjustLUMs") > 0 Then
            ' Process with multicar shipment size at 75 cars
            mUnitTrainDef = 75
        Else
            ' Process with multicar shipment size at 50 cars
            mUnitTrainDef = 50
        End If

        mTimeStart = Now
        mCounter = 0

        ' Check to see what, if any, csv files are requested via checkboxes on the form
        sb100Series = Nothing
        If chk100Series.Checked Then
            If mUnitTrainDef = 50 Then
                sb100Series = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_100Series.CSV", False)
            Else
                sb100Series = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_100Series_EP431Sub4.CSV", False)
            End If
            mOutString = New StringBuilder
            mOutString.Append("Serial_no,Seg_no")
            sb100Series.Write(mOutString.ToString)
        End If

        sb200Series = Nothing
        If chk200Series.Checked Then
            If mUnitTrainDef = 50 Then
                sb200Series = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_200Series.CSV", False)
            Else
                sb200Series = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_200Series_EP431Sub4.CSV", False)
            End If
            mOutString = New StringBuilder
            mOutString.Append("Serial_no,Seg_no")
            sb200Series.Write(mOutString.ToString)
        End If

        sb300Series = Nothing
        If chk300Series.Checked Then
            If mUnitTrainDef = 50 Then
                sb300Series = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_300Series.CSV", False)
            Else
                sb300Series = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_300Series_EP431Sub4.CSV", False)
            End If
            mOutString = New StringBuilder
            mOutString.Append("Serial_no,Seg_no")
            sb300Series.Write(mOutString.ToString)
        End If

        sb400Series = Nothing
        If chk400Series.Checked Then
            If mUnitTrainDef = 50 Then
                sb400Series = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_400Series.CSV", False)
            Else
                sb400Series = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_400Series_EP431Sub4.CSV", False)
            End If
            mOutString = New StringBuilder
            mOutString.Append("Serial_no,Seg_no")
            sb400Series.Write(mOutString.ToString)
        End If

        sb500Series = Nothing
        If chk500Series.Checked Then
            If mUnitTrainDef = 50 Then
                sb500Series = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_500Series.CSV", False)
            Else
                sb500Series = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_500Series_EP431Sub4.CSV", False)
            End If
            mOutString = New StringBuilder
            mOutString.Append("Serial_no,Seg_no")
            sb500Series.Write(mOutString.ToString)
        End If

        sb600Series = Nothing
        If chk600Series.Checked Then
            If mUnitTrainDef = 50 Then
                sb600Series = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_600Series.CSV", False)
            Else
                sb600Series = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_600Series_EP431Sub4.CSV", False)
            End If
            mOutString = New StringBuilder
            mOutString.Append("Serial_no,Seg_no")
            sb600Series.Write(mOutString.ToString)
        End If

        'We always create a Results file
        sbResults = Nothing
        If mUnitTrainDef = 50 Then
            sbResults = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_Results.CSV", False)
        Else
            sbResults = New StreamWriter(txtFolder.Text & "\" & cmb_URCS_Year.Text & "_Results_EP431Sub4.CSV", False)
        End If
        mOutString = New StringBuilder
        mOutString.Append("Serial_no,Seg_no")
        sbResults.Write(mOutString.ToString)

        mCellRange = mBatchOutputSheet.Cells

        ' Results File
        mOutString = New StringBuilder
        For Each cell As IRange In mCellRange("B4:J4")
            mVal = cell.Value
            mOutString.Append("," & mVal.ToString)
        Next cell
        ' Get the header for L700
        mOutString.Append("," & mCellRange("PN4").Value)
        sbResults.WriteLine(mOutString.ToString)

        ' Write the values to each file 
        m600Procd = False
        mCellRange = mBatchOutputSheet.Cells

        'Now write the remainder of the results to the respective output files
        For Each cell As IRange In mCellRange("K4:RA4")
            mVal = cell.Value
            If mVal <> "" Then
                mOutString = New StringBuilder
                mOutString.Append("," & mVal.ToString)
                If m600Procd = True Then
                    sb600Series.Write(mOutString.ToString)
                Else
                    Select Case Mid(mVal.ToString, 1, 2)
                        Case "L1"
                            sb100Series.Write(mOutString.ToString)
                        Case "L2"
                            sb200Series.Write(mOutString.ToString)
                        Case "L3"
                            sb300Series.Write(mOutString.ToString)
                        Case "L4"
                            sb400Series.Write(mOutString.ToString)
                        Case "L5"
                            sb500Series.Write(mOutString.ToString)
                        Case "L6", "L7"
                            m600Procd = True
                            sb600Series.Write(mOutString.ToString)
                    End Select
                End If
            End If
        Next

        'finalize the headers
        sb100Series.WriteLine("")
        sb200Series.WriteLine("")
        sb300Series.WriteLine("")
        sb400Series.WriteLine("")
        sb500Series.WriteLine("")
        sb600Series.WriteLine("")

        txtStatus.Text = "Processing..."
        Refresh()
        Application.DoEvents()

        ' Start looping thru the recordset
        rst.MoveFirst()
        Do While Not rst.EOF
            mCounter = mCounter + 1
            If mCounter Mod 100 = 0 Then
                txtStatus.Text = "Processing record " & mCounter.ToString & " of " _
                    & rst.RecordCount.ToString & "..."
                Refresh()
                Application.DoEvents()
            End If

            'Clean up any old data

            mCellRange = mRailroadCostProgramSheet.Cells("D6:D15")
            mCellRange.Value = ""
            mCellRange = mRailroadCostProgramSheet.Cells("E6:H7")
            mCellRange.Value = ""

            mCellRange = mDetailedParametersSheet.Cells("C4:G7")
            mCellRange.Value = ""
            mDetailedParametersSheet.Cells("C13").Value = ""

            'Start laying in the values to line 5 base zero of the spreadsheet
            mSerial_No = rst.Fields("Serial_no").Value
            mSeg_No = rst.Fields("Seg_no").Value

            ' Input Parameter: ID
            ' mBatchCostProgramSheet.Cells("A5").Value = 1  'Since we're doing one at a time, not really needed
            mBatchCostProgramSheet.Cells("A5").Value = rst.Fields("Serial_No").Value + (0.1 * rst.Fields("Seg_No").Value)

            ' Input Parameter: RR
            ' mBatchCostProgramSheet.Cells("B5").Value = Trim(rst.Fields("RR_Alpha").Value)
            mBatchCostProgramSheet.Cells("B5").Value = rst.Fields("RR_Num").Value

            ' Input Parameter: DIS
            mBatchCostProgramSheet.Cells("C5").Value = rst.Fields("RR_Dist").Value * 0.1

            ' Input Parameter: SG
            mBatchCostProgramSheet.Cells("D5").Value = rst.Fields("Seg_Type").Value

            ' Input Parameter: FC
            If rdo_Legacy.Checked = True Then
                ' Logic if running as Legacy 
                mTOFCMove = False
                Select Case rst.Fields("STB_Car_Typ").Value
                    Case 46, 49, 52, 54
                        If (rst.Fields("TOFC_Serv_Code").Value <> "") Or (rst.Fields("Int_Eq_Flg").Value = 2) Then
                            mTOFCMove = True
                            mBatchCostProgramSheet.Cells("E5").Value = 46
                        Else
                            mBatchCostProgramSheet.Cells("E5").Value = rst.Fields("STB_Car_typ").Value
                        End If
                    Case Else
                        mBatchCostProgramSheet.Cells("E5").Value = rst.Fields("STB_Car_typ").Value
                End Select
            Else
                ' Check to see if we have a value for the Car Type.  If not, use default
                If String.IsNullOrEmpty(rst.Fields("STB_Car_typ").Value) Then
                    mBatchCostProgramSheet.Cells("E5").Value = 52
                Else
                    mBatchCostProgramSheet.Cells("E5").Value = rst.Fields("STB_Car_typ").Value
                End If

                mTOFCMove = False
                Select Case rst.Fields("STB_Car_Typ").Value
                    Case 46, 48, 49, 52, 54
                        If (rst.Fields("TOFC_Serv_Code").Value <> "") Or (rst.Fields("Int_Eq_Flg").Value = 2) Then
                            mTOFCMove = True
                        End If
                End Select

            End If

            ' Input Parameter: NC
            'Check for the larger of U_Cars or U_TC_Units
            If rst.Fields("U_Cars").Value > rst.Fields("U_TC_Units").Value Then
                mBatchCostProgramSheet.Cells("F5").Value = rst.Fields("U_Cars").Value
            Else
                mBatchCostProgramSheet.Cells("F5").Value = rst.Fields("U_TC_Units").Value
            End If

            ' Input Parameter: OWN
            If rdo_Legacy.Checked = True Then
                ' Logic if running as Legacy
                Select Case Trim(rst.Fields("U_Car_init").Value)
                    Case "ABOX", "RBOX", "CSX", "CSXT", "GONX"
                        mBatchCostProgramSheet.Cells("G5").Value = "R"
                    Case Else
                        If Strings.Right(Trim(rst.Fields("U_Car_Init").Value), 1) = "X" Then
                            mBatchCostProgramSheet.Cells("G5").Value = "P"
                        Else
                            mBatchCostProgramSheet.Cells("G5").Value = "R"
                        End If
                End Select
            Else
                ' Use value in Car_Own field unless that is blank
                Select Case Trim(rst.Fields("Car_Own").Value)
                    Case "R", "P", "T"
                        mBatchCostProgramSheet.Cells("G5").Value = rst.Fields("Car_Own").Value
                    Case Else
                        If Strings.Right(Trim(rst.Fields("U_Car_Init").Value), 1) = "X" Then
                            mBatchCostProgramSheet.Cells("G5").Value = "P"
                        Else
                            mBatchCostProgramSheet.Cells("G5").Value = "R"
                        End If
                End Select

            End If

            ' Input Parameter: WT
            'Calculate the tons per car or tons per TCU value
            If mTOFCMove Then
                If rst.Fields("U_TC_Units").Value > 0 Then
                    mBatchCostProgramSheet.Cells("H5").Value = rst.Fields("Bill_Wght_Tons").Value / rst.Fields("U_TC_Units").Value
                Else
                    mBatchCostProgramSheet.Cells("H5").Value = 0
                End If
            Else
                If rst.Fields("U_Cars").Value > 0 Then
                    mBatchCostProgramSheet.Cells("H5").Value = rst.Fields("Bill_Wght_Tons").Value / rst.Fields("U_Cars").Value
                Else
                    mBatchCostProgramSheet.Cells("H5").Value = 0
                End If
            End If

            ' Input Parameter: COM
            mBatchCostProgramSheet.Cells("I5").Value = "'" & Strings.Left(rst.Fields("STCC").Value, 5)

            ' Input Parameter: SZ (Set the shipment size - legacy v. EP431 Sub 4)
            If mTOFCMove = True Then
                mBatchCostProgramSheet.Cells("J5").Value = "Intermodal"
            ElseIf rst.Fields("U_Cars").Value <= 5 Then
                mBatchCostProgramSheet.Cells("J5").Value = "Single"
            ElseIf rst.Fields("U_Cars").Value < mUnitTrainDef Then
                mBatchCostProgramSheet.Cells("J5").Value = "Multi"
            Else
                mBatchCostProgramSheet.Cells("J5").Value = "Unit"
            End If

            ' Input Parameter: L102 (Set the Circuity to 1)
            mBatchCostProgramSheet.Cells("K5").Value = 1

            ' Input Parameter: L569
            If rst.Fields("Int_Eq_Flg").Value = 2 Then
                mBatchCostProgramSheet.Cells("L5").Value = "TCS"
            Else
                mBatchCostProgramSheet.Cells("L5").Value = Trim(rst.Fields("TOFC_Serv_Code").Value)
            End If

            ' Input Parameter: TDIS
            mBatchCostProgramSheet.Cells("M5").Value = rst.Fields("Total_Dist").Value * 0.1

            ' Input Parameter: ORR
            mBatchCostProgramSheet.Cells("N5").Value = rst.Fields("ORR").Value

            ' Copy the formulas for P5:AC5
            With mBatchCostProgramSheet
                mCellRange = .Cells
                mCellRange("P1:AC1").Copy(.Cells("P5:AC5"))
            End With

            mWorkbook.WorkbookSet.Calculate()

            ' Copy the Q5:Y5 values to the RailroadCostProgramSheet
            'For mLooper = 6 To 14
            '    mRailroadCostProgramSheet.Cells("D" & mLooper.ToString).Value =
            '        mBatchCostProgramSheet.Cells(4, (mLooper + 10)).Value
            'Next

            mRailroadCostProgramSheet.Cells("D6").Value = mBatchCostProgramSheet.Cells("Q5").Value          'RR
            mRailroadCostProgramSheet.Cells("D7").Value = mBatchCostProgramSheet.Cells("R5").Value          'DIS
            mRailroadCostProgramSheet.Cells("D8").Value = mBatchCostProgramSheet.Cells("S5").Value          'SG
            mRailroadCostProgramSheet.Cells("D9").Value = mBatchCostProgramSheet.Cells("T5").Value          'FC
            mRailroadCostProgramSheet.Cells("D10").Value = mBatchCostProgramSheet.Cells("U5").Value         'NC
            mRailroadCostProgramSheet.Cells("D11").Value = mBatchCostProgramSheet.Cells("V5").Value         'OWN
            mRailroadCostProgramSheet.Cells("D12").Value = mBatchCostProgramSheet.Cells("W5").Value         'WT
            mRailroadCostProgramSheet.Cells("D13").Value = Replace(mBatchCostProgramSheet.Cells("X5").Value, "'", ";")         'COM
            mRailroadCostProgramSheet.Cells("D14").Value = mBatchCostProgramSheet.Cells("Y5").Value         'SZ

            ' Copy the OtherRRDist (if any) from the BatchCostProgram sheet to the RailroadCostProgram sheet
            mRailroadCostProgramSheet.Cells("H7").Value = mBatchCostProgramSheet.Cells("Z5").Value

            ' Copy the Circuity (if any) from the BatchCostProgram sheet to the DetailedParameters sheet
            mDetailedParametersSheet.Cells("C4").Value = mBatchCostProgramSheet.Cells("AA5").Value

            ' Copy the TOFC Plan (if any) from the BatchCostProgram sheet to the DetailedParameters sheet
            ' mDetailedParametersSheet.Cells("C13").Value = mBatchCostProgramSheet.Cells("L5").Value
            mDetailedParametersSheet.Cells("C13").Value = mBatchCostProgramSheet.Cells("AB5").Value

            ' Copy the ORR (if any) from the BatchCostProgram sheet to the DetailedParameters sheet
            ' mDetailedParametersSheet.Cells("J10").Value = mBatchCostProgramSheet.Cells("N5").Value
            mDetailedParametersSheet.Cells("J10").Value = mBatchCostProgramSheet.Cells("AC5").Value

            mWorkbook.WorkbookSet.Calculate()

            ' Extract the calculated values and save them to CSV files

            If chk100Series.Checked = True Then
                mOutString = New StringBuilder
                mOutString.Append(rst.Fields("Serial_no").Value & ",")
                mOutString.Append(rst.Fields("Seg_no").Value)
                sb100Series.Write(mOutString.ToString)
            End If

            mOutString = New StringBuilder
            mOutString.Append(rst.Fields("Serial_no").Value & ",")
            mOutString.Append(rst.Fields("Seg_no").Value)

            If chk200Series.Checked Then
                sb200Series.Write(mOutString.ToString)
            End If

            If chk300Series.Checked Then
                sb300Series.Write(mOutString.ToString)
            End If

            If chk400Series.Checked Then
                sb400Series.Write(mOutString.ToString)
            End If

            If chk500Series.Checked Then
                sb500Series.Write(mOutString.ToString)
            End If

            If chk600Series.Checked Then
                sb600Series.Write(mOutString.ToString)
            End If

            mCellRange = mBatchCostProgramSheet.Cells

            ' Always write the results out
            For Each cell As IRange In mCellRange("Q5:Y5")
                mVal = cell.Value
                mOutString.Append("," & mVal.ToString)
            Next cell

            ' Switch to the Batch Output sheet
            mCellRange = mBatchOutputSheet.Cells
            m600Procd = False

            ' Get the header for L700 for the results file
            mOutString.Append("," & mCellRange("PN1").Value)
            sbResults.WriteLine(mOutString.ToString)

            ' Load the data from the Batch Output sheet into the respective output files
            For mLooper = 10 To 1000
                mOutString = New StringBuilder
                ' Get the value from row 1 (this is zero based)
                If IsNothing(mBatchOutputSheet.Cells(0, mLooper).Value) = False Then
                    mOutString.Append("," & mBatchOutputSheet.Cells(0, mLooper).Value.ToString)
                    If m600Procd = True Then
                        sb600Series.Write(mOutString.ToString)
                    Else
                        Select Case Mid(mBatchOutputSheet.Cells(3, mLooper).Value, 1, 2)
                            Case "L1"
                                sb100Series.Write(mOutString.ToString)
                            Case "L2"
                                sb200Series.Write(mOutString.ToString)
                            Case "L3"
                                sb300Series.Write(mOutString.ToString)
                            Case "L4"
                                sb400Series.Write(mOutString.ToString)
                            Case "L5"
                                sb500Series.Write(mOutString.ToString)
                            Case "L6", "L7"
                                m600Procd = True
                                sb600Series.Write(mOutString.ToString)
                        End Select
                    End If

                End If
            Next

            'finalize the data
            sb100Series.WriteLine("")
            sb200Series.WriteLine("")
            sb300Series.WriteLine("")
            sb400Series.WriteLine("")
            sb500Series.WriteLine("")
            sb600Series.WriteLine("")


            If mTestOne = True Then
                Exit Do
            End If

            rst.MoveNext()
        Loop

        mWorkbook.Save()

        'Housekeeping
        rst.Close()
        rst = Nothing

        'close the CSV files if they were created.
        If chk100Series.Checked Then
            sb100Series.Close()
        End If

        If chk200Series.Checked Then
            sb200Series.Close()
        End If

        If chk300Series.Checked Then
            sb300Series.Close()
        End If

        If chk400Series.Checked Then
            sb400Series.Close()
        End If

        If chk500Series.Checked Then
            sb500Series.Close()
        End If

        If chk600Series.Checked Then
            sb600Series.Close()
        End If

        sbResults.Close()

EndIt:
        mTimeStops = Now
        txtStatus.Text = "Done! - Elapsed time: " & mTimeStops.Subtract(mTimeStart).ToString("hh\:mm\:ss")

        btn_Return_To_MainMenu.Enabled = True
        btnExecute.Enabled = True

        Refresh()

    End Sub

    Private Sub btn_Return_To_MainMenu_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btn_Return_To_MainMenu.Click
        ' Open the Main Menu Form
        Dim frmNew As New frm_MainMenu()
        frmNew.Show()
        ' Close this Menu
        Me.Close()
    End Sub

    Private Sub btnSelectExcelFile_Click(sender As Object, e As EventArgs) Handles btnSelectExcelFile.Click
        Dim fd As New OpenFileDialog

        fd.Multiselect = False
        fd.CheckFileExists = True
        fd.Filter = "Excel Files|*.xlsx;*.xls;*.xlsm|All Files|*.*"

        If fd.ShowDialog() = DialogResult.OK Then
            txtExcelFilePath.Text = fd.FileName
        End If
    End Sub

    Private Sub btnSelectOutputFolder_Click(sender As Object, e As EventArgs) Handles btnSelectOutputFolder.Click
        Dim oFolderBrowserDialog As FolderBrowserDialog

        oFolderBrowserDialog = New FolderBrowserDialog
        oFolderBrowserDialog.ShowDialog()

        If oFolderBrowserDialog.SelectedPath.Length > 0 Then
            txtFolder.Text = oFolderBrowserDialog.SelectedPath
        End If
    End Sub

End Class
