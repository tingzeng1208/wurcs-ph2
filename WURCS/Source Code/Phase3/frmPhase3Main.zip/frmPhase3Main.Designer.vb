﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPhase3Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_Return_To_MainMenu = New System.Windows.Forms.Button()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.btnSelectOutputFolder = New System.Windows.Forms.Button()
        Me.txtFolder = New System.Windows.Forms.TextBox()
        Me.cmb_URCS_Year = New System.Windows.Forms.ComboBox()
        Me.txtExcelFilePath = New System.Windows.Forms.TextBox()
        Me.btnSelectExcelFile = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.chk100Series = New System.Windows.Forms.CheckBox()
        Me.chk200Series = New System.Windows.Forms.CheckBox()
        Me.chk300Series = New System.Windows.Forms.CheckBox()
        Me.chk400Series = New System.Windows.Forms.CheckBox()
        Me.chk500Series = New System.Windows.Forms.CheckBox()
        Me.btnExecute = New System.Windows.Forms.Button()
        Me.txtStatus = New System.Windows.Forms.TextBox()
        Me.chk600Series = New System.Windows.Forms.CheckBox()
        Me.rdo_Legacy = New System.Windows.Forms.RadioButton()
        Me.rdo_EP431Sub4 = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.chk_Save_CRPRES = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btn_Return_To_MainMenu
        '
        Me.btn_Return_To_MainMenu.Image = Global.WURCS.My.Resources.Resources.ExitDoor
        Me.btn_Return_To_MainMenu.Location = New System.Drawing.Point(608, 393)
        Me.btn_Return_To_MainMenu.Name = "btn_Return_To_MainMenu"
        Me.btn_Return_To_MainMenu.Size = New System.Drawing.Size(51, 52)
        Me.btn_Return_To_MainMenu.TabIndex = 14
        Me.btn_Return_To_MainMenu.UseVisualStyleBackColor = True
        '
        'lblYear
        '
        Me.lblYear.AutoSize = True
        Me.lblYear.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblYear.Location = New System.Drawing.Point(40, 64)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(61, 13)
        Me.lblYear.TabIndex = 0
        Me.lblYear.Text = "Select year"
        '
        'btnSelectOutputFolder
        '
        Me.btnSelectOutputFolder.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSelectOutputFolder.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSelectOutputFolder.Location = New System.Drawing.Point(38, 157)
        Me.btnSelectOutputFolder.Name = "btnSelectOutputFolder"
        Me.btnSelectOutputFolder.Size = New System.Drawing.Size(129, 23)
        Me.btnSelectOutputFolder.TabIndex = 4
        Me.btnSelectOutputFolder.Text = "Select Output Folder:"
        Me.btnSelectOutputFolder.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSelectOutputFolder.UseVisualStyleBackColor = True
        '
        'txtFolder
        '
        Me.txtFolder.Location = New System.Drawing.Point(242, 157)
        Me.txtFolder.Name = "txtFolder"
        Me.txtFolder.ReadOnly = True
        Me.txtFolder.Size = New System.Drawing.Size(394, 21)
        Me.txtFolder.TabIndex = 5
        Me.txtFolder.TabStop = False
        '
        'cmb_URCS_Year
        '
        Me.cmb_URCS_Year.Location = New System.Drawing.Point(107, 61)
        Me.cmb_URCS_Year.MaxLength = 4
        Me.cmb_URCS_Year.Name = "cmb_URCS_Year"
        Me.cmb_URCS_Year.Size = New System.Drawing.Size(60, 21)
        Me.cmb_URCS_Year.TabIndex = 1
        '
        'txtExcelFilePath
        '
        Me.txtExcelFilePath.Location = New System.Drawing.Point(242, 99)
        Me.txtExcelFilePath.Name = "txtExcelFilePath"
        Me.txtExcelFilePath.ReadOnly = True
        Me.txtExcelFilePath.Size = New System.Drawing.Size(403, 21)
        Me.txtExcelFilePath.TabIndex = 3
        Me.txtExcelFilePath.TabStop = False
        '
        'btnSelectExcelFile
        '
        Me.btnSelectExcelFile.Location = New System.Drawing.Point(38, 97)
        Me.btnSelectExcelFile.Name = "btnSelectExcelFile"
        Me.btnSelectExcelFile.Size = New System.Drawing.Size(198, 23)
        Me.btnSelectExcelFile.TabIndex = 2
        Me.btnSelectExcelFile.Text = "Select Phase III Spreadsheet File:"
        Me.btnSelectExcelFile.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSelectExcelFile.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 14.25!)
        Me.Label1.Location = New System.Drawing.Point(245, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(180, 46)
        Me.Label1.TabIndex = 50
        Me.Label1.Text = "URCS && Waybills" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Phase III Costing Module"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'chk100Series
        '
        Me.chk100Series.AutoSize = True
        Me.chk100Series.Location = New System.Drawing.Point(38, 184)
        Me.chk100Series.Name = "chk100Series"
        Me.chk100Series.Size = New System.Drawing.Size(146, 17)
        Me.chk100Series.TabIndex = 6
        Me.chk100Series.Text = "Save 100 Series Columns"
        Me.chk100Series.UseVisualStyleBackColor = True
        '
        'chk200Series
        '
        Me.chk200Series.AutoSize = True
        Me.chk200Series.Location = New System.Drawing.Point(38, 207)
        Me.chk200Series.Name = "chk200Series"
        Me.chk200Series.Size = New System.Drawing.Size(146, 17)
        Me.chk200Series.TabIndex = 7
        Me.chk200Series.Text = "Save 200 Series Columns"
        Me.chk200Series.UseVisualStyleBackColor = True
        '
        'chk300Series
        '
        Me.chk300Series.AutoSize = True
        Me.chk300Series.Location = New System.Drawing.Point(38, 230)
        Me.chk300Series.Name = "chk300Series"
        Me.chk300Series.Size = New System.Drawing.Size(146, 17)
        Me.chk300Series.TabIndex = 8
        Me.chk300Series.Text = "Save 300 Series Columns"
        Me.chk300Series.UseVisualStyleBackColor = True
        '
        'chk400Series
        '
        Me.chk400Series.AutoSize = True
        Me.chk400Series.Location = New System.Drawing.Point(38, 253)
        Me.chk400Series.Name = "chk400Series"
        Me.chk400Series.Size = New System.Drawing.Size(146, 17)
        Me.chk400Series.TabIndex = 9
        Me.chk400Series.Text = "Save 400 Series Columns"
        Me.chk400Series.UseVisualStyleBackColor = True
        '
        'chk500Series
        '
        Me.chk500Series.AutoSize = True
        Me.chk500Series.Location = New System.Drawing.Point(38, 277)
        Me.chk500Series.Name = "chk500Series"
        Me.chk500Series.Size = New System.Drawing.Size(146, 17)
        Me.chk500Series.TabIndex = 10
        Me.chk500Series.Text = "Save 500 Series Columns"
        Me.chk500Series.UseVisualStyleBackColor = True
        '
        'btnExecute
        '
        Me.btnExecute.Location = New System.Drawing.Point(275, 382)
        Me.btnExecute.Name = "btnExecute"
        Me.btnExecute.Size = New System.Drawing.Size(117, 29)
        Me.btnExecute.TabIndex = 13
        Me.btnExecute.Text = "Execute"
        Me.btnExecute.UseVisualStyleBackColor = True
        '
        'txtStatus
        '
        Me.txtStatus.BackColor = System.Drawing.SystemColors.Control
        Me.txtStatus.Location = New System.Drawing.Point(72, 355)
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.Size = New System.Drawing.Size(527, 21)
        Me.txtStatus.TabIndex = 52
        Me.txtStatus.TabStop = False
        '
        'chk600Series
        '
        Me.chk600Series.AutoSize = True
        Me.chk600Series.Location = New System.Drawing.Point(38, 300)
        Me.chk600Series.Name = "chk600Series"
        Me.chk600Series.Size = New System.Drawing.Size(146, 17)
        Me.chk600Series.TabIndex = 11
        Me.chk600Series.Text = "Save 600 Series Columns"
        Me.chk600Series.UseVisualStyleBackColor = True
        '
        'rdo_Legacy
        '
        Me.rdo_Legacy.AutoSize = True
        Me.rdo_Legacy.Location = New System.Drawing.Point(6, 20)
        Me.rdo_Legacy.Name = "rdo_Legacy"
        Me.rdo_Legacy.Size = New System.Drawing.Size(59, 17)
        Me.rdo_Legacy.TabIndex = 0
        Me.rdo_Legacy.TabStop = True
        Me.rdo_Legacy.Text = "Legacy"
        Me.rdo_Legacy.UseVisualStyleBackColor = True
        '
        'rdo_EP431Sub4
        '
        Me.rdo_EP431Sub4.AutoSize = True
        Me.rdo_EP431Sub4.Location = New System.Drawing.Point(6, 38)
        Me.rdo_EP431Sub4.Name = "rdo_EP431Sub4"
        Me.rdo_EP431Sub4.Size = New System.Drawing.Size(85, 17)
        Me.rdo_EP431Sub4.TabIndex = 1
        Me.rdo_EP431Sub4.TabStop = True
        Me.rdo_EP431Sub4.Text = "EP431 Sub 4"
        Me.rdo_EP431Sub4.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdo_Legacy)
        Me.GroupBox1.Controls.Add(Me.rdo_EP431Sub4)
        Me.GroupBox1.Location = New System.Drawing.Point(242, 190)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(97, 57)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Cost As"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(38, 128)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(198, 23)
        Me.Button1.TabIndex = 53
        Me.Button1.Text = "Select Make Whole Spreadsheet File:"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(242, 128)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(403, 21)
        Me.TextBox1.TabIndex = 54
        Me.TextBox1.TabStop = False
        '
        'chk_Save_CRPRES
        '
        Me.chk_Save_CRPRES.AutoSize = True
        Me.chk_Save_CRPRES.Location = New System.Drawing.Point(38, 323)
        Me.chk_Save_CRPRES.Name = "chk_Save_CRPRES"
        Me.chk_Save_CRPRES.Size = New System.Drawing.Size(118, 17)
        Me.chk_Save_CRPRES.TabIndex = 55
        Me.chk_Save_CRPRES.Text = "Save CRPRES Data"
        Me.chk_Save_CRPRES.UseVisualStyleBackColor = True
        '
        'frmPhase3Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(671, 457)
        Me.Controls.Add(Me.chk_Save_CRPRES)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.chk600Series)
        Me.Controls.Add(Me.txtStatus)
        Me.Controls.Add(Me.btnExecute)
        Me.Controls.Add(Me.chk500Series)
        Me.Controls.Add(Me.chk400Series)
        Me.Controls.Add(Me.chk300Series)
        Me.Controls.Add(Me.chk200Series)
        Me.Controls.Add(Me.chk100Series)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnSelectExcelFile)
        Me.Controls.Add(Me.txtExcelFilePath)
        Me.Controls.Add(Me.txtFolder)
        Me.Controls.Add(Me.cmb_URCS_Year)
        Me.Controls.Add(Me.btnSelectOutputFolder)
        Me.Controls.Add(Me.btn_Return_To_MainMenu)
        Me.Controls.Add(Me.lblYear)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmPhase3Main"
        Me.Text = "URCS Phase III - Waybill Costing"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn_Return_To_MainMenu As System.Windows.Forms.Button
    Friend WithEvents lblYear As Label
    Friend WithEvents btnSelectOutputFolder As Button
    Friend WithEvents txtFolder As TextBox
    Friend WithEvents cmb_URCS_Year As ComboBox
    Friend WithEvents txtExcelFilePath As TextBox
    Friend WithEvents btnSelectExcelFile As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents chk100Series As CheckBox
    Friend WithEvents chk200Series As CheckBox
    Friend WithEvents chk300Series As CheckBox
    Friend WithEvents chk400Series As CheckBox
    Friend WithEvents chk500Series As CheckBox
    Friend WithEvents btnExecute As Button
    Friend WithEvents txtStatus As TextBox
    Friend WithEvents chk600Series As System.Windows.Forms.CheckBox
    Friend WithEvents rdo_Legacy As RadioButton
    Friend WithEvents rdo_EP431Sub4 As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents chk_Save_CRPRES As CheckBox
End Class
