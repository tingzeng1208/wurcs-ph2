﻿Public Class Segments_Table_Builder

    Private Sub Segments_Table_Builder_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim mDataTable As DataTable

        'Set the form so it centers on the user's screen
        CenterToScreen()

        ' Load the Year combobox from the SQL database
        mDataTable = Get_Waybill_Years_Table()

        For mLooper = 0 To mDataTable.Rows.Count - 1
            cmb_URCS_Year.Items.Add(mDataTable.Rows(mLooper)("wb_year").ToString)
        Next

        mDataTable = Nothing

    End Sub

    Private Sub btn_Return_To_DataPrepMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Return_To_DataPrepMenu.Click
        ' Open the Data Prep Menu Form
        Dim frmNew As New frm_URCS_Waybill_Data_Prep()
        frmNew.Show()
        ' Close this Form
        Close()
    End Sub

    Private Sub btn_Execute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Execute.Click

        Dim rst As ADODB.Recordset
        Dim mStrSQL As String, mStrOutSQL As String
        Dim mBolWrite As Boolean, mIntermodal As Boolean
        Dim mSglMaxRecs As Single, mThisRec As Single
        Dim mShipTypes(8) As String
        Dim mLooper As Integer
        Dim mVC_Value As Integer

        Gbl_Masked_TableName = Get_Table_Name_From_SQL(cmb_URCS_Year.Text, "MASKED")
        Gbl_Segments_TableName = Get_Table_Name_From_SQL(cmb_URCS_Year.Text, "SEGMENTS")
        Gbl_Unmasked_Segments_TableName = Get_Table_Name_From_SQL(cmb_URCS_Year.Text, "UNMASKED_SEGMENTS")
        Gbl_Unmasked_Rev_TableName = Get_Table_Name_From_SQL(cmb_URCS_Year.Text, "UNMASKED_REV")

        Gbl_AuditTrailLog_Tablename = Get_Table_Name_From_SQL("1", "ACTIVITYAUDITLOG")

        Insert_AuditTrail_Record("Updated WB" & cmb_URCS_Year.Text & "_Segments and WB" & cmb_URCS_Year.Text & "_Unmasked_Segments Tables.")

        Gbl_Waybill_Database_Name = Get_Database_Name_From_SQL(cmb_URCS_Year.Text, "MASKED")

        OpenADOConnection(Global_Variables.Gbl_Waybill_Database_Name)

        'Initialize the return recordset and run the query to load it
        rst = SetRST()
        System.Windows.Forms.Cursor.Current = Cursors.WaitCursor

        txt_StatusBox.Text = "Searching for records..."
        Refresh()

        mSglMaxRecs = Count_Any_Table(Global_Variables.Gbl_Waybill_Database_Name, Global_Variables.Gbl_Segments_TableName)

        System.Windows.Forms.Cursor.Current = Cursors.Default
        txt_StatusBox.Text = ""
        Refresh()

        If mSglMaxRecs > 0 Then
            mBolWrite = MsgBox("Are you sure that you want to overwrite " & mSglMaxRecs.ToString & " Segment Records for " & cmb_URCS_Year.Text & "?", vbYesNo, "Caution!")
        Else
            mBolWrite = MsgBox("Are you sure that you want to create Segment Records for " & cmb_URCS_Year.Text & "?", vbYesNo, "Caution!")
        End If

        If mBolWrite = True Then
            System.Windows.Forms.Cursor.Current = Cursors.WaitCursor

            Insert_AuditTrail_Record("Inserted Segments data into WB" & cmb_URCS_Year.Text & "_Segments and WB" & cmb_URCS_Year.Text & "_Unmasked_Segments.")

            txt_StatusBox.Text = "Wiping the output tables"
            Refresh()

            OpenADOConnection(Global_Variables.Gbl_Waybill_Database_Name)

            ' We will delete/drop the WBxxxx_Segments table here

            ' Check to see if the table exists before trying the TRUNCATE command
            If WBTableExist(Global_Variables.Gbl_Waybill_Database_Name, Global_Variables.Gbl_Segments_TableName) Then
                mStrOutSQL = "TRUNCATE TABLE " & Global_Variables.Gbl_Segments_TableName
                OpenADOConnection(Global_Variables.Gbl_Waybill_Database_Name)
                Global_Variables.gbl_ADOConnection.Execute(mStrOutSQL)
            Else
                mStrOutSQL = "CREATE TABLE " & Global_Variables.Gbl_Segments_TableName &
                    "( " &
                    "Serial_No Int NOT NULL, " &
                    "Seg_no tinyint NOT NULL, " &
                    "Total_Segs tinyint NULL, " &
                    "RR_Num smallint NULL, " &
                    "RR_Alpha nvarchar(5) NULL, " &
                    "RR_Dist int NULL, " &
                    "RR_Cntry nvarchar(2) NULL, " &
                    "RR_Rev decimal(18, 0) NULL, " &
                    "RR_VC int NULL, " &
                    "Seg_Type nvarchar(2) NULL, " &
                    "From_Node int NULL, " &
                    "To_Node int NULL, " &
                    "From_Loc nvarchar(9) NULL, " &
                    "From_St nvarchar(5) NULL, " &
                    "To_Loc nvarchar(9) NULL, " &
                    "To_St nvarchar(5) NULL) on [PRIMARY]"
                OpenADOConnection(Global_Variables.Gbl_Waybill_Database_Name)
                Global_Variables.gbl_ADOConnection.Execute(mStrOutSQL)

                ' Now we need to create the index for the table we just created.

                mStrOutSQL = "ALTER TABLE " & Global_Variables.Gbl_Segments_TableName &
                    " ADD CONSTRAINT pk_" & Global_Variables.Gbl_Segments_TableName &
                    " PRIMARY KEY CLUSTERED " &
                    "(Serial_No, Seg_No) WITH (STATISTICS_NORECOMPUTE= OFF, " &
                    "IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, " &
                    "ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]"
                OpenADOConnection(Global_Variables.Gbl_Waybill_Database_Name)
                Global_Variables.gbl_ADOConnection.Execute(mStrOutSQL)

            End If

            ' And now do the same for the WBxxxx_Unmasked_Segments table as well
            If WBTableExist(Global_Variables.Gbl_Waybill_Database_Name, Global_Variables.Gbl_Unmasked_Segments_TableName) Then
                mStrOutSQL = "TRUNCATE TABLE " & Global_Variables.Gbl_Unmasked_Segments_TableName
                OpenADOConnection(Global_Variables.Gbl_Waybill_Database_Name)
                Global_Variables.gbl_ADOConnection.Execute(mStrOutSQL)
            Else

                ' And create the Unmasked table for each segment

                mStrOutSQL = "CREATE TABLE " & Global_Variables.Gbl_Unmasked_Segments_TableName &
                    " ( " &
                    "Serial_No Int NOT NULL, " &
                    "Seg_no tinyint NOT NULL, " &
                    "RR_Unmasked_Rev decimal(18, 0) NULL) on [PRIMARY]"
                OpenADOConnection(Global_Variables.Gbl_Waybill_Database_Name)
                Global_Variables.gbl_ADOConnection.Execute(mStrOutSQL)

                ' And finally, create the index and rights for the Unmasked Segments table

                mStrOutSQL = "ALTER TABLE " & Global_Variables.Gbl_Unmasked_Segments_TableName &
                    " ADD CONSTRAINT pk_" & Global_Variables.Gbl_Unmasked_Segments_TableName &
                    " PRIMARY KEY CLUSTERED " &
                    "(Serial_No, Seg_No) WITH (STATISTICS_NORECOMPUTE= OFF, " &
                    "IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, " &
                    "ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]"
                OpenADOConnection(Global_Variables.Gbl_Waybill_Database_Name)
                Global_Variables.gbl_ADOConnection.Execute(mStrOutSQL)

                mStrOutSQL = "GRANT SELECT ON " & Global_Variables.Gbl_Unmasked_Segments_TableName &
                    " TO Unmasked_Revenue_Read_Access"
                OpenADOConnection(Global_Variables.Gbl_Waybill_Database_Name)
                Global_Variables.gbl_ADOConnection.Execute(mStrOutSQL)

                mStrOutSQL = "DENY SELECT ON " & Global_Variables.Gbl_Unmasked_Segments_TableName &
                    " TO Unmasked_Revenue_Deny_Access"
                OpenADOConnection(Global_Variables.Gbl_Waybill_Database_Name)
                Global_Variables.gbl_ADOConnection.Execute(mStrOutSQL)

            End If

            txt_StatusBox.Text = "Getting Waybill Data From Server"
            Refresh()

            mStrSQL = "SELECT " & Gbl_Masked_TableName & ".Serial_no, " &
                Gbl_Masked_TableName & ".JF, " &
                Gbl_Masked_TableName & ".ORR, " &
                Gbl_Masked_TableName & ".JCT1, " &
                Gbl_Masked_TableName & ".JRR1, " &
                Gbl_Masked_TableName & ".JCT2, " &
                Gbl_Masked_TableName & ".JRR2, " &
                Gbl_Masked_TableName & ".JCT3, " &
                Gbl_Masked_TableName & ".JRR3, " &
                Gbl_Masked_TableName & ".JCT4, " &
                Gbl_Masked_TableName & ".JRR4, " &
                Gbl_Masked_TableName & ".JCT5, " &
                Gbl_Masked_TableName & ".JRR5, " &
                Gbl_Masked_TableName & ".JCT6, " &
                Gbl_Masked_TableName & ".JRR6, " &
                Gbl_Masked_TableName & ".JCT7, " &
                Gbl_Masked_TableName & ".TRR, " &
                Gbl_Masked_TableName & ".O_FSAC, " &
                Gbl_Masked_TableName & ".T_FSAC, " &
                Gbl_Masked_TableName & ".ORR_ALPHA, " &
                Gbl_Masked_TableName & ".JRR1_ALPHA, " &
                Gbl_Masked_TableName & ".JRR2_ALPHA, " &
                Gbl_Masked_TableName & ".JRR3_ALPHA, " &
                Gbl_Masked_TableName & ".JRR4_ALPHA, "

            mStrSQL = mStrSQL &
                Gbl_Masked_TableName & ".JRR5_ALPHA, " &
                Gbl_Masked_TableName & ".JRR6_ALPHA, " &
                Gbl_Masked_TableName & ".TRR_ALPHA, " &
                Gbl_Masked_TableName & ".ORR_REV, " &
                Gbl_Masked_TableName & ".JRR1_REV, " &
                Gbl_Masked_TableName & ".JRR2_REV, " &
                Gbl_Masked_TableName & ".JRR3_REV, " &
                Gbl_Masked_TableName & ".JRR4_REV, " &
                Gbl_Masked_TableName & ".JRR5_REV, " &
                Gbl_Masked_TableName & ".JRR6_REV, " &
                Gbl_Masked_TableName & ".TRR_REV, " &
                Gbl_Masked_TableName & ".ORR_DIST, " &
                Gbl_Masked_TableName & ".JRR1_DIST, " &
                Gbl_Masked_TableName & ".JRR2_DIST, " &
                Gbl_Masked_TableName & ".JRR3_DIST, " &
                Gbl_Masked_TableName & ".JRR4_DIST, " &
                Gbl_Masked_TableName & ".JRR5_DIST, " &
                Gbl_Masked_TableName & ".JRR6_DIST, " &
                Gbl_Masked_TableName & ".TRR_DIST, " &
                Gbl_Masked_TableName & ".TOTAL_DIST, " &
                Gbl_Masked_TableName & ".REBILL, "

            mStrSQL = mStrSQL &
                Gbl_Masked_TableName & ".O_ST, " &
                Gbl_Masked_TableName & ".JCT1_ST, " &
                Gbl_Masked_TableName & ".JCT2_ST, " &
                Gbl_Masked_TableName & ".JCT3_ST, " &
                Gbl_Masked_TableName & ".JCT4_ST, " &
                Gbl_Masked_TableName & ".JCT5_ST, " &
                Gbl_Masked_TableName & ".JCT6_ST, " &
                Gbl_Masked_TableName & ".JCT7_ST, " &
                Gbl_Masked_TableName & ".T_ST, " &
                Gbl_Masked_TableName & ".ONET, " &
                Gbl_Masked_TableName & ".NET1, " &
                Gbl_Masked_TableName & ".NET2, " &
                Gbl_Masked_TableName & ".NET3, " &
                Gbl_Masked_TableName & ".NET4, " &
                Gbl_Masked_TableName & ".NET5, " &
                Gbl_Masked_TableName & ".NET6, " &
                Gbl_Masked_TableName & ".NET7, " &
                Gbl_Masked_TableName & ".TNET, "

            mStrSQL = mStrSQL &
                Gbl_Masked_TableName & ".ORR_CNTRY, " &
                Gbl_Masked_TableName & ".JRR1_CNTRY, " &
                Gbl_Masked_TableName & ".JRR2_CNTRY, " &
                Gbl_Masked_TableName & ".JRR3_CNTRY, " &
                Gbl_Masked_TableName & ".JRR4_CNTRY, " &
                Gbl_Masked_TableName & ".JRR5_CNTRY, " &
                Gbl_Masked_TableName & ".JRR6_CNTRY, " &
                Gbl_Masked_TableName & ".TRR_CNTRY, " &
                Gbl_Masked_TableName & ".RR1_VC, " &
                Gbl_Masked_TableName & ".RR2_VC, " &
                Gbl_Masked_TableName & ".RR3_VC, " &
                Gbl_Masked_TableName & ".RR4_VC, " &
                Gbl_Masked_TableName & ".RR5_VC, " &
                Gbl_Masked_TableName & ".RR6_VC, " &
                Gbl_Masked_TableName & ".RR7_VC, " &
                Gbl_Masked_TableName & ".RR8_VC, " &
                Gbl_Masked_TableName & ".STB_CAR_TYP, " &
                Gbl_Masked_TableName & ".TOFC_SERV_CODE, "

            mStrSQL = mStrSQL &
                Global_Variables.Gbl_Unmasked_Rev_TableName & ".ORR_Unmasked_Rev, " &
                Global_Variables.Gbl_Unmasked_Rev_TableName & ".JRR1_Unmasked_Rev, " &
                Global_Variables.Gbl_Unmasked_Rev_TableName & ".JRR2_Unmasked_Rev, " &
                Global_Variables.Gbl_Unmasked_Rev_TableName & ".JRR3_Unmasked_Rev, " &
                Global_Variables.Gbl_Unmasked_Rev_TableName & ".JRR4_Unmasked_Rev, " &
                Global_Variables.Gbl_Unmasked_Rev_TableName & ".JRR5_Unmasked_Rev, " &
                Global_Variables.Gbl_Unmasked_Rev_TableName & ".JRR6_Unmasked_Rev, " &
                Global_Variables.Gbl_Unmasked_Rev_TableName & ".TRR_Unmasked_Rev "

            ' Now we add the join properties between the 2 tables

            mStrSQL = mStrSQL & "FROM " & Gbl_Masked_TableName & " INNER JOIN " &
                Global_Variables.Gbl_Unmasked_Rev_TableName & " ON " &
                Gbl_Masked_TableName & ".Serial_No = " &
                Global_Variables.Gbl_Unmasked_Rev_TableName & ".Unmasked_Serial_No"

            rst = SetRST()
            rst.Open(mStrSQL, Global_Variables.gbl_ADOConnection)

            rst.MoveFirst()
            mThisRec = 1
            Do While Not rst.EOF
                If mThisRec Mod 100 = 0 Then
                    txt_StatusBox.Text = "Loading record " & mThisRec.ToString & " of " & rst.RecordCount.ToString & "..."
                    Refresh()
                    setTaskbarProgress((mThisRec / rst.RecordCount) * 100, 100, TaskbarProgressBarState.Normal)
                    Application.DoEvents()
                End If

                '********************************************************************************
                ' Determine if the move is Intermodal
                '********************************************************************************
                mIntermodal = False

                Select Case rst.Fields("stb_car_typ").Value
                    Case 46, 49, 52, 54
                        If Len(Trim(ReturnString(rst.Fields("tofc_serv_code").Value, 0))) > 0 Then
                            mIntermodal = True
                        End If
                End Select

                '********************************************************************************
                ' Now we set the shiptypes for the waybill record
                '********************************************************************************
                If rst.Fields("jf").Value = 0 Then
                    Select Case rst.Fields("rebill").Value
                        Case 0
                            If ((rst.Fields("total_dist").Value / 10) < 8.5) And (mIntermodal = False) Then
                                '********************************************************************************
                                ' Only set this to "IA" if there is only one railroad reported in the movement,
                                ' it is not a rebill, it travels less than 8.5 miles, and it is not intermodal.
                                '********************************************************************************
                                mShipTypes(0) = "IA"
                            Else
                                mShipTypes(0) = "OT"
                            End If
                        Case 1
                            mShipTypes(0) = "OD"
                        Case 2
                            mShipTypes(0) = "RD"
                        Case 3
                            mShipTypes(0) = "RT"
                    End Select
                Else
                    '********************************************************************************
                    ' Set the default shiptype array values if there are more than one railroad
                    ' reported in the route.
                    '   1) Array position 0 is the ORR
                    '   2) Positions 1-6 are the JRRs
                    '   3) Position 7 is the TRR
                    '********************************************************************************
                    mShipTypes(0) = "OD"
                    For mLooper = 1 To 6
                        mShipTypes(mLooper) = "RD"
                    Next mLooper
                    mShipTypes(7) = "RT"

                    '********************************************************************************
                    ' This next section is commented out under the assumption that a rebill,
                    ' which reports other railroads in the movement, is reporting "all" the other
                    ' railroads in the movement.  In other words, the only segments that will
                    ' start or end with "RD" are rebills with no other railroads reported in
                    ' the route.
                    '********************************************************************************
                    'Select Case rst.Fields("rebill").Value
                    '    Case 1
                    '        mShipTypes(7) = "RD"
                    '    Case 2
                    '        mShipTypes(0) = "RD"
                    '        mShipTypes(7) = "RD"
                    '    Case 3
                    '        mShipTypes(0) = "RD"
                    'End Select
                    '********************************************************************************

                    If (rst.Fields("jf").Value = 1) And (rst.Fields("rebill").Value = 0) Then
                        If ((rst.Fields("total_dist").Value / 10) < 8.5) And (mIntermodal = False) Then
                            '********************************************************************************
                            ' Only set this to "IR" if there are only two railroads reported in the movement,
                            ' it is not a rebill, it travels less than 8.5 miles, and it is not intermodal.
                            '********************************************************************************
                            For mLooper = 0 To 7
                                mShipTypes(mLooper) = "IR"
                            Next mLooper
                        End If
                    End If

                End If

                '********************************************************************************
                ' Make accodations for the VC if it is blank
                '********************************************************************************
                If IsDBNull(rst.Fields("RR1_VC").Value) = True Then
                    mVC_Value = 0
                Else
                    mVC_Value = rst.Fields("RR1_VC").Value
                End If

                '********************************************************************************
                '* Write the unique records to the Segments table
                '********************************************************************************

                Select Case rst.Fields("JF").Value
                    Case 0

                        ' Add the record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            1,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("ORR").Value,
                            ReturnString(rst.Fields("ORR_Alpha").Value, 0),
                            rst.Fields("ORR_Dist").Value,
                            ReturnString(rst.Fields("ORR_Cntry").Value, 0),
                            rst.Fields("ORR_Rev").Value,
                            mVC_Value,
                            mShipTypes(0),
                            rst.Fields("ONET").Value,
                            rst.Fields("TNET").Value,
                            Field_Right(rst.Fields("ORR").Value, 3) & "-" & Field_Right(rst.Fields("O_FSAC").Value, 5),
                            rst.Fields("O_ST").Value,
                            Field_Right(rst.Fields("TRR").Value, 3) & "-" & Field_Right(rst.Fields("T_FSAC").Value, 5),
                            rst.Fields("T_ST").Value).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            1,
                            rst.Fields("ORR_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                    Case 1

                        ' Add the record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            1,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("ORR").Value,
                            rst.Fields("ORR_Alpha").Value,
                            rst.Fields("ORR_Dist").Value,
                            ReturnString(rst.Fields("ORR_Cntry").Value, 0),
                            rst.Fields("ORR_Rev").Value,
                            mVC_Value,
                            mShipTypes(0),
                            rst.Fields("ONET").Value,
                            rst.Fields("NET1").Value,
                            Field_Right(rst.Fields("ORR").Value, 3) & "-" & Field_Right(rst.Fields("O_FSAC").Value, 5),
                            rst.Fields("O_ST").Value,
                            ReturnString(rst.Fields("JCT1").Value, 0),
                            ReturnString(rst.Fields("JCT1_ST").Value, 0)).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the record to the Unmasked Segments table
                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            1,
                            rst.Fields("ORR_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        '********************************************************************************
                        ' Make accodations for the VC if it is blank
                        '********************************************************************************
                        If IsDBNull(rst.Fields("RR2_VC").Value) = True Then
                            mVC_Value = 0
                        Else
                            mVC_Value = rst.Fields("RR2_VC").Value
                        End If

                        ' Add the 2nd record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            2,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("TRR").Value,
                            rst.Fields("TRR_Alpha").Value,
                            rst.Fields("TRR_Dist").Value,
                            ReturnString(rst.Fields("TRR_Cntry").Value, 0),
                            rst.Fields("TRR_Rev").Value,
                            rst.Fields("RR2_VC").Value,
                            mShipTypes(7),
                            rst.Fields("NET1").Value,
                            rst.Fields("TNET").Value,
                            ReturnString(rst.Fields("JCT1").Value, 0),
                            ReturnString(rst.Fields("JCT1_ST").Value, 0),
                            Field_Right(rst.Fields("TRR").Value, 3) & "-" & Field_Right(rst.Fields("T_FSAC").Value, 5),
                            rst.Fields("T_ST").Value).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the 2nd record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            2,
                            rst.Fields("TRR_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                    Case 2

                        ' The first Segment and Unmasked Segment records will be added later

                        '********************************************************************************
                        ' Make accodations for the VC if it is blank
                        '********************************************************************************
                        If IsDBNull(rst.Fields("RR2_VC").Value) = True Then
                            mVC_Value = 0
                        Else
                            mVC_Value = rst.Fields("RR2_VC").Value
                        End If

                        ' Add the 2nd record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            2,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("JRR1").Value,
                            rst.Fields("JRR1_Alpha").Value,
                            rst.Fields("JRR1_Dist").Value,
                            ReturnString(rst.Fields("JRR1_Cntry").Value, 0),
                            rst.Fields("JRR1_Rev").Value,
                            mVC_Value,
                            mShipTypes(1),
                            rst.Fields("NET1").Value,
                            rst.Fields("NET2").Value,
                            ReturnString(rst.Fields("JCT1").Value, 0),
                            ReturnString(rst.Fields("JCT1_ST").Value, 0),
                            ReturnString(rst.Fields("JCT2").Value, 0),
                            ReturnString(rst.Fields("JCT2_ST").Value, 0)).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the 2nd record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            2,
                            rst.Fields("JRR1_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        '********************************************************************************
                        ' Make accodations for the VC if it is blank
                        '********************************************************************************
                        If IsDBNull(rst.Fields("RR3_VC").Value) = True Then
                            mVC_Value = 0
                        Else
                            mVC_Value = rst.Fields("RR3_VC").Value
                        End If

                        ' Add the 3rd record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            3,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("TRR").Value,
                            rst.Fields("TRR_Alpha").Value,
                            rst.Fields("TRR_Dist").Value,
                            ReturnString(rst.Fields("TRR_Cntry").Value, 0),
                            rst.Fields("TRR_Rev").Value,
                            mVC_Value,
                            mShipTypes(7),
                            rst.Fields("NET2").Value,
                            rst.Fields("TNET").Value,
                            ReturnString(rst.Fields("JCT2").Value, 0),
                            ReturnString(rst.Fields("JCT2_ST").Value, 0),
                            Field_Right(rst.Fields("TRR").Value, 3) & "-" & Field_Right(rst.Fields("T_FSAC").Value, 5),
                            rst.Fields("T_ST").Value).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the 3rd record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            3,
                            rst.Fields("TRR_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                    Case 3

                        ' The first 2 Segment and Unmasked Segment records will be added later

                        '********************************************************************************
                        ' Make accodations for the VC if it is blank
                        '********************************************************************************
                        If IsDBNull(rst.Fields("RR3_VC").Value) = True Then
                            mVC_Value = 0
                        Else
                            mVC_Value = rst.Fields("RR3_VC").Value
                        End If

                        ' Add the 3rd record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            3,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("JRR2").Value,
                            rst.Fields("JRR2_Alpha").Value,
                            rst.Fields("JRR2_Dist").Value,
                            ReturnString(rst.Fields("JRR2_Cntry").Value, 0),
                            rst.Fields("JRR2_Rev").Value,
                            rst.Fields("RR3_VC").Value,
                            mShipTypes(2),
                            rst.Fields("NET2").Value,
                            rst.Fields("NET3").Value,
                            ReturnString(rst.Fields("JCT2").Value, 0),
                            ReturnString(rst.Fields("JCT2_ST").Value, 0),
                            ReturnString(rst.Fields("JCT3").Value, 0),
                            ReturnString(rst.Fields("JCT3_ST").Value, 0)).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the 3rd record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            3,
                            rst.Fields("JRR2_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        '********************************************************************************
                        ' Make accodations for the VC if it is blank
                        '********************************************************************************
                        If IsDBNull(rst.Fields("RR4_VC").Value) = True Then
                            mVC_Value = 0
                        Else
                            mVC_Value = rst.Fields("RR4_VC").Value
                        End If

                        ' Add the 4th record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            4,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("TRR").Value,
                            rst.Fields("TRR_Alpha").Value,
                            rst.Fields("TRR_Dist").Value,
                            ReturnString(rst.Fields("TRR_Cntry").Value, 0),
                            rst.Fields("TRR_Rev").Value,
                            mVC_Value,
                            mShipTypes(7),
                            rst.Fields("NET3").Value,
                            rst.Fields("TNET").Value,
                            ReturnString(rst.Fields("JCT3").Value, 0),
                            ReturnString(rst.Fields("JCT3_ST").Value, 0),
                            Field_Right(rst.Fields("TRR").Value, 3) & "-" & Field_Right(rst.Fields("T_FSAC").Value, 5),
                            rst.Fields("T_ST").Value).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the 4th record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            4,
                            rst.Fields("TRR_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                    Case 4

                        ' The first 3 Segment and Unmasked Segment records will be added later

                        '********************************************************************************
                        ' Make accodations for the VC if it is blank
                        '********************************************************************************
                        If IsDBNull(rst.Fields("RR4_VC").Value) = True Then
                            mVC_Value = 0
                        Else
                            mVC_Value = rst.Fields("RR4_VC").Value
                        End If

                        ' Add the 4th record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            4,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("JRR3").Value,
                            rst.Fields("JRR3_Alpha").Value,
                            rst.Fields("JRR3_Dist").Value,
                            ReturnString(rst.Fields("JRR3_Cntry").Value, 0),
                            rst.Fields("JRR3_Rev").Value,
                            mVC_Value,
                            mShipTypes(3),
                            rst.Fields("NET3").Value,
                            rst.Fields("NET4").Value,
                            ReturnString(rst.Fields("JCT3").Value, 0),
                            ReturnString(rst.Fields("JCT3_ST").Value, 0),
                            ReturnString(rst.Fields("JCT4").Value, 0),
                            ReturnString(rst.Fields("JCT4_ST").Value, 0)).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the 4th record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            4,
                            rst.Fields("JRR3_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        '********************************************************************************
                        ' Make accodations for the VC if it is blank
                        '********************************************************************************
                        If IsDBNull(rst.Fields("RR5_VC").Value) = True Then
                            mVC_Value = 0
                        Else
                            mVC_Value = rst.Fields("RR5_VC").Value
                        End If

                        ' Add the 5th record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            5,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("TRR").Value,
                            rst.Fields("TRR_Alpha").Value,
                            rst.Fields("TRR_Dist").Value,
                            ReturnString(rst.Fields("TRR_Cntry").Value, 0),
                            rst.Fields("TRR_Rev").Value,
                            mVC_Value,
                            mShipTypes(7),
                            rst.Fields("NET4").Value,
                            rst.Fields("TNET").Value,
                            ReturnString(rst.Fields("JCT4").Value, 0),
                            ReturnString(rst.Fields("JCT4_ST").Value, 0),
                            Field_Right(rst.Fields("TRR").Value, 3) & "-" & Field_Right(rst.Fields("T_FSAC").Value, 5),
                            rst.Fields("T_ST").Value).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the 4th record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            5,
                            rst.Fields("TRR_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                    Case 5

                        ' The first 4 Segment and Unmasked Segment records will be added later

                        '********************************************************************************
                        ' Make accodations for the VC if it is blank
                        '********************************************************************************
                        If IsDBNull(rst.Fields("RR5_VC").Value) = True Then
                            mVC_Value = 0
                        Else
                            mVC_Value = rst.Fields("RR5_VC").Value
                        End If

                        ' Add the 5th record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            5,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("JRR4").Value,
                            rst.Fields("JRR4_Alpha").Value,
                            rst.Fields("JRR4_Dist").Value,
                            ReturnString(rst.Fields("JRR4_Cntry").Value, 0),
                            rst.Fields("JRR4_Rev").Value,
                            mVC_Value,
                            mShipTypes(4),
                            rst.Fields("NET4").Value,
                            rst.Fields("NET5").Value,
                            ReturnString(rst.Fields("JCT4").Value, 0),
                            ReturnString(rst.Fields("JCT4_ST").Value, 0),
                            ReturnString(rst.Fields("JCT5").Value, 0),
                            ReturnString(rst.Fields("JCT5_ST").Value, 0)).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the 5th record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            5,
                            rst.Fields("JRR4_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        '********************************************************************************
                        ' Make accodations for the VC if it is blank
                        '********************************************************************************
                        If IsDBNull(rst.Fields("RR6_VC").Value) = True Then
                            mVC_Value = 0
                        Else
                            mVC_Value = rst.Fields("RR6_VC").Value
                        End If

                        ' Add the 6th record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            6,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("TRR").Value,
                            rst.Fields("TRR_Alpha").Value,
                            rst.Fields("TRR_Dist").Value,
                            ReturnString(rst.Fields("TRR_Cntry").Value, 0),
                            rst.Fields("TRR_Rev").Value,
                            rst.Fields("RR6_VC").Value,
                            mShipTypes(7),
                            rst.Fields("NET5").Value,
                            rst.Fields("TNET").Value,
                            ReturnString(rst.Fields("JCT5").Value, 0),
                            ReturnString(rst.Fields("JCT5_ST").Value, 0),
                            Field_Right(rst.Fields("TRR").Value, 3) & "-" & Field_Right(rst.Fields("T_FSAC").Value, 5),
                            rst.Fields("T_ST").Value).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the 6th record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            6,
                            rst.Fields("TRR_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                    Case 6

                        ' The first 5 Segment and Unmasked Segment records will be added later

                        '********************************************************************************
                        ' Make accodations for the VC if it is blank
                        '********************************************************************************
                        If IsDBNull(rst.Fields("RR6_VC").Value) = True Then
                            mVC_Value = 0
                        Else
                            mVC_Value = rst.Fields("RR6_VC").Value
                        End If

                        ' Add the 6th record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            6,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("JRR5").Value,
                            rst.Fields("JRR5_Alpha").Value,
                            rst.Fields("JRR5_Dist").Value,
                            ReturnString(rst.Fields("JRR5_Cntry").Value, 0),
                            rst.Fields("JRR5_Rev").Value,
                            mVC_Value,
                            mShipTypes(5),
                            rst.Fields("NET5").Value,
                            rst.Fields("NET6").Value,
                            ReturnString(rst.Fields("JCT5").Value, 0),
                            ReturnString(rst.Fields("JCT5_ST").Value, 0),
                            ReturnString(rst.Fields("JCT6").Value, 0),
                            ReturnString(rst.Fields("JCT6_ST").Value, 0)).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the 6th record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            6,
                            rst.Fields("JRR5_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        '********************************************************************************
                        ' Make accodations for the VC if it is blank
                        '********************************************************************************
                        If IsDBNull(rst.Fields("RR7_VC").Value) = True Then
                            mVC_Value = 0
                        Else
                            mVC_Value = rst.Fields("RR7_VC").Value
                        End If

                        ' Add the 7th record to the Segments table

                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            7,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("TRR").Value,
                            rst.Fields("TRR_Alpha").Value,
                            rst.Fields("TRR_Dist").Value,
                            ReturnString(rst.Fields("TRR_Cntry").Value, 0),
                            rst.Fields("TRR_Rev").Value,
                            mVC_Value,
                            mShipTypes(7),
                            rst.Fields("NET6").Value,
                            rst.Fields("TNET").Value,
                            ReturnString(rst.Fields("JCT6").Value, 0),
                            ReturnString(rst.Fields("JCT6_ST").Value, 0),
                            ReturnString(Field_Right(rst.Fields("TRR").Value, 3) & "-" & Field_Right(rst.Fields("T_FSAC").Value, 5), 0),
                            ReturnString(rst.Fields("T_ST").Value, 0)).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the 7th record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            7,
                            rst.Fields("TRR_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                    Case 7

                        ' The first 6 Segment and Unmasked Segment records will be added later

                        '********************************************************************************
                        ' Make accodations for the VC if it is blank
                        '********************************************************************************
                        If IsDBNull(rst.Fields("RR7_VC").Value) = True Then
                            mVC_Value = 0
                        Else
                            mVC_Value = rst.Fields("RR7_VC").Value
                        End If

                        ' Add the 7th record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            7,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("JRR6").Value,
                            rst.Fields("JRR6_Alpha").Value,
                            rst.Fields("JRR6_Dist").Value,
                            ReturnString(rst.Fields("JRR6_Cntry").Value, 0),
                            rst.Fields("JRR6_Rev").Value,
                            mVC_Value,
                            mShipTypes(6),
                            rst.Fields("NET6").Value,
                            rst.Fields("NET7").Value,
                            ReturnString(rst.Fields("JCT6").Value, 0),
                            ReturnString(rst.Fields("JCT6_ST").Value, 0),
                            ReturnString(rst.Fields("JCT7").Value, 0),
                            ReturnString(rst.Fields("JCT7_ST").Value, 0)).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the 7th record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            7,
                            rst.Fields("JRR6_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        '********************************************************************************
                        ' Make accodations for the VC if it is blank
                        '********************************************************************************
                        If IsDBNull(rst.Fields("RR8_VC").Value) = True Then
                            mVC_Value = 0
                        Else
                            mVC_Value = rst.Fields("RR8_VC").Value
                        End If

                        ' Add the 8th record to the Segments table
                        mStrSQL = Build_Segment_SQL(
                            Global_Variables.Gbl_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            8,
                            rst.Fields("JF").Value + 1,
                            rst.Fields("TRR").Value,
                            ReturnString(rst.Fields("TRR_Alpha").Value, 0),
                            rst.Fields("TRR_Dist").Value,
                            ReturnString(rst.Fields("TRR_Cntry").Value, 0),
                            rst.Fields("TRR_Rev").Value,
                            mVC_Value,
                            mShipTypes(7),
                            rst.Fields("NET7").Value,
                            rst.Fields("TNET").Value,
                            ReturnString(rst.Fields("JCT7").Value, 0),
                            ReturnString(rst.Fields("JCT7_ST").Value, 0),
                            Field_Right(rst.Fields("TRR").Value, 3) & "-" & Field_Right(rst.Fields("T_FSAC").Value, 5),
                            ReturnString(rst.Fields("T_ST").Value, 0)).ToString
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                        'Add the 8th record to the Unmasked Segments table

                        mStrSQL = Build_Unmasked_Segment_SQL(
                            Global_Variables.Gbl_Unmasked_Segments_TableName,
                            rst.Fields("Serial_No").Value,
                            8,
                            rst.Fields("TRR_Unmasked_Rev").Value)
                        Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                End Select

                If rst.Fields("JF").Value > 1 Then
                    ' Write the first Segment and Unmasked Segment records
                    ' Add the record to the Segments table

                    '********************************************************************************
                    ' Make accodations for the VC if it is blank
                    '********************************************************************************
                    If IsDBNull(rst.Fields("RR1_VC").Value) = True Then
                        mVC_Value = 0
                    Else
                        mVC_Value = rst.Fields("RR1_VC").Value
                    End If

                    mStrSQL = Build_Segment_SQL(
                        Global_Variables.Gbl_Segments_TableName,
                        rst.Fields("Serial_No").Value,
                        1,
                        rst.Fields("JF").Value + 1,
                        rst.Fields("ORR").Value,
                        rst.Fields("ORR_Alpha").Value,
                        rst.Fields("ORR_Dist").Value,
                        ReturnString(rst.Fields("ORR_Cntry").Value, 0),
                        rst.Fields("ORR_Rev").Value,
                        mVC_Value,
                        mShipTypes(0),
                        rst.Fields("ONET").Value,
                        rst.Fields("NET1").Value,
                        Field_Right(rst.Fields("ORR").Value, 3) & "-" & Field_Right(rst.Fields("O_FSAC").Value, 5),
                        rst.Fields("O_ST").Value,
                        ReturnString(rst.Fields("JCT1").Value, 0),
                        ReturnString(rst.Fields("JCT1_ST").Value, 0)).ToString
                    Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                    'Add the record to the Unmasked Segments table
                    mStrSQL = Build_Unmasked_Segment_SQL(
                        Global_Variables.Gbl_Unmasked_Segments_TableName,
                        rst.Fields("Serial_No").Value,
                        1,
                        rst.Fields("ORR_Unmasked_Rev").Value)
                    Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                End If

                If rst.Fields("JF").Value > 2 Then
                    ' Write the 2nd Segment and Unmasked Segment records

                    '********************************************************************************
                    ' Make accodations for the VC if it is blank
                    '********************************************************************************
                    If IsDBNull(rst.Fields("RR2_VC").Value) = True Then
                        mVC_Value = 0
                    Else
                        mVC_Value = rst.Fields("RR2_VC").Value
                    End If

                    ' Add the 2nd record to the Segments table
                    mStrSQL = Build_Segment_SQL(
                        Global_Variables.Gbl_Segments_TableName,
                        rst.Fields("Serial_No").Value,
                        2,
                        rst.Fields("JF").Value + 1,
                        rst.Fields("JRR1").Value,
                        rst.Fields("JRR1_Alpha").Value,
                        rst.Fields("JRR1_Dist").Value,
                        ReturnString(rst.Fields("JRR1_Cntry").Value, 0),
                        rst.Fields("JRR1_Rev").Value,
                        mVC_Value,
                        mShipTypes(1),
                        rst.Fields("NET1").Value,
                        rst.Fields("NET2").Value,
                        ReturnString(rst.Fields("JCT1").Value, 0),
                        ReturnString(rst.Fields("JCT1_ST").Value, 0),
                        ReturnString(rst.Fields("JCT2").Value, 0),
                        ReturnString(rst.Fields("JCT2_ST").Value, 0)).ToString
                    Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                    'Add the 2nd record to the Unmasked Segments table

                    mStrSQL = Build_Unmasked_Segment_SQL(
                        Global_Variables.Gbl_Unmasked_Segments_TableName,
                        rst.Fields("Serial_No").Value,
                        2,
                        rst.Fields("JRR1_Unmasked_Rev").Value)
                    Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                End If

                If rst.Fields("JF").Value > 3 Then
                    ' Write the 3rd Segment and Unmasked Segment records

                    '********************************************************************************
                    ' Make accodations for the VC if it is blank
                    '********************************************************************************
                    If IsDBNull(rst.Fields("RR3_VC").Value) = True Then
                        mVC_Value = 0
                    Else
                        mVC_Value = rst.Fields("RR3_VC").Value
                    End If

                    ' Add the 3rd record to the Segments table
                    mStrSQL = Build_Segment_SQL(
                        Global_Variables.Gbl_Segments_TableName,
                        rst.Fields("Serial_No").Value,
                        3,
                        rst.Fields("JF").Value + 1,
                        rst.Fields("JRR2").Value,
                        rst.Fields("JRR2_Alpha").Value,
                        rst.Fields("JRR2_Dist").Value,
                        ReturnString(rst.Fields("JRR2_Cntry").Value, 0),
                        rst.Fields("JRR2_Rev").Value,
                        mVC_Value,
                        mShipTypes(2),
                        rst.Fields("NET2").Value,
                        rst.Fields("NET3").Value,
                        ReturnString(rst.Fields("JCT2").Value, 0),
                        ReturnString(rst.Fields("JCT2_ST").Value, 0),
                        ReturnString(rst.Fields("JCT3").Value, 0),
                        ReturnString(rst.Fields("JCT3_ST").Value, 0)).ToString
                    Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                    'Add the 3rd record to the Unmasked Segments table

                    mStrSQL = Build_Unmasked_Segment_SQL(
                        Global_Variables.Gbl_Unmasked_Segments_TableName,
                        rst.Fields("Serial_No").Value,
                        3,
                        rst.Fields("JRR2_Unmasked_Rev").Value)
                    Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                End If

                If rst.Fields("JF").Value > 4 Then
                    ' Write the 4th Segment and Unmasked Segment records

                    '********************************************************************************
                    ' Make accodations for the VC if it is blank
                    '********************************************************************************
                    If IsDBNull(rst.Fields("RR4_VC").Value) = True Then
                        mVC_Value = 0
                    Else
                        mVC_Value = rst.Fields("RR4_VC").Value
                    End If

                    ' Add the 4th record to the Segments table
                    mStrSQL = Build_Segment_SQL(
                        Global_Variables.Gbl_Segments_TableName,
                        rst.Fields("Serial_No").Value,
                        4,
                        rst.Fields("JF").Value + 1,
                        rst.Fields("JRR3").Value,
                        rst.Fields("JRR3_Alpha").Value,
                        rst.Fields("JRR3_Dist").Value,
                        ReturnString(rst.Fields("JRR3_Cntry").Value, 0),
                        rst.Fields("JRR3_Rev").Value,
                        mVC_Value,
                        mShipTypes(3),
                        rst.Fields("NET3").Value,
                        rst.Fields("NET4").Value,
                        ReturnString(rst.Fields("JCT3").Value, 0),
                        ReturnString(rst.Fields("JCT3_ST").Value, 0),
                        ReturnString(rst.Fields("JCT4").Value, 0),
                        ReturnString(rst.Fields("JCT4_ST").Value, 0)).ToString
                    Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                    'Add the 4th record to the Unmasked Segments table

                    mStrSQL = Build_Unmasked_Segment_SQL(
                        Global_Variables.Gbl_Unmasked_Segments_TableName,
                        rst.Fields("Serial_No").Value,
                        4,
                        rst.Fields("JRR3_Unmasked_Rev").Value)
                    Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                End If

                If rst.Fields("JF").Value > 5 Then
                    ' Write the 5th Segment and Unmasked Segment records

                    '********************************************************************************
                    ' Make accodations for the VC if it is blank
                    '********************************************************************************
                    If IsDBNull(rst.Fields("RR5_VC").Value) = True Then
                        mVC_Value = 0
                    Else
                        mVC_Value = rst.Fields("RR5_VC").Value
                    End If

                    ' Add the 5th record to the Segments table
                    mStrSQL = Build_Segment_SQL(
                        Global_Variables.Gbl_Segments_TableName,
                        rst.Fields("Serial_No").Value,
                        5,
                        rst.Fields("JF").Value + 1,
                        rst.Fields("JRR4").Value,
                        rst.Fields("JRR4_Alpha").Value,
                        rst.Fields("JRR4_Dist").Value,
                        ReturnString(rst.Fields("JRR4_Cntry").Value, 0),
                        rst.Fields("JRR4_Rev").Value,
                        mVC_Value,
                        mShipTypes(4),
                        rst.Fields("NET4").Value,
                        rst.Fields("NET5").Value,
                        ReturnString(rst.Fields("JCT4").Value, 0),
                        ReturnString(rst.Fields("JCT4_ST").Value, 0),
                        ReturnString(rst.Fields("JCT5").Value, 0),
                        ReturnString(rst.Fields("JCT5_ST").Value, 0)).ToString
                    Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                    'Add the 4th record to the Unmasked Segments table

                    mStrSQL = Build_Unmasked_Segment_SQL(
                        Global_Variables.Gbl_Unmasked_Segments_TableName,
                        rst.Fields("Serial_No").Value,
                        5,
                        rst.Fields("JRR4_Unmasked_Rev").Value)
                    Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                End If

                If rst.Fields("JF").Value > 6 Then
                    ' Write the 6th Segment and Unmasked Segment records

                    '********************************************************************************
                    ' Make accodations for the VC if it is blank
                    '********************************************************************************
                    If IsDBNull(rst.Fields("RR6_VC").Value) = True Then
                        mVC_Value = 0
                    Else
                        mVC_Value = rst.Fields("RR6_VC").Value
                    End If

                    ' Add the 6th record to the Segments table
                    mStrSQL = Build_Segment_SQL(
                        Global_Variables.Gbl_Segments_TableName,
                        rst.Fields("Serial_No").Value,
                        6,
                        rst.Fields("JF").Value + 1,
                        rst.Fields("JRR5").Value,
                        rst.Fields("JRR5_Alpha").Value,
                        rst.Fields("JRR5_Dist").Value,
                        ReturnString(rst.Fields("JRR5_Cntry").Value, 0),
                        rst.Fields("JRR5_Rev").Value,
                        mVC_Value,
                        mShipTypes(5),
                        rst.Fields("NET5").Value,
                        rst.Fields("NET6").Value,
                        ReturnString(rst.Fields("JCT5").Value, 0),
                        ReturnString(rst.Fields("JCT5_ST").Value, 0),
                        ReturnString(rst.Fields("JCT6").Value, 0),
                        ReturnString(rst.Fields("JCT6_ST").Value, 0)).ToString
                    Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                    'Add the 6th record to the Unmasked Segments table

                    mStrSQL = Build_Unmasked_Segment_SQL(
                        Global_Variables.Gbl_Unmasked_Segments_TableName,
                        rst.Fields("Serial_No").Value,
                        6,
                        rst.Fields("JRR5_Unmasked_Rev").Value)
                    Global_Variables.gbl_ADOConnection.Execute(mStrSQL)

                End If

                mThisRec = mThisRec + 1
                rst.MoveNext()
            Loop

            rst.Close()
            rst = Nothing

            txt_StatusBox.Text = "Done!"
            Refresh()

        Else
            txt_StatusBox.Text = "Run Aborted."
            Refresh()
        End If

        System.Windows.Forms.Cursor.Current = Cursors.Default

    End Sub

    Public Shared Function NotNull(Of T)(ByVal Value As T, ByVal DefaultValue As T) As T
        If Value Is Nothing OrElse IsDBNull(Value) Then
            Return DefaultValue
        Else
            Return Value
        End If
    End Function
End Class